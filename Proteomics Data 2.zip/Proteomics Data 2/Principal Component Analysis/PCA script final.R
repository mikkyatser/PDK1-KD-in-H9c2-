# Name: Chelsea Wenyonu
# Date: 2024-01-10
# Description: PCA Plotting Script


#Loading required packages
library(dplyr)
library(readxl)
library(writexl)
library(ggfortify)
library(ggplot2)
library(ggforce)
library(extrafont)
extrafont::loadfonts()
library(cluster)
library(factoextra)


#Loading excel sheet
log_data <- read.csv("Input/Log transformed Protein Matrix.csv")
#filter to remove non-resolved protein isoforms
# Remove rows where 'Genes' column contains ";"
log_data <- log_data[!grepl(";", log_data$Protein.Group), ]

log_data <- log_data[c(28, 1:24)]

#Making log_data numeric
log_data[, 2:25] <- lapply(log_data[, 2:25], as.numeric)

# Removing rows with NAs
log_data <- na.omit(log_data)

# Removing duplicated rows based on the 'genes' column
log_data <- log_data[!duplicated(log_data$Genes), ]

#Saving log_data as a csv file
write.csv(log_data, "Output/PCA sheet.csv", row.names = FALSE)

log_data2 <- log_data[c(1,5:7, 11:13, 17:19, 23:25)] 

# Extracting the gene names as column names
column_names <- log_data[, 1]

# Transposing the dataframe and setting column names
transform <- t(log_data[,-1])
colnames(transform) <- log_data$Genes


# Converting matrix to data frame
transform <- as.data.frame(transform)

#Creating another column based on treatment grouping  
transform <- transform %>%
  mutate(Samplegroups = case_when(
    grepl("control_BSA", rownames(transform)) ~ "SC+BSA",
    grepl("control_SS_BSA", rownames(transform)) ~ "SC+SS+BSA",
    grepl("control_PA", rownames(transform)) ~ "SC+PA",
    grepl("control_SS_PA", rownames(transform)) ~ "SC+SS+PA",
    grepl("KD_BSA", rownames(transform)) ~ "KD+BSA",
    grepl("KD_SS_BSA", rownames(transform)) ~ "KD+SS+BSA",
    grepl("KD_PA", rownames(transform)) ~ "KD+PA",
    grepl("KD_SS_PA", rownames(transform)) ~ "KD+SS+PA",
    TRUE ~ NA_character_
  )) %>%
  select(Samplegroups, everything())


# Saving transform as a CSV file
output_file_path <- "D:/Users/johnsonlab/Desktop/PDK1 proteomics project/Principal Component Analysis/Output/your_dataframe.csv"
write.csv(transform, output_file_path, row.names = FALSE)

######################Plotting PCA against a white background and specifying Helvetica font##################
pca_plot <- prcomp(transform[c(-1)], scale. = TRUE)

# Converting "Samplegroups" column to factor with specified levels
transform$Samplegroups <- factor(transform$Samplegroups, levels = c(
  "SC+BSA", "SC+PA", "SC+SS+BSA", "SC+SS+PA",
  "KD+BSA", "KD+PA", "KD+SS+BSA", "KD+SS+PA"))

# Plotting PCA
autoplot(pca_plot, data = transform, colour = 'Samplegroups') +
  scale_color_manual(values = c(
    "KD+BSA" = "darkorange1",
    "KD+PA" = "deepskyblue",
    "KD+SS+BSA" = "black",
    "KD+SS+PA" = "red4",
    "SC+BSA" = "chartreuse4",
    "SC+PA" = "blue", 
    "SC+SS+BSA" = "darkorchid1",
    "SC+SS+PA" = "lightsalmon"
  )) +
  theme_bw() +
  ggtitle(" ") 

#################Clustering points on PCA by similarity#######################
#Performing PCA using prcomp
pca_result <- prcomp(transform[, 2:6096], scale. = TRUE)

# Accessing principal components
transform$PC1 <- pca_plot$x[, 1]
transform$PC2 <- pca_plot$x[, 2]

# Performing PAM clustering
pam_result <- pam(transform[, 2:6096], k = 2)

# Assigning cluster labels to the dataframe
transform$Cluster <- pam_result$clustering

# Specifying the fill colors for the convex hulls
convex_fill_colors <- c("saddlebrown", "lightgoldenrod")  # Change these to your desired colors

# Creating the cluster plot with specified fill colors, white background, and Helvetica font
autoplot(pam_result, data = transform, frame = TRUE, frame.type = 'norm') +
  theme_bw() +  # Set white background
  ggtitle("Proteomics PCA plot") +  # Add plot title
  theme(plot.title = element_text(hjust = 0.5)) +  # Center the plot title
  scale_fill_manual(values = convex_fill_colors, name = "Clusters", labels = c("SC", "KD")) +
  guides(fill = guide_legend(title = "Clusters"), color = guide_legend(title = "Sample groups", override.aes = list(shape = 16, fill = "white"))) +
  geom_point(aes(color = transform$Samplegroups)) +
  scale_color_manual(values = c(
    "SC+BSA" = "darkorange1",
    "SC+PA" = "deepskyblue",
    "SC+SS+BSA" = "black",
    "SC+SS+PA" = "red4",
    "KD+BSA" = "chartreuse4",
    "KD+PA" = "blue", 
    "KD+SS+BSA" = "darkorchid1",
    "KD+SS+PA" = "lightsalmon"),
    breaks = c("SC+BSA", "SC+PA", "SC+SS+BSA", "SC+SS+PA", "KD+BSA", "KD+PA", "KD+SS+BSA", "KD+SS+PA"),
    labels = c("SC+BSA", "SC+PA", "SC+SS+BSA", "SC+SS+PA", "KD+BSA", "KD+PA", "KD+SS+BSA", "KD+SS+PA")
  )

####################################################################################
####################################################################################
####################################################################################

# Extracting the gene names as column names
column_names <- log_data2[, 1]

# Transposing the dataframe and setting column names
transform <- t(log_data2[,-1])
colnames(transform) <- log_data$Genes


# Converting matrix to data frame
transform <- as.data.frame(transform)

#Creating another column based on treatment grouping  
transform <- transform %>%
  mutate(Samplegroups = case_when(
    grepl("control_PA", rownames(transform)) ~ "SC(Pre-starved)",
    grepl("control_SS_PA", rownames(transform)) ~ "SC(Starved)",
    grepl("KD_PA", rownames(transform)) ~ "KD(Pre-starved)",
    grepl("KD_SS_PA", rownames(transform)) ~ "KD(Starved)",
    TRUE ~ NA_character_
  )) %>%
  select(Samplegroups, everything())

#################Clustering points on PCA by similarity#######################
pca_plot <- prcomp(transform[c(-1)], scale. = TRUE)
#Performing PCA using prcomp
pca_result <- prcomp(transform[, 2:6096], scale. = TRUE)

# Accessing principal components
transform$PC1 <- pca_plot$x[, 1]
transform$PC2 <- pca_plot$x[, 2]

# Performing PAM clustering
pam_result <- pam(transform[, 2:6096], k = 2)

# Assigning cluster labels to the dataframe
transform$Cluster <- pam_result$clustering

# Specifying the fill colors for the convex hulls
convex_fill_colors <- c("#AA4611", "#CB9F18")  # Change these to your desired colors

# Creating the cluster plot with specified fill colors, white background, and Helvetica font
autoplot(pam_result, data = transform, frame = TRUE, frame.type = 'norm') +
  theme_bw() +  # Set white background
  ggtitle(" ") +  # Add plot title
  theme(plot.title = element_text(hjust = 0.5)) +  # Center the plot title
  scale_fill_manual(values = convex_fill_colors, name = "Clusters", labels = c("SC", "KD")) +
  guides(fill = guide_legend(title = "Clusters"), color = guide_legend(title = "Sample groups", override.aes = list(shape = 16, fill = "white"))) +
  geom_point(aes(color = transform$Samplegroups)) +
  scale_color_manual(values = c(
    #"SC+BSA" = "darkorange1",
    "SC(Pre-starved)" = "deepskyblue",
    #"SC+SS+BSA" = "black",
    "SC(Starved)" = "red4",
    #"KD+BSA" = "chartreuse4",
    "KD(Pre-starved)" = "blue", 
    #"KD+SS+BSA" = "darkorchid1",
    "KD(Starved)" = "lightsalmon"),
    breaks = c( "SC(Pre-starved)", "SC(Starved)", "KD(Pre-starved)", "KD(Starved)"),
    labels = c("SC(Pre-starved)", "SC(Starved)", "KD(Pre-starved)", "KD(Starved)")
  )
ggsave(filename="PCA_II.png",width=6.15,height=4.34,units="in",dpi=600)
ggsave(filename="PCA_II.pdf",width=6.15,height=4.34,units="in")
