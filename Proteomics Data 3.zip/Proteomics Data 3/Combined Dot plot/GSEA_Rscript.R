setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

dir.create("input")
dir.create("output")
dir.create("figures")

#install.packages("tidyverse")
library(tidyverse)

#install.packages("readxl")
library(readxl)

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("org.Rn.eg.db")
library(org.Rn.eg.db) # for converting rat gene IDs

BiocManager::install("clusterProfiler")
BiocManager::install("ReactomePA")
library("ReactomePA") # for Reactome
library("clusterProfiler") # for any other gene set knowledgebases

setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ##Set work directory to where this file is.
getwd()

res <- read.csv("input/SCvKD_BSA.csv")
View(res)



# GSEA ========================
columns(org.Rn.eg.db) # check the columns in the database, eg. SYMBOL, ENSEMBL, ENTREXID, UNIPROT, GENENAME.

res$entrez <- mapIds(org.Rn.eg.db, keys=res$Genes, keytype="SYMBOL", column="ENTREZID", multiVals="first")

#calculate -logPval
res$logPval <- -log10(res$adj.P.Val)

#  use p value * FC sign as rank score
genelist <- sign(res$logFC) * res$logPval

# entrez id as names of the gene list
names(genelist) <- res$entrez
genelist = sort(genelist, decreasing = TRUE)
head(genelist)

x <- na.omit(genelist) #some entrez ID are NA. remove them

## run different gene set knowledge base ------

## KEGG

gse.kegg <- gseKEGG(
  geneList=x,
  organism = "rno",
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  keyType = "kegg"
)
View(gse.kegg)
gse.kegg <- setReadable(gse.kegg, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gse.kegg.df <- as.data.frame(gse.kegg)
View(gse.kegg.df)
#write.xlsx2(gse.kegg.df, file="output/GSEA_.xlsx", sheetName = "KEGG",
#           col.names = TRUE, row.names = TRUE, append = TRUE)

## reactome

gseReactome <- gsePathway(
  geneList=x,
  organism = "rat",
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE)
gseReactome <- setReadable(gseReactome, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseReactome.df <- as.data.frame(gseReactome)
view(gseReactome.df)

#write.xlsx2(gseReactome.df, file="output/GSEA_.xlsx", sheetName = "Reactome",
#            col.names = TRUE, row.names = TRUE, append = TRUE)

## GO-BP
gseGO.bp <- gseGO(
  geneList=x,
  ont = "BP",
  OrgDb = org.Rn.eg.db,
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE,
  keyType = "ENTREZID"
)
gseGO.bp <- setReadable(gseGO.bp, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseGO.bp.df <- as.data.frame(gseGO.bp)
head(gseGO.bp.df)

#write.xlsx2(gseGO.bp.df, file="output/GSEA_.xlsx", sheetName = "GO_BP",
#            col.names = TRUE, row.names = TRUE, append = TRUE)

## GO-MF

gseGO.mf <- gseGO(
  geneList=x,
  ont = "MF",
  OrgDb = org.Rn.eg.db,
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE,
  keyType = "ENTREZID"
)
gseGO.mf <- setReadable(gseGO.mf, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseGO.mf.df <- as.data.frame(gseGO.mf)
head(gseGO.mf.df)

#write.xlsx2(gseGO.mf.df, file="output/GSEA_.xlsx", sheetName = "GO_MF",
#            col.names = TRUE, row.names = TRUE, append = TRUE)

## GO-CC

gseGO.cc <- gseGO(
  geneList=x,
  ont = "CC",
  OrgDb = org.Rn.eg.db,
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE,
  keyType = "ENTREZID"
)
gseGO.cc <- setReadable(gseGO.cc, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseGO.cc.df <- as.data.frame(gseGO.cc)
head(gseGO.cc.df)
#write.xlsx2(gseGO.cc.df, file="output/GSEA_.xlsx", sheetName = "GO_CC",
#            col.names = TRUE, row.names = TRUE, append = TRUE)

install.packages("msigdbr")
library(msigdbr)
# mSigDB Hallmark gene sets

#msigdbr_show_species()
#m_df <- msigdbr(species = "Mus musculus")
#head(m_df, 2) %>% as.data.frame

# H: hallmark gene sets
# C1: positional gene sets
# C2: curated gene sets
# C3: motif gene sets
# C4: computational gene sets
# C5: GO gene sets
# C6: oncogenic signatures
# C7: immunologic signatures

# MSigDb H: hallmark gene sets
h_t2g <- msigdbr(species = "Rattus norvegicus", category = "H") %>% 
  dplyr::select(gs_name, entrez_gene)
head(h_t2g)

gse.hallmark <- GSEA(x,
                     TERM2GENE = h_t2g,
                     minGSSize = 15,
                     maxGSSize = 500,
                     pvalueCutoff = 1)

gse.hallmark <- setReadable(gse.hallmark, OrgDb = org.Rn.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol

gse.hallmark.df <- as.data.frame(gse.hallmark)

## save GSEA spreadsheets

# Create a new Excel Workbook
install.packages("openxlsx")
library(openxlsx)

wb <- createWorkbook ()
addWorksheet(wb, "MSigDB_hallmark")
writeData(wb, "MSigDB_hallmark", gse.hallmark.df)

addWorksheet(wb, "KEGG")
writeData(wb, "KEGG", gse.kegg.df)

addWorksheet(wb, "Reactome")
writeData(wb, "Reactome", gseReactome.df)

addWorksheet(wb, "GO_BP")
writeData(wb, "GO_BP", gseGO.bp.df)

addWorksheet(wb, "GO_MF")
writeData(wb, "GO_MF", gseGO.mf.df)

addWorksheet(wb, "GO_CC")
writeData(wb, "GO_CC", gseGO.cc.df)

saveWorkbook(wb, "output/GSEA_SCvKD_BSA.xlsx", overwrite = TRUE)

# read excel sheet. we are going to be plotting dotplot based on GO_BP as it provides the most coverage

m <- read_excel("output/GSEA_SCvKD_BSA.Xlsx", sheet = "Reactome")

library(dplyr)

mf <- m %>%
  filter(m$p.adjust < 0.001)

library(ggplot2)

mf2 <- mf %>%
  filter(mf$NES > 0 | mf$NES < -2.3)

mf2 <- mf2[!grepl(",", mf2$Description),]

# Plot dot plot
p.reactome <- ggplot(mf,
                     aes(x=NES, y = fct_reorder(Description, NES))) +
  geom_point(aes(size = setSize,
                 colour = p.adjust)) +
  
  #theme_minimal()+
  
  theme_bw(base_size = 8) +
  scale_color_gradient2(#limits=c(0,5),
    midpoint = 0.004,
    low = "maroon4",
    mid = "maroon2",
    high = "hotpink1",
    space = "Lab")+
  ylab(NULL)+
  xlab("NES")+
  theme(#axis.ticks.x = element_blank(),
    panel.grid.major.y = element_line(colour = "gray", linetype = "dotted"),
    panel.grid.major.x = element_line(colour = "gray", linetype = "dotted"),
    panel.grid.minor.x = element_line(colour = "gray", linetype = "dotted"),
    axis.text.y = element_text(colour = "black", size = 8),
    axis.text.x = element_text(colour = "black", size = 10))+
  labs(color = "p.adjust", size = "count")+
  # facet_grid(. library)+
  theme(strip.background = element_rect(fill=alpha("blue", 0.2) ))+
  theme(strip.text = element_text(colour = "black"))

p.reactome

ggsave(filename = "figures/SCvKD_BSA_Reactome Dotplot.pdf", width = 25, height = 18, units = "cm")






