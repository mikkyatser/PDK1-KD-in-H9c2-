#Loading required packages
library(readxl)
library(openxlsx)
library(tidyverse)
library(ggplot2)

#Importing Files
#df1 <- read_excel("Input/GSEA_SCvKD_BSA.xlsx", sheet = "Reactome")
#df2 <- read_excel("Input/GSEA_SCvKD_BSA_SS.xlsx", sheet = "Reactome")
#df3 <- read_excel("Input/GSEA_SCvKD_PA.xlsx", sheet = "Reactome")
df4 <- read_excel("Input/GSEA_SCvKD_PA_SS.xlsx", sheet = "Reactome")

# Selecting only the columns "Description", "p.adjust" and "NES"  
#m1 <- df1[, c("Description", "p.adjust", "NES")]
#m2 <- df2[, c("Description", "p.adjust", "NES")]
#m3 <- df3[, c("Description", "p.adjust", "NES")]
m4 <- df4[, c("Description", "p.adjust", "NES","setSize")]


# Calculating the negative logarithm of the values in the "p.adjust" column
#m1$neg.log.p.adjust.B <- -log10(m1$p.adjust)
#m2$neg.log.p.adjust.BS <- -log10(m2$p.adjust)
#m3$neg.log.p.adjust.P <- -log10(m3$p.adjust)
m4$neg.log.p.adjust.PS <- -log10(m4$p.adjust)

# Exporting file
#write.xlsx(m1, "D:/Users/johnsonlab/Desktop/PDK1 proteomics project/Combined Dot Blot/Input/GSEA_SCvKD_BSA-1_m1.xlsx", sheetName = "m1", row.names = FALSE)

# Remove the "p.adjust" column from m1
#c1 <- m1[, !colnames(m1) %in% "p.adjust"]
#c2 <- m2[, !colnames(m2) %in% "p.adjust"]
#c3 <- m3[, !colnames(m3) %in% "p.adjust"]
c4 <- m4[, !colnames(m4) %in% "p.adjust"]


# Renaming the "NES" columns in each dataframe
#names(c1)[names(c1) == "NES"] <- "NES.B"
#names(c2)[names(c2) == "NES"] <- "NES.BS"
#names(c3)[names(c3) == "NES"] <- "NES.P"
names(c4)[names(c4) == "NES"] <- "NES.PS"



# Filter c1 for neg.log.p.adjust.B >= -log10(0.001)
#fc1 <- c1 %>%
#  filter(neg.log.p.adjust.B >= -log10(0.001))

# Filter c2 for neg.log.p.adjust.B >= -log10(0.001)
#fc2 <- c2 %>%
#  filter(neg.log.p.adjust.BS >= -log10(0.001))

# Filter c3 for neg.log.p.adjust.B >= -log10(0.001)
#fc3 <- c3 %>%
  #filter(neg.log.p.adjust.P >= -log10(0.001))

# Filter c4 for neg.log.p.adjust.B >= -log10(0.001)
#fc4 <- c4 %>%
  #filter(neg.log.p.adjust.PS >= -log10(0.001))



# Exporting file
#write.xlsx(fc1, "D:/Users/johnsonlab/Desktop/PDK1 proteomics project/Combined Dot Blot/Input/GSEA_SCvKD_BSA-1_c1.xlsx", sheetName = "fc1", row.names = FALSE)

# Merging the dataframes by the "Description" column
#combined_data <- merge(fc3, fc4, by = "Description", all = TRUE)
#combined_data <- merge(combined_data, fc3, by = "Description", all = TRUE)
#combined_data <- merge(combined_data, fc4, by = "Description", all = TRUE)

#combined_data[is.na(combined_data)] <- 0

# Exporting the combined_data sheet
write.xlsx(combined_data, "Output/Combined_data_PA treatments.xlsx", sheetName = "combined.input.data", rowNames = FALSE)

#Importing manipulated sheet
d2 <- read_excel("Output/Combined_data_PA treatments2.xlsx")

# Reorder Description based on NES.f
d2 <- d2 %>%
  mutate(Description = factor(Description, levels = Description[order(NES.P, decreasing = F)]))


#Plotting Dot Plot
ggplot(d2, aes(y = Description)) + 
  #geom_point(aes(size = neg.log.p.adjust.B, color = NES.B, x = "BSA")) +
  #geom_point(aes(size = neg.log.p.adjust.BS, color = NES.BS, x = "BSA+SS")) +
  geom_point(aes(size = neg.log.p.adjust.P, color = NES.P, x = "Pre-starved")) +
  geom_point(aes(size = neg.log.p.adjust.PS, color = NES.PS, x = "Starved")) +
  scale_size_continuous(range = c(1, 3)) +  
  theme_bw(base_size = 9) +
  theme(panel.grid.major = element_blank(),
        axis.text = element_text(color = "black", size = 9),
        #axis.title = element_text(family = "Helvetica"),
        legend.title = element_text(color = "black", size = 9)) +
  scale_color_gradient2(midpoint = 0, low = "skyblue2", mid = "white", high = "indianred", space = "Lab") +
  ylab(NULL) +
  xlab(NULL) +
  scale_x_discrete(limits = c("Pre-starved", "Starved")) +
  #geom_vline(xintercept = c(2.5, 4.5), linetype = "dashed", colour = "grey", size = 1) +
  theme(axis.ticks.x = element_blank()) +
  labs(color = "NES", size = "-log10(p.adjust)")

ggsave(filename="combined_dotplot_PA treatments.png",width=8,height=6,units="in",dpi=600)
ggsave(filename="combined_dotplot_PA treatments.pdf",width=8,height=6,units="in")






#####################################################################################
#Loading required packages
library(readxl)
install.packages("openxlsx")
library(openxlsx)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(forcats)
library(scales)


df4 <- read_excel("Input/GSEA_SCvKD_PA_SS.xlsx", sheet = "Reactome")
m1 <- df4 %>% filter(p.adjust < 0.01)
write.csv(m1, "Output/scvKD_PA_SS reactome.csv")
#Importing Files
reactome <- read.csv("Input/reactome.2.csv")
reactome <- reactome[,-1]
reactome$`-log.p.adjust` <- -log(reactome$p.adjust)

#plotting the graph
reactome_2f <- ggplot(reactome, aes(x = NES, y = fct_reorder(Description, NES))) +
  geom_point(aes(size = setSize, color = `-log.p.adjust`)) + 
  theme_bw(base_size = 16) + 
  scale_size_continuous(range = c(2, 6)) + 
  scale_color_gradient2(
    low = "gold4", 
    mid = "darkgoldenrod2", 
    high = "green3", 
    midpoint = 1.3,   # Set midpoint to 1.3
    limits = c(1.3, max(reactome$`-log.p.adjust`)),  # Set color scale limits
    breaks = seq(1.3, max(reactome$`-log.p.adjust`), length.out = 3),  # Set breaks for the legend
    labels = label_number(accuracy = 0.1)  # Round legend labels to one decimal place
  ) + 
  ylab(NULL) + 
  xlab("NES") + 
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(color = "black", size = 10),
    axis.text.x = element_text(color = "black", size = 12),
    strip.background = element_rect(fill = alpha("blue", 0.2)),
    strip.text = element_text(color = "black")
  ) +
  labs(color = "Log P.Val", size = "Count")

# Print the plot
print(reactome_2f)

ggsave(filename="dot plot_PA + ss.pdf",width=7.05,height=7.21,units="in")
ggsave(filename="dot plot_PA + ss.svg",width=7.05,height=7.21,units="in")
