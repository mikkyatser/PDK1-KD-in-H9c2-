library(tidyverse)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(gridtext)
install.packages("ComplexUpset")
library(ComplexUpset)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

dir.create("input")
dir.create("output")
dir.create("figures")

m1 <- read.csv("Input/SCvKD_BSA.csv")
m2 <- read.csv("Input/SCvKD_SS_BSA.csv")
m3 <- read.csv("Input/SCvKD_PA.csv")
m4 <- read.csv("Input/SCvKD_SS_PA.csv")

temp<- m1[c(1,2,3,7)]
temp2<-m2[c(1,2,3,7)]
temp3<-m3[c(1,2,3,7)]
temp4<-m4[c(1,2,3,7)]

tempA<-full_join(temp,temp2)
tempA<-full_join(tempA,temp3)
tempA<-full_join(tempA,temp4)


# filter to remove unresolved protein isomers
tempB <- tempA[!grepl(";", tempA$Protein.Group), ]



# For each comparison, added a column to label the significance as TRUE or FALSE. 

tempB$"SC v KD (BSA)" <- ifelse(tempB$adj.P.Val.BSA <0.05, "TRUE", "FALSE")
tempB$"SC v KD (Pre-starved)" <- ifelse(tempB$adj.P.Val.PA <0.05, "TRUE", "FALSE")
tempB$"SC v KD (BSA+SS)" <- ifelse(tempB$adj.P.Val.SS.BSA <0.05, "TRUE", "FALSE")
tempB$"SC v KD (Starved)" <- ifelse(tempB$adj.P.Val.SS.PA <0.05, "TRUE", "FALSE")

# call out the intersected proteins
#tempB <- Upset_Plot_Sc_v_KD_I

#mf <- tempB %>%
  #filter(tempB$`SC v KD (BSA+SS)` == "TRUE",tempB$`SC v KD (PA+SS)` == "TRUE")

#mf2 <- mf %>%
  #filter({mf$`SC v KD (BSA)`} == {mf$`SC v KD (PA)`})

#write.csv(mf2, "output/Intersected proteins in all conditions and SS only.CSV")

# For each comparison, added a column to label the directions of change as Up, Down, or NS.

tempB$SC.KD_BSA.direction <- ifelse(!tempB$adj.P.Val.BSA <0.05, 
                                          "NS",
                                          ifelse(tempB$logFC.BSA >0,
                                                 "Up", "Down"))
tempB$SC.KD_PA.direction <- ifelse(!tempB$adj.P.Val.PA <0.05,
                                          "NS",
                                          ifelse(tempB$logFC.PA >0,
                                                 "Up", "Down"))
tempB$SC.KD_BSA_SS.direction <- ifelse(!tempB$adj.P.Val.SS.BSA <0.05,
                                          "NS",
                                          ifelse(tempB$logFC.SS.BSA >0,
                                                 "Up", "Down"))
tempB$SC.KD_PA_SS.direction <- ifelse(!tempB$adj.P.Val.SS.PA <0.05,
                                          "NS",
                                          ifelse(tempB$logFC.SS.PA >0, 
                                                 "Up", "Down"))
#select only PA treatments for poster
tempc <- tempB[c(1,2,7,8,9,10,12,14,16,18)]

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

tempB$Intersect_direction <- ifelse(rowSums(tempB[, c(15:18)] =="Down", na.rm = TRUE) == rowSums(!tempB[, c(15:18)] == "NS"), 
                                              "Down", 
                                              ifelse(rowSums(tempB[, c(15:18)] =="Up", na.rm = TRUE) == rowSums(!tempB[, c(15:18)] == "NS"), "Up", "Different direction"))

# Make the overall direction factors. And their levels should be in the order of Up, Down, Different direction. So later on, this order will be maintained in figure legend.

tempB$Intersect_direction <- factor(tempB$Intersect_direction, 
                                              levels = c("Up","Different direction","Down"))

write.csv(tempB, "output/Upset Plot Sc v KD_I.CSV")




# Plot UpSet

SCvKD <- colnames(tempB)[11:14]

upset(tempB, SCvKD, name='', width_ratio=0.3,
      height_ratio=0.5, min_size=1,min_degree=1,
      
      base_annotations = list(
        'Intersection size'=(
          intersection_size(#mapping=aes(fill=Intersect_direction)
          )
          #+ scale_fill_manual(values=c("tomato","cornflowerblue","grey"))
          
          + theme(axis.title.y = element_text(margin = margin(r = -120)),
                  legend.title = element_blank(),
                  panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank())
        )
      ),
      
      annotations = list(
        'Direction'=(
          ggplot(mapping=aes(fill=Intersect_direction))
          + geom_bar(stat='count', position='fill')
          + scale_y_continuous(labels=scales::percent_format())
          + scale_fill_manual(values=c("indianred3","black","skyblue2"))
          + ylab('Direction')
          + theme(axis.title.y = element_text(margin = margin(r = 9.8)),
                  legend.title = element_blank(),
                  legend.position = "right",
                  aspect.ratio=0.22/1,
                  panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank())
        )
      ),
      set_sizes=(
        upset_set_size()
        + ylab('DE proteins')
        + geom_text(aes(label=..count..), hjust=1.1, stat='count')
        + expand_limits(y=3000)
        + theme(axis.title.x = element_text(margin = margin(t = -15)),
                axis.text.x=element_blank(),
                panel.grid.major = element_blank(),
                panel.grid.minor = element_blank())
      ),
      stripes = c("white")
) + 
  theme(panel.grid = element_blank(),
        text = element_text(size=12))+
  
  patchwork::plot_layout(heights=c(0.5, 1, 0.5))

ggsave(filename="upset_I.png",width=9,height=4,units="in",dpi=600)

#######################################################################################
#######################################################################################
#######################################################################################

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

tempc$Intersect_direction <- ifelse(rowSums(tempc[, c(9:10)] =="Down", na.rm = TRUE) == rowSums(!tempc[, c(9:10)] == "NS"), 
                                    "Down", 
                                    ifelse(rowSums(tempc[, c(9:10)] =="Up", na.rm = TRUE) == rowSums(!tempc[, c(9:10)] == "NS"), "Up", "Different direction"))

# Make the overall direction factors. And their levels should be in the order of Up, Down, Different direction. So later on, this order will be maintained in figure legend.

tempc$Intersect_direction <- factor(tempc$Intersect_direction, 
                                    levels = c("Up","Different direction","Down"))

write.csv(tempc, "output/Upset Plot Sc v KD_PA treatments only.CSV")


# Plot UpSet

SCvKD <- colnames(tempc)[7:8]

upset(tempc, SCvKD, name='', width_ratio=0.65,
      height_ratio=0.5, min_size=1,min_degree=1,
      
      base_annotations = list(
        'Intersection size'=(
          intersection_size(#mapping=aes(fill=Intersect_direction)
          )
          #+ scale_fill_manual(values=c("tomato","cornflowerblue","grey"))
         
          + theme(axis.title.y = element_text(margin = margin(r = 0)),
                  legend.title = element_blank(),
                  panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank())
        )
      ),
      
      annotations = list(
        'Direction'=(
          ggplot(mapping=aes(fill=Intersect_direction))
          + geom_bar(stat='count', position='fill')
          + scale_y_continuous(labels=scales::percent_format())
          + scale_fill_manual(values=c("indianred3","black","skyblue2"))
          + ylab('Direction')
          + theme(axis.title.y = element_text(margin = margin(r = 0)),
                  legend.title = element_blank(),
                  legend.position = "right",
                  #aspect.ratio=0.5/1,
                  panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank())
        )
      ),
      set_sizes=(
        upset_set_size()
        + labs(y = 'DE proteins')
        + geom_text(aes(label=..count..), hjust=1.1, stat='count')
        + expand_limits(y=5000)
        + theme(axis.title.x = element_text(angle = 0, hjust = 0.9, margin = margin(r = 20)),
                axis.text.x=element_blank(),
                panel.grid.major = element_blank(),
                panel.grid.minor = element_blank())
      ),
      stripes = c("white")
) + 
  theme(panel.grid = element_blank(),
        text = element_text(size=12))+
  
  patchwork::plot_layout(heights=c(0.5, 1, 0.5))

ggsave(filename="upset_II.png",width=6.14,height=4.21,units="in",dpi=600)
ggsave(filename="upset_II.pdf",width=6.14,height=4.21,units="in")



