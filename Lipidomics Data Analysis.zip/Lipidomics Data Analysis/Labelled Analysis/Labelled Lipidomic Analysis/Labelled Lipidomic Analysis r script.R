library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)



dat <- read.csv("Input/Peak Area.csv", check.names = F)
IS <- read_excel("Input/IS normalization factor.xlsx")
prot <- read_excel("Input/Protein Normalization factor.xlsx")


dat_tg <- dat %>%
  filter(Ontology == "TG")

dat_dg <- dat %>%
  filter(Ontology == "DG")

dat_ce <- dat %>%
  filter(Ontology == "CE")

IS_tg <- IS %>%
  filter(Molecule == "TG")

IS_dg <- IS %>%
  filter(Molecule == "DG")

IS_ce <- IS %>%
  filter(Molecule == "CE")


IS_tg <- IS_tg[,-1]
#add missing columns to IS_tg
missing_cols_in_IS <- setdiff(names(dat_tg), names(IS_tg))
IS_tg[missing_cols_in_IS] <- NA

#rowbind the two dataframes
norm_tg <- rbind(IS_tg, dat_tg)
#multiply raw values by IS normalization factor to normalize
norm_tg <- norm_tg %>%
  mutate(across(-c(25:30), ~ .*first(.)))
norm_tg <- norm_tg[-1,]

IS_dg <- IS_dg[,-1]
#add missing columns to IS_dg
missing_cols_in_IS <- setdiff(names(dat_dg), names(IS_dg))
IS_dg[missing_cols_in_IS] <- NA

#rowbind the two dataframes
norm_dg <- rbind(IS_dg, dat_dg)
#multiply raw values by IS normalization factor to normalize
norm_dg <- norm_dg %>%
  mutate(across(-c(25:30), ~ .*first(.)))
norm_dg <- norm_dg[-1,]


IS_ce <- IS_ce[,-1]
#add missing columns to IS_dg
missing_cols_in_IS <- setdiff(names(dat_ce), names(IS_ce))
IS_ce[missing_cols_in_IS] <- NA

#rowbind the two dataframes
norm_ce <- rbind(IS_ce, dat_ce)
#multiply raw values by IS normalization factor to normalize
norm_ce <- norm_ce %>%
  mutate(across(-c(25:30), ~ .*first(.)))
norm_ce <- norm_ce[-1,]

#row bind IS normalized values
norm <- rbind(norm_ce, norm_dg)
norm <- rbind(norm, norm_tg)
write.csv(norm, "Output/NormalizedArea.csv")


#protein normalization
prot <- prot[-1,-1]

#add missing columns to prot
missing_cols_in_prot <- setdiff(names(norm), names(prot))
prot[missing_cols_in_prot] <- NA
#add missing columns to norm
missing_cols_in_norm <- setdiff(names(prot), names(norm))
norm[missing_cols_in_norm] <- NA

#rowbind the two dataframes
lipid5 <- rbind(prot, norm)

#protein normalization
lipid5 <- lipid5 %>%
  mutate(across(-c(49:54), ~ ./first(.)))
lipid5 <- lipid5[-1,]

#remove columns with NA values
lipid6 <- lipid5[, colSums(is.na(lipid5)) == 0]

lipid6 <- lipid6[c(25:30, 1,5,9,2,6,10,3,7,11,4,8,12,13,17,21,14,18,22,15,19,23,16,20,24)]
write.csv(lipid6, "Output/IS normalized labelled lipidomics.csv")

#convert to log2
mf2<- lipid6 %>%
  mutate(across(-c(1:6), ~ifelse(.> 0, log2(.),NA)))
write.csv(mf2, "Output/Log2 IS normalized labelled lipidomics.csv")






#Create a list of lipids that have been annotated to the molecular specie in the paralleld unlabelled experiment
pos <- read_csv("Input/Peak intensity_positive mode.csv")
neg <- read_csv("Input/Peak intensity_negative mode.csv")
unlab <- read_csv("Input/Log2 transformed Lipid Data.csv")

#pos processing
pos <- pos[c(4,2,10)]
pos <- pos[-(1:3),]
colnames(pos) <- pos[1, ]
pos <- pos[-1,]

#neg processing
neg <- neg[c(4,2,10)]
neg <- neg[-(1:3),]
colnames(neg) <- neg[1, ]
neg <- neg[-1,]

#select lipids that contain a 16C fatty acid chain
unlab_1 <- unlab[grepl("16", unlab$"Metabolite name"), ]
unlab_1 <- unlab_1[c(2)]

#filter pos and neg for suitable lipids
lib_pos <- pos[pos$`Metabolite name` %in% unlab_1$`Metabolite name`, ]
lib_neg <- neg[neg$`Metabolite name` %in% unlab_1$`Metabolite name`, ]

write.csv(lib_pos, "Output/Target library_pos.csv", row.names = F)
write.csv(lib_neg, "Output/Target library_neg.csv", row.names = F)
################################################################################
m1 <- read_excel("Input/TIC normalized_Identified isotopes.xlsx")

#calculate standard deviation across all samples
m_sd <- function(df) {
  df %>%
    rowwise() %>%
    mutate(sd_across = sd(across(starts_with("Lenti"))))
}
mf <- m_sd(m1)

#filter duplicates by lowest standard deviation across all samples
column_to_filter <- mf$`Metabolite name`
column_to_select <- mf$sd_across

mf2 <- mf %>%
  group_by({{column_to_filter}}) %>%
  arrange({{column_to_select}}) %>%
  slice_head(n = 1) %>%
  ungroup ()


#convert to log2 scale
m2 <- mf2 %>%
  mutate(log2(across(starts_with("Lenti"))))
m2 <- m2[c(1:6,19:30,7:18)]

colnames(m2) <- c(
  "Metabolite name","Expected_RT", "Expected_MZ","Isotope",  "Detected_Rt(min)", "Detected_Mz",
  "SC_0_1", "SC_0_2", "SC_0_3", "SC_1_1", "SC_1_2", "SC_1_3",
  "SC_2_1", "SC_2_2", "SC_2_3", "SC_3_1", "SC_3_2", "SC_3_3",
  "KD_0_1", "KD_0_2", "KD_0_3", "KD_1_1", "KD_1_2", "KD_1_3",
  "KD_2_1", "KD_2_2", "KD_2_3", "KD_3_1", "KD_3_2", "KD_3_3"
)

m2$MZ_error <- m2$Expected_MZ - m2$Detected_Mz
m2$RT_error <- m2$Expected_RT - m2$`Detected_Rt(min)`

#Set a min RT_error of 0.01
m2 <- m2 %>% filter(RT_error < 0.01)

#clean up lipid names
# Function to remove characters preceding and including "|" and add parentheses
remove_prefix_add_parentheses <- function(x) {
  # Remove prefix if "|" is present
  x <- gsub(".*\\|", "", x)
  # Add parentheses without a space after the first space and closing parenthesis at the end
  x <- paste0(gsub(" ", "(", x, fixed = TRUE), ")")
  return(x)
}
# Apply the function to the specified column
m2$`Metabolite name` <- sapply(m2$`Metabolite name`, remove_prefix_add_parentheses)
write.csv(m2, "Output/Log2 TIC normalized_Identified isotopes.csv", row.names = F)

#################### LINEX2

#Uniformly labelled lipids
uni <- read.csv("Input/Log2 TIC normalized_uniformly labelled isotopes.csv", check.names = F)
uni<- uni[c(1,7:30)]

m3<- m2[c(1,7:30)]
m2.1 <- m2[c(1)]

#export lipid names and convert to lipidlynxX nomenclature
write.csv(m2.1, "Output/lipid names for lipidlynxX.csv", row.names = F)

lynx <- read_excel("Input/LipidLynxX-Converter-20231231-193555-d6f8.xlsx")
lynx_f <- merge(lynx, m3, by = "Metabolite name", all.x = TRUE)
lynx_uni <- merge(uni,lynx, by = "Metabolite name", all.x = TRUE)
lynx <- lynx[,-1]
lynx_uni <- lynx_uni[,-1]

# Change the data into long format where metabolites become columns
lynx_long <- lynx_f %>%
  pivot_longer(cols = -Lipid, names_to = c("CellLine", "Time", "Replicate"), 
               names_sep = "_", values_to = "Abundance") %>%
  separate(CellLine, into = c("CellLine", "ID"), sep = 7) %>%
  mutate(Time = as.numeric(Time),
         Replicate = as.numeric(Replicate)) %>%
  dplyr::select(Subject = ID, CellLine, Time, Replicate, Lipid, Abundance) %>%
  spread(key = Lipid, value = Abundance) %>%
  dplyr::select(-Subject)


#filter all time 0 = non-starved
lynx.0<- lynx_long %>% filter(Time == 0)
lynx.0 <- lynx.0 %>%
  arrange(desc(CellLine))
#filter all time 3 = starved
lynx.3 <- lynx_long %>% filter(Time == 3)
lynx.3 <- lynx.3 %>%
  arrange(desc(CellLine))



# Change the data into long format where metabolites become columns
lynx_uni_long <- lynx_uni %>%
  pivot_longer(cols = -Lipid, names_to = c("CellLine", "Time", "Replicate"), 
               names_sep = "_", values_to = "Abundance") %>%
  separate(CellLine, into = c("CellLine", "ID"), sep = 7) %>%
  mutate(Time = as.numeric(Time),
         Replicate = as.numeric(Replicate)) %>%
  dplyr::select(Subject = ID, CellLine, Time, Replicate, Lipid, Abundance) %>%
  spread(key = Lipid, value = Abundance) %>%
  dplyr::select(-Subject)


#filter all time 0 = non-starved
lynx_uni.0<- lynx_uni_long %>% filter(Time == 0)
lynx_uni.0 <- lynx_uni.0 %>%
  arrange(desc(CellLine))
#filter all time 3 = starved
lynx_uni.3 <- lynx_uni_long %>% filter(Time == 3)
lynx_uni.3 <- lynx_uni.3 %>%
  arrange(desc(CellLine))

write.csv(lynx_uni_long, "Output/13CU_lipid_data.csv", row.names = F)
write.csv(lynx_uni.0, "Output/13CU_lipid_data_unstarved.csv", row.names = F)
write.csv(lynx_uni.3, "Output/13CU_lipid_data_starved.csv", row.names = F)



################################################################################
################################################################################
#Linear Model and Trend Relationship
data <- read.csv("Output/13CU_lipid_data.csv", check.names = F)
sc <- filter(data, CellLine == "SC")
kd <- filter(data, CellLine == "KD")


#LM for SC cellLine
i=1
input=sc
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ Time")
    model_sc <- lm(formula, data = input) 
    s <- summary(model_sc)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(s$coefficients)
    fixed_est <- fixed_df[1:2,1]
    fixed_SE <- fixed_df[1:2,2]
    fixed_p <- fixed_df[1:2,4]
    df_coef <- df.residual(model_sc)
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model_sc))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:2, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model_sc)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model_sc)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model_sc)$r.squared
    f_statistic <- summary(model_sc)$fstatistic[1]
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 df_coef,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_SC","SC_slope", 
                           "SE_Basal_SC", "SE_SC_slope",
                           "p_Basal_SC",  "p_SC_slope",
                           "df",
                           "95%CI_Basal_SC",  "95%CI_SC_slope",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                           "Multiplel_r.sq")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_SC = p.adjust(p_Basal_SC, method = "fdr"),
           p.adj_SC_slope = p.adjust(p_SC_slope, method = "fdr"))
  
  return(output.df)
}


# calculate lme using the created function
output.sc <- calculate_lm(sc)
write.csv(output.sc, "Output/LM SC 13CU_Lipids.csv", row.names = T)



# LM for KD CellLine
i=1
input=kd
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ Time")
    model_kd <- lm(formula, data = input) 
    k <- summary(model_kd)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(k$coefficients)
    fixed_est <- fixed_df[1:2,1]
    fixed_SE <- fixed_df[1:2,2]
    fixed_p <- fixed_df[1:2,4]
    df_coef <- df.residual(model_kd)
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model_kd))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:2, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model_kd)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model_kd)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model_kd)$r.squared
    f_statistic <- summary(model_kd)$fstatistic[1]
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 df_coef,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_KD","KD_slope", 
                           "SE_Basal_KD", "SE_KD_slope",
                           "p_Basal_KD",  "p_KD_slope",
                           "df",
                           "95%CI_Basal_KD",  "95%CI_KD_slope",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                           "Multiplel_r.sq")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_KD = p.adjust(p_Basal_KD, method = "fdr"),
           p.adj_KD_slope = p.adjust(p_KD_slope, method = "fdr"))
  
  return(output.df)
}
# calculate lm using the created function
output.kd <- calculate_lm(kd)
write.csv(output.kd, "Output/LM KD 13CU_Lipids.csv", row.names = T)


output.kd1 <- output.kd [,2:17]
rownames(output.kd1) <- output.kd$metabolites
output.kd2 <- output.kd1 [c(2,4,7)]
output.kd2 <- as.data.frame(lapply(output.kd2, as.numeric))
rownames(output.kd2) <- output.kd$metabolites


output.sc1 <- output.sc [,2:17]
rownames(output.sc1) <- output.sc$metabolites
output.sc2 <- output.sc1 [c(2,4,7)]
output.sc2 <- as.data.frame(lapply(output.sc2, as.numeric))
rownames(output.sc2) <- output.sc$metabolites


# Custom t-test function using standard errors and degrees of freedom
t_test_custom <- function(mean1, se1, df1, mean2, se2, df2, alternative = 'two.sided') {
  # Calculate pooled standard error
  pooled_se <- sqrt((se1^2 / df1) + (se2^2 / df2))
  # Calculate t-value
  t_value <- (mean1 - mean2) / pooled_se
  # Calculate degrees of freedom
  df_total <- df1 + df2
  # Calculate p-value
  p_value <- 2 * pt(abs(t_value), df_total, lower.tail = FALSE)
  # Return the results
  return(list(
    p_value = p_value
  ))
}


result <- t_test_custom(output.sc2$SC_slope, output.sc2$SE_SC_slope, output.sc2$df, output.kd2$KD_slope, output.kd2$SE_KD_slope, output.kd2$df)
result_table <- as.data.frame(result)
rownames(result_table) <- output.kd$metabolites
adjusted_p_values <- as.data.frame(p.adjust(result_table$p_value, method = "BH"))
rownames(adjusted_p_values) <- output.kd$metabolites

# Add a column with row names to each data frame
output.sc2$metabolites <- rownames(output.sc2)
output.kd2$metabolites <- rownames(output.kd2)
adjusted_p_values$metabolites <- rownames(adjusted_p_values)
result_table$metabolites <- rownames(result_table)

merged_stats <- merge(merge(merge(output.sc2, output.kd2, by = "metabolites", all = TRUE), result_table, by = "metabolites", all = TRUE), adjusted_p_values, by = "metabolites", all = TRUE)
colnames(merged_stats) <- c("metabolites",
                            "SC_slope",
                            "SE_SC_slope",
                            "df",
                            "KD_slope",
                            "SE_KD_slope",
                            "df",
                            "p-value SC v KD",
                            "p.adj BH meth")
merged_stats <- merged_stats[c(1,2,3,5,6,8,9)]

write.csv(merged_stats, "Output/13CU_Fixed Time estimates stats (SC v KD).csv", row.names = T)

########################trend relationship######################################

#find difference between slopes
merged_stats$slope_diff <- (abs(merged_stats$KD_slope) - abs(merged_stats$SC_slope))

# Assuming your data frame is named 'trend'
merged_stats$SC_slope <- round(merged_stats$SC_slope, 2)
merged_stats$KD_slope <- round(merged_stats$KD_slope, 2)

# Assuming your data frame is named 'your_data' and the column you want to transform is 'your_column'
merged_stats$logP.adj <- -log10(merged_stats$`p.adj BH meth`)


# For each cell line, added a column to label the directions of change as Up, Down, or NS.
merged_stats$SC_slope.direction <- ifelse(merged_stats$SC_slope>0,"Up", "Down")
merged_stats$KD_slope.direction <- ifelse(merged_stats$KD_slope>0,"Up", "Down")

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"
merged_stats$Intersect_direction <- ifelse(merged_stats[, 10] == merged_stats[, 11], 
                                           ifelse(merged_stats[, 10] == "Down", "Down", "Up"), 
                                           "Different direction")

#plot quadrant plot
quandrant_plot <- ggplot(merged_stats, aes(SC_slope, KD_slope, size = logP.adj, color = ifelse(`p.adj BH meth` > 0.05, "grey", ifelse(Intersect_direction == "Different direction", "black", ifelse(slope_diff > 0, "indianred3", "deepskyblue3"))))) +
  geom_point(show.legend = TRUE) +
  scale_color_manual(
    values = c("indianred3" = "indianred3", "deepskyblue3" = "deepskyblue3", "black" = "black"),
    breaks = c("indianred3", "deepskyblue3", "black"),
    labels = c("Higher rate in KD", "Lower rate in KD", "Different Direction"),
    name = " "
  ) +
  scale_size_continuous(range = c(0.1, 3), name = "logP.adj") +
  theme_minimal() +
  labs(title = " ", x = expression(paste(italic(m[SC]))),
       y = expression(paste(italic(m[KD])))) +
  geom_hline(yintercept = 0, color = "black") +
  geom_vline(xintercept = 0, color = "black") +
  scale_x_continuous(limits = c(-0.7, 0.7), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
  scale_y_continuous(limits = c(-0.6, 0.6), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
  theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 0.25))

# Add labels with random arrangement to minimize overlap
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = merged_stats,
    aes(label = metabolites),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 2.5,
    show.legend = FALSE
  )
print(quandrant_plot)
################################################################################
################################################################################
#Limma and Volcano plot
library(limma)

exprs <- read.csv("Input/Log2 TIC normalized_uniformly labelled isotopes copy.csv") #expression data
exprs <- na.omit(exprs)
sample_info <- read.csv("Input/TIC normalized lipid metadata.csv", header = TRUE, row.names = 1) #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make time a categorical variable
sample_info$Time <- factor(sample_info$Time, levels=c("0","1","2", "3")) 
levels(sample_info$Time)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Time, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  CellLineKD_Time0 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "0"),
  CellLineKD_Time1 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "1"),
  CellLineKD_Time2 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "2"),
  CellLineKD_Time3 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "3"),
  CellLineSC_Time0 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "0"),
  CellLineSC_Time1 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "1"),
  CellLineSC_Time2 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "2"),
  CellLineSC_Time3 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "3")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  CellLineKD_Time1 - CellLineSC_Time1,
  CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/13CU_Limma lipid classes_starvation time points.csv", row.names = F)
########################### Volcano plot ########################################
unstarved <- read.csv("Output/13CU_Limma lipid classes_Pre starvation(time 0).csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(unstarved$logFC), max(unstarved$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(unstarved, aes(x = logFC, y = -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "black") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
  labs(title = "KD v SC (pre-starved)", x = "logFC", y = "-log10(adj.P.Val)") +
  theme(legend.position = "none", 
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),      
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
        plot.title = element_text(hjust = 0.5))
# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_logFC, max_abs_logFC))

# label dots with lowest p-val and highest positive logFC
label_points <- unstarved %>%
  arrange(desc(logFC), adj.P.Val) %>%
  filter(adj.P.Val < 0.05) 

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = label_points,
    aes(label = Metabolite.name),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 3,
    show.legend = FALSE
  )

# Print the plot
print(volcano_plot)

#starved
starved <- read.csv("Output/13CU_Limma lipid classes_starvation time points.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(starved$logFC), max(starved$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(starved, aes(x = logFC, y = -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "black") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
  labs(title = "KD v SC (starved)", x = "logFC", y = "-log10(adj.P.Val)") +
  theme(legend.position = "none", 
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),      
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
        plot.title = element_text(hjust = 0.5))
# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_logFC, max_abs_logFC))

# label dots with lowest p-val and highest positive logFC
label_points <- starved %>%
  arrange(desc(logFC), adj.P.Val) %>%
  filter(adj.P.Val < 0.05) 

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = label_points,
    aes(label = Metabolite.name),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 3,
    show.legend = FALSE
  )

# Print the plot
print(volcano_plot)
################################################################################
################################################################################
#Lipid Molecular Species at Time =0
prof <- read.csv("Output/13CU_lipid_data.csv", check.names = F) #log data
#pivot all lipids into a single column
prof_long <- prof %>%
  pivot_longer(cols = 4:30, names_to = "Metabolite.name", values_to = "value")

#filter all time 0 = non-starved
prof_long<- prof_long %>% filter(Time == 0)
prof_long.log <- prof_long
#find the antilog for plotting
prof_long$value <- (2^prof_long$value)


###########Calculate t test
# Create an empty data frame to store the t-test results
t_test_results <- data.frame()

# Unique ontologies in the data frame
lipids <- unique(prof_long.log$Metabolite.name)

# Loop through each lipid specie and perform t-test
for (lipid in lipids) {
  kd_data <- subset(prof_long.log, CellLine == "KD" & Metabolite.name == lipid)$value
  sc_data <- subset(prof_long.log, CellLine == "SC" & Metabolite.name == lipid)$value
  
  # Perform t-test
  t_test_result <- t.test(kd_data, sc_data)
  
  # Store the results in the data frame
  result_row <- data.frame(Metabolite.name = lipid,
                           t_statistic = t_test_result$statistic,
                           p_value = t_test_result$p.value)
  
  t_test_results <- rbind(t_test_results, result_row)
}

# Perform FDR correction
t_test_results$fdr <- p.adjust(t_test_results$p_value, method = "fdr")

# Calculate the sum for each combination of Time, CellLine, and Ontology
mean_prof <- prof_long %>%
  group_by(CellLine, Metabolite.name) %>%
  summarize(AvgIntensity = mean(value),
            SEM = sd(value) / sqrt(length(value)))
# Merge the data
mean_prof <- merge(mean_prof, t_test_results, by = "Metabolite.name")

#make SC the reference factor
mean_prof$CellLine <- factor(mean_prof$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
mean_prof$label <- ifelse(mean_prof$fdr < 0.001 & mean_prof$CellLine == "KD", '***',
                          ifelse(mean_prof$fdr < 0.01 & mean_prof$CellLine == "KD", '**',
                                 ifelse(mean_prof$fdr < 0.05 & mean_prof$CellLine == "KD", '*', '')))
write.csv(mean_prof, "Output/13CU_lipid species profile stat_unstarved.csv", row.names = F)


# Reorder lipids variable based on average intensity within each CellLine
mean_prof <- mean_prof %>%
  arrange(CellLine, desc(AvgIntensity))

# Convert Metabolite.name to a factor with levels ordered by the new order
mean_prof$Metabolite.name <- factor(mean_prof$Metabolite.name, levels = unique(mean_prof$Metabolite.name))

# Plot the data (rest of the code remains unchanged)
ggplot(mean_prof, aes(x = Metabolite.name, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = AvgIntensity+ SEM + 0.5), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = "13C-u Lipid Species Profile",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 7.25, vjust = 1.08, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 40)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))



#################################################################################
#TG isotopes alone (isotopologues)
m1 <- read_excel("Input/TIC normalized_Identified isotopes_TG.xlsx")

#convert to log2 scale
m2 <- m1 %>%
  mutate(log2(across(starts_with("Lenti"))))
m2 <- m2 %>%
  arrange((`Metabolite name`))
m2 <- m2[c(1:6,19:30,7:18)]

colnames(m2) <- c(
  "Metabolite name", "Isotope", "Expected_MZ", "Expected_RT", "Detected_Rt(min)", "Detected_Mz",
  "SC_0_1", "SC_0_2", "SC_0_3", "SC_1_1", "SC_1_2", "SC_1_3",
  "SC_2_1", "SC_2_2", "SC_2_3", "SC_3_1", "SC_3_2", "SC_3_3",
  "KD_0_1", "KD_0_2", "KD_0_3", "KD_1_1", "KD_1_2", "KD_1_3",
  "KD_2_1", "KD_2_2", "KD_2_3", "KD_3_1", "KD_3_2", "KD_3_3"
)

m2$MZ_error <- m2$Expected_MZ - m2$Detected_Mz
m2$RT_error <- m2$Expected_RT - m2$`Detected_Rt(min)`

write.csv(m2, "Output/Log2 TIC normalized_Identified isotopes_TG.csv", row.names = F)
#################################################################################
#################################################################################
#################### LipidONE
#Uniformly labelled lipids
ats <- read.csv("Input/Log2 TIC normalized_uniformly labelled isotopes.csv", check.names = F)
#call out relevant columns
ats <- ats[c(1,7:30)]
k <- read_excel("Input/LipidLynxX-shorthand_lipidOne.xlsx")
#cnvert to antilog
ats <- ats[ats$`Metabolite name` %in% k$`Metabolite name`, ]
ats[, -1] <- 2 ^ ats[, -1]
#merge files to get shorthand notation
lone <- merge(ats, k, by = "Metabolite name", all.x = TRUE)
lone <- lone[c(26,2:25)]

#unstarved samples
lone.0 <- lone[c(1,2:4,14:16)]

#3H starved samples
lone.3 <- lone[c(1,11:13,23:25)]

write.csv(lone.0, "Output/13CU_lipid_data_unstarved_Lone.csv", row.names = F)
write.csv(lone.3, "Output/13CU_lipid_data_starved_Lone.csv", row.names = F)
################################################################################
###############################plotting figures#################################
lip.prof <- read.csv("Input/lipid_profile.csv")
# make long format
lip.prof_long <- tidyr::gather(lip.prof, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
lip.prof_long <- lip.prof_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
lip.prof_long <- lip.prof_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
lip.prof_long$CellLine <- factor(lip.prof_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
lip.prof_long$label <- ifelse(lip.prof_long$P.value < 0.001 & lip.prof_long$CellLine == "KD", '***',
                                ifelse(lip.prof_long$P.value < 0.01 & lip.prof_long$CellLine == "KD", '**',
                                       ifelse(lip.prof_long$P.value < 0.05 & lip.prof_long$CellLine == "KD", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(lip.prof_long, aes(x= as.factor(Classes), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value +SEM + 2), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = "13C-U-Lipid class profile",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 60)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

###############################chain unsat#######################################
unsat <- read.csv("Input/chain unsat.csv")
# make long format
unsat_long <- tidyr::gather(unsat, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
unsat_long <- unsat_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
unsat_long <- unsat_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
unsat_long$CellLine <- factor(unsat_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
unsat_long$label <- ifelse(unsat_long$P.value < 0.001 & unsat_long$CellLine == "KD", '***',
                           ifelse(unsat_long$P.value < 0.01 & unsat_long$CellLine == "KD", '**',
                                  ifelse(unsat_long$P.value < 0.05 & unsat_long$CellLine == "KD", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(unsat_long, aes(x= as.factor(Unsaturations), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + SEM + 1), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = "13C-U-Class Unsaturation",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 100)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

####################Ether/Ester linked ratio####################################
Eth <- read.csv("Input/Ether_Ester linkage ratio.csv")
#remove na values
Eth <- subset(Eth, SC != 0)
#make P-val col numeric
Eth$P.value <- as.numeric(Eth$P.value)
# make long format
Eth_long <- tidyr::gather(Eth, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
Eth_long <- Eth_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
Eth_long <- Eth_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
Eth_long$CellLine <- factor(Eth_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
Eth_long$label <- ifelse(Eth_long$P.value < 0.001 & Eth_long$CellLine == "KD", '***',
                         ifelse(Eth_long$P.value < 0.01 & Eth_long$CellLine == "KD", '**',
                                ifelse(Eth_long$P.value < 0.05 & Eth_long$CellLine == "KD", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(Eth_long, aes(x= as.factor(Alkyl.Acyl.ratio), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + SEM + 0.02), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = " ",
       x = " ",
       y = "Ether/Ester ratio") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 0.5)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

############################16C chain analysis##################################
clength <- read.csv("Input/palmitate chain analysis.csv")
#remove the other chain info
clength <- clength[-(1:3), ]
# make long format
clength_long <- tidyr::gather(clength, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
clength_long <- clength_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
clength_long <- clength_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
clength_long$CellLine <- factor(clength_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
clength_long$label <- ifelse(clength_long$P.value < 0.001 & clength_long$CellLine == "KD", '***',
                             ifelse(clength_long$P.value < 0.01 & clength_long$CellLine == "KD", '**',
                                    ifelse(clength_long$P.value < 0.05 & clength_long$CellLine == "KD", '*', '')))

# Plot the data 
ggplot(clength_long, aes(x= as.factor(Chain.length), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + SEM + 2), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = "16C chain Analysis",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 7.5, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 100)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))
