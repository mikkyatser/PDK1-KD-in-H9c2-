library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
library(ggplot2)
library(tidyr)
library(ggrepel)
if(!require("BiocManager", quietly = T))
  install.packages("BiocManager")
BiocManager::install("limma")
library(limma)
install.packages("svglite")
library(svglite)

pos <- read_excel("Input/Positive mode data.xlsx")
neg <- read_excel("Input/Negative mode data.xlsx")
#pos <- pos[c(1,29:40,53:64)]
#neg <- neg [c(1,30:41,54:65)]
pos <- pos[c(1,101:106)]
neg <- neg [c(1,102:107)]

#rename columns
#renaming function to column names
rename_columns <- function (colnames, date_str) {
  str_replace(colnames, paste0("_",date_str, ".*"), "")
}

#Apply renaming function to the column names
new_colnames <- rename_columns(colnames(pos), "10-25-2023")
colnames(pos) <- new_colnames

new_colnames <- rename_columns(colnames(neg), "10-22-2023")
colnames(neg) <- new_colnames

pos <- as.data.frame(pos) %>%
  rename("S1T3" = "Lenti-SC_3 hour_Expt I",
         "S2T3" = "Lenti-SC_3 hour_Expt II",
         "S3T3" = "Lenti-SC_3 hour_Expt III",
         "K1T3" = "Lenti-C_3 hour_Expt I",
         "K2T3" = "Lenti-C_3 hour_Expt II",
         "K3T3" = "Lenti-C_3 hour_Expt III")

neg <- as.data.frame(neg) %>%
  rename("S1T3" = "Lenti-SC_3 hour_Expt I",
         "S2T3" = "Lenti-SC_3 hour_Expt II",
         "S3T3" = "Lenti-SC_3 hour_Expt III",
         "K1T3" = "Lenti-C_3 hour_Expt I",
         "K2T3" = "Lenti-C_3 hour_Expt II",
         "K3T3" = "Lenti-C_3 hour_Expt III")

#convert to log2
pos[, -1] <- log2(pos[, -1])
write.csv(pos, "Output/Log2 unlabelled 3hr positive mode data.csv", row.names = F)
neg[, -1] <- log2(neg[, -1])
write.csv(neg, "Output/Log2 unlabelled 3hr negative mode data.csv", row.names = F)

pos2 <- head(pos, 72)
neg2 <- head(neg, 79)

# Merge the pos and neg data
merged_df <- rbind(pos2,neg2)
write.csv(merged_df, "Output/Log2 unlabelled 3hr metabolomics data.csv", row.names = F)


exprs <- read.csv("Output/Log2 unlabelled 3hr metabolomics data.csv")

#write.csv(exprs_clean, "Output/Log2 protein data cleaned.csv", row.names = F)
sample_info <- read.csv("Output/Log2 unlabelled 3hr metabolomics metadata.csv") #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make time a categorical variable
#sample_info$Time <- factor(sample_info$Time, levels=c("0","1","2", "3")) 
#levels(sample_info$Time)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Time, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  #CellLineKD_Time0 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "0"),
  #CellLineKD_Time1 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "1"),
  #CellLineKD_Time2 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "2"),
  CellLineKD_Time3 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "3"),
  #CellLineSC_Time0 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "0"),
  #CellLineSC_Time1 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "1"),
  #CellLineSC_Time2 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "2"),
  CellLineSC_Time3 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "3")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:3)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)

# contrast (unstarved)
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
sig_results <- results %>% filter (adj.P.Val < 0.05)
write.csv(results, "Output/limma unlabelled 3hr results.csv", row.names = F)
write.csv(sig_results, "Output/limma unlabelled 3hr sig hits results.csv", row.names = F)

# contrast (starved - 3 hours)
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_t3 <- topTable(fit2, coef = 1, number = nrow(exprs))
sig_results_t3 <- results_t3 %>% filter (adj.P.Val < 0.05)
write.csv(results_t3, "Output/limma time3 results.csv", row.names = F)
write.csv(sig_results_t3, "Output/limma time3 sig hits results.csv", row.names = F)
######################################################################################
######################################################################################
#Volcano Plots

library(ggplot2)
library(ggrepel)

unstarved <- read.csv("Output/limma time0 results.csv", check.names = F)

#glutathion is duplicated so removing the duplicate
unstarved <- unstarved [-9,]
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(unstarved$logFC), max(unstarved$logFC))))

# label dots
# label dots
label_points <- unstarved %>%
  arrange(desc(logFC), adj.P.Val) %>%
  filter(adj.P.Val < 0.05) 
label_points1 <- label_points %>% filter (logFC > 0)
label_points2 <- label_points %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(unstarved, aes(x = logFC, y = -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC KD/SC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = "Nutrient rich") +
  theme(legend.position = "none", 
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),      
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
        plot.title = element_text(hjust = 0.5)) +
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = label_points1,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "black",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-label_points1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = label_points2,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "black",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-label_points2$logFC,
    #nudge_y = 0.5,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )
volcano_plot
ggsave(filename="volcano plot_Time 0.png",width=9,height=6,units="in",dpi=600)
ggsave(filename="volcano plot_Time 0.pdf",width=9,height=6,units="in")
ggsave(filename="volcano plot_Time 0.svg",width=9,height=6,units="in")
############################

starved <- read.csv("Output/limma unlabelled 3hr results.csv", check.names = F)

#glutathion is duplicated so removing the duplicate
starved <- starved [-2,]
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(starved$logFC), max(starved$logFC))))

# label dots
label_points <- starved %>%
  arrange(desc(logFC), P.Value) %>%
  filter(P.Value < 0.05) 
label_points1 <- label_points %>% filter (logFC > 0)
label_points2 <- label_points %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(starved, aes(x = logFC, y = -log10(P.Value))) +
  geom_point(aes(color = ifelse(P.Value < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC KD/SC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = "3 hr Nutrient deprivation") +
  theme(legend.position = "none", 
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),      
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
        plot.title = element_text(hjust = 0.5)) +
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = label_points1,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "black",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-label_points1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 3,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = label_points2,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "black",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-label_points2$logFC,
    #nudge_y = 0.5,
    direction = "y",
    hjust = 1,
    size = 3,
    show.legend = F
  )
volcano_plot
ggsave(filename="volcano plot_unlabelled.png",width=5.78,height=5.2,units="in",dpi=600)
ggsave(filename="volcano plot_unlabelled.pdf",width=5.78,height=5.2,units="in")
ggsave(filename="volcano plot_unlabelled.svg",width=5.78,height=5.2,units="in")
#######################################################################################
#scatter plots

df <- read.csv("Output/Log2 metabolomics data.csv")
df <- df %>% distinct(Compound, .keep_all = T)
# Change the data into long format where metabolites become columns
df_long <- df %>%
  pivot_longer(cols = -Compound, names_to = "Sample", values_to = "Abundance") %>%
  separate(Sample, into = c("CellLine", "ReplicateTime"), sep = 1) %>%
  separate(ReplicateTime, into = c("Replicate", "Time"), sep = 1) %>%
  dplyr::select(CellLine, Time, Replicate, Compound, Abundance) %>%
  mutate(CellLine = str_replace_all(CellLine, c("S" = "SC", "K" = "KD"))) %>%
  mutate(Time = str_replace(Time, "T", "")) %>%
  mutate(Time = as.numeric(Time), Replicate = as.numeric(Replicate)) %>%
  spread(key = Compound, value = Abundance)
write.csv(df_long, "Output/Log2 metabolomics data long.csv", row.names = F)
getwd()
# Define your folder path
folder_path <- "C:/Users/Az/JimJohnsonLab Dropbox/Individual DropBoxes/Mikky Dropbox/PDK project/Data/shRNA Lentiviral knockdowns/Metabolomic Analysis/Unlabeled Metabololomic Analysis/Figure/scatter plot"

# List to store the mean data frames for each compound
mean_data_list <- list()

# Loop through each compound column (assuming the first three columns are non-compound columns)
for (i in 4:ncol(df_long)) {
  # Calculate mean values for each combination of Time and CellLine
  mean_data <- aggregate(. ~ Time + CellLine, data = df_long, FUN = function(x) mean(x, na.rm = TRUE))
  
  # Add the compound column to the mean data frame
  mean_data$compound <- colnames(df_long)[i]
  
  # Append mean data frame to the list
  mean_data_list[[i - 3]] <- mean_data
}

# Clean up column names
clean_col_names <- function(names) {
  cleaned_names <- gsub("/", "_", names)
  return(cleaned_names)
}

# Apply the function to your data frame's column names
colnames(mean_data) <- clean_col_names(colnames(mean_data))

# Loop through each compound column
for (compound in colnames(mean_data)[4:ncol(mean_data)]) {
  # Create scatter plot
  p <- ggplot(mean_data, aes(x = Time, y = !!as.name(compound), color = factor(CellLine))) +
    geom_point() +
    geom_line(aes(group = CellLine)) + 
    labs(title = paste("Scatter plot for", compound))
  
  # Save plot as png file
  ggsave(filename = paste(folder_path, "/", compound, ".png", sep = ""), plot = p, width = 6, height = 4)
}
#################################
#Metaboanalyst enrichment at starved time point
# Filter columns containing "T3" in their names
filtered_cols <- grep("T3", names(df), value = TRUE)

# Select the first column and the columns containing "T3"
cols_to_select <- c(names(df)[1], filtered_cols)

# Select the desired columns
starved <- df[, cols_to_select]
write.csv(starved, "Output/Log2 metabolomics data(time3).csv", row.names = F)

starved_2 <- df_long %>% filter(Time == 3)
write.csv(starved_2, "Output/Log2 metabolomics data(time3) long.csv", row.names = F)

pos <- read_excel("Input/Positive mode data.xlsx")
neg <- read_excel("Input/Negative mode data.xlsx")
pos1 <- pos[c(2,3)]
neg1 <- neg[c(5,6)]
pos2 <- pos[c(2,29:40,53:64)]
neg2 <- neg [c(5,30:41,54:65)]


#rename columns
#renaming function to column names
rename_columns <- function (colnames, date_str) {
  str_replace(colnames, paste0("_",date_str, ".*"), "")
}

#Apply renaming function to the column names
new_colnames <- rename_columns(colnames(pos2), "10-24-2023")
colnames(pos2) <- new_colnames

new_colnames <- rename_columns(colnames(neg2), "10-22-2023")
colnames(neg2) <- new_colnames

pos2 <- as.data.frame(pos2) %>%
  rename("S1T0" = "Lenti-SC_Time 0_Expt I",
         "S2T0" = "Lenti-SC_Time 0_Expt II",
         "S3T0" = "Lenti-SC_Time 0_Expt III",
         "S1T1" = "Lenti-SC_Time 1_Expt I",
         "S2T1" = "Lenti-SC_Time 1_Expt II",
         "S3T1" = "Lenti-SC_Time 1_Expt III",
         "S1T2" = "Lenti-SC_Time 2_Expt I",
         "S2T2" = "Lenti-SC_Time 2_Expt II",
         "S3T2" = "Lenti-SC_Time 2_Expt III",
         "S1T3" = "Lenti-SC_Time 3_Expt I",
         "S2T3" = "Lenti-SC_Time 3_Expt II",
         "S3T3" = "Lenti-SC_Time 3_Expt III",
         "K1T0" = "Lenti-C_Time 0_Expt I",
         "K2T0" = "Lenti-C_Time 0_Expt II",
         "K3T0" = "Lenti-C_Time 0_Expt III",
         "K1T1" = "Lenti-C_Time 1_Expt I",
         "K2T1" = "Lenti-C_Time 1_Expt II",
         "K3T1" = "Lenti-C_Time 1_Expt III",
         "K1T2" = "Lenti-C_Time 2_Expt I",
         "K2T2" = "Lenti-C_Time 2_Expt II",
         "K3T2" = "Lenti-C_Time 2_Expt III",
         "K1T3" = "Lenti-C_Time 3_Expt I",
         "K2T3" = "Lenti-C_Time 3_Expt II",
         "K3T3" = "Lenti-C_Time 3_Expt III")

neg2 <- as.data.frame(neg2) %>%
  rename("S1T0" = "Lenti-SC_Time 0_Expt I",
         "S2T0" = "Lenti-SC_Time 0_Expt II",
         "S3T0" = "Lenti-SC_Time 0_Expt III",
         "S1T1" = "Lenti-SC_Time 1_Expt I",
         "S2T1" = "Lenti-SC_Time 1_Expt II",
         "S3T1" = "Lenti-SC_Time 1_Expt III",
         "S1T2" = "Lenti-SC_Time 2_Expt I",
         "S2T2" = "Lenti-SC_Time 2_Expt II",
         "S3T2" = "Lenti-SC_Time 2_Expt III",
         "S1T3" = "Lenti-SC_Time 3_Expt I",
         "S2T3" = "Lenti-SC_Time 3_Expt II",
         "S3T3" = "Lenti-SC_Time 3_Expt III",
         "K1T0" = "Lenti-C_Time 0_Expt I",
         "K2T0" = "Lenti-C_Time 0_Expt II",
         "K3T0" = "Lenti-C_Time 0_Expt III",
         "K1T1" = "Lenti-C_Time 1_Expt I",
         "K2T1" = "Lenti-C_Time 1_Expt II",
         "K3T1" = "Lenti-C_Time 1_Expt III",
         "K1T2" = "Lenti-C_Time 2_Expt I",
         "K2T2" = "Lenti-C_Time 2_Expt II",
         "K3T2" = "Lenti-C_Time 2_Expt III",
         "K1T3" = "Lenti-C_Time 3_Expt I",
         "K2T3" = "Lenti-C_Time 3_Expt II",
         "K3T3" = "Lenti-C_Time 3_Expt III")

#convert to log2
pos2[, -1] <- log2(pos2[, -1])
neg2[, -1] <- log2(neg2[, -1])

pos2 <- pos2 %>% mutate(`m/z` = as.character(`m/z`))
neg2 <- neg2 %>% mutate(`m/z` = as.character(`m/z`))
#write.csv(exprs_clean, "Output/Log2 protein data cleaned.csv", row.names = F)
sample_info <- read.csv("Output/Log2 metabolomics metadata.csv") #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make time a categorical variable
sample_info$Time <- factor(sample_info$Time, levels=c("0","1","2", "3")) 
levels(sample_info$Time)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Time, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  CellLineKD_Time0 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "0"),
  CellLineKD_Time1 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "1"),
  CellLineKD_Time2 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "2"),
  CellLineKD_Time3 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "3"),
  CellLineSC_Time0 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "0"),
  CellLineSC_Time1 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "1"),
  CellLineSC_Time2 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "2"),
  CellLineSC_Time3 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "3")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(pos2, design_matrix)

# contrast (unstarved)
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_pos <- topTable(fit2, coef = 1, number = nrow(pos2))
pos1 <- pos1 %>% rename (m.z = `m/z`)

# Merge the data
pos_results <- merge(results_pos, pos1, by = 'm.z')
pos_results <- pos_results[c(1,6,4,8)]
pos_results <- na.omit(pos_results)
pos_results <- pos_results %>% rename (p.value = adj.P.Val)
pos_results <- pos_results %>% rename (t.score = t)
pos_results <- pos_results %>% rename (r.t = `Retention time (min)`)
write.csv(pos_results, "Output/limma time3 pos mode results.csv", row.names = F)



# Fit the linear model for neg data
fit <- lmFit(neg2, design_matrix)

# contrast (unstarved)
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_neg <- topTable(fit2, coef = 1, number = nrow(neg2))
neg1 <- neg1 %>% rename (m.z = `m/z`)

# Merge the data
neg_results <- merge(results_neg, neg1, by = 'm.z')
neg_results <- neg_results[c(1,6,4,8)]
neg_results <- neg_results %>% rename (p.value = adj.P.Val)
neg_results <- neg_results %>% rename (t.score = t)
neg_results <- neg_results %>% rename (r.t = `Retention time (min)`)
write.csv(neg_results, "Output/limma time3 neg mode results.csv", row.names = F)


