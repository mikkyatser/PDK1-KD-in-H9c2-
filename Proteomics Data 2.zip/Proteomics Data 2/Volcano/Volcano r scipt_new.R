# Name: Chelsea Wenyonu
# Date: 2024-01-10
# Description: Volcano Plotting Script

#Loading packages
library(tidyverse) 
library(RColorBrewer)
library(ggrepel) 
library(dplyr)
library(ggplot2)
library(readxl)
library(writexl)


getwd()
#Importing data
m1<- read.csv("Input/SCvKD_BSA.csv")
m2 <- read.csv("Input/SCvKD_PA.csv")
m3 <- read.csv("Input/SCvKD_SS_BSA.csv")
m4 <- read.csv("Input/SCvKD_SS_PA.csv")

# filter to remove unresolved protein isomers
m1 <- m1[!grepl(";", m1$Protein.Group), ]
m2 <- m2[!grepl(";", m2$Protein.Group), ]
m3 <- m3[!grepl(";", m3$Protein.Group), ]
m4 <- m4[!grepl(";", m4$Protein.Group), ]
significance_threshold <- 0.05

#############################Creating Volcano plots##########################################
#m1_
max_abs_logFC <- max(abs(c(min(m1$logFC), max(m1$logFC))))

#label dots with biggest positive FC
label_point <- m1 %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- m1 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- m1 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 
 
# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, m1[m1$Genes=="Pdk1",])

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


volcano_m1 <- ggplot(m1, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (BSA)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) + 
  xlim(c(-10, 10)) +
   #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 8-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +

   #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -8-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )

volcano_m1
ggsave(filename="volcano plot_BSA.png",width=6,height=4,units="in",dpi=600)
ggsave(filename="volcano plot_BSA.pdf",width=8,height=6,units="in")
#
#
#
#
#
#
#
#m2_group plot
max_abs_logFC <- max(abs(c(min(m2$logFC), max(m2$logFC))))
#label dots with biggest positive FC
label_point <- m2 %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- m2 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- m2 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, m2[m2$Genes=="Pdk1",])

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels <- unique_labels[-17,]
unique_labels <- unique_labels[-26,]
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

volcano_m2 <- ggplot(m2, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (Pre-starved)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) + 
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 8-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -8-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )
volcano_m2
ggsave(filename="volcano plot_PA_II.png",width=6,height=4,units="in",dpi=600)
ggsave(filename="volcano plot_PA_II.pdf",width=8,height=6,units="in")
#
#
#
#
#
#
#
#
#m3_group plot
max_abs_logFC <- max(abs(c(min(m3$logFC), max(m3$logFC))))
#label dots with biggest positive FC
label_point <- m3 %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- m3 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- m3 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, m3[m3$Genes=="Pdk1",])

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

volcano_m3 <- ggplot(m3, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (BSA_SS)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) + 
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 8-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -8-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )
volcano_m3
ggsave(filename="volcano plot_BSA_SS.png",width=6,height=4,units="in",dpi=600)
ggsave(filename="volcano plot_BSA_SS.pdf",width=8,height=6,units="in")
#
#
#
#
#
#
#
#m4
max_abs_logFC <- max(abs(c(min(m4$logFC), max(m4$logFC))))

#label dots with biggest positive FC
label_point <- m4 %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- m4 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- m4 %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, m4[m4$Genes=="Pdk1",])

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels <- unique_labels[-6,]
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

volcano_m4 <- ggplot(m4, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (Starved)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) + 
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    size= 4.5,
    max.overlaps = Inf,
    nudge_x = 8-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Genes),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    size = 4.5,
    max.overlaps = Inf,
    nudge_x = -8-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )
volcano_m4

ggsave(filename="volcano plot_PA_SS_II.pdf",width=6.15,height=5.74,units="in")
ggsave(filename="volcano plot_PA_SS_II.svg",width=6.15,height=5.74,units="in")

