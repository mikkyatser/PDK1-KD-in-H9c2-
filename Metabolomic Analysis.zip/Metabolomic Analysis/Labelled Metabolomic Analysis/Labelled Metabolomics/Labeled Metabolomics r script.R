library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)
library(stringr)

---
  title: "label_ratio"
author: "Howard Cen"
date: "2024-05-16"
output: html_document
---
  
  ```{r calculate ratio, include=FALSE}

library(tidyverse)

dat <- read.csv("Input/Molecule Quantification_Labelled metabolites II.csv", check.names = F) %>% janitor::clean_names()
dat2 <- dat[c(1:3,8)]
# Convert long format data to wide format
dat2 <- pivot_wider(dat2, names_from = replicate_name, values_from = max_height)
#remove blank columns
dat2 <- dat2[-c(3:7)]

#filter metabolites
citrate <- dat2 %>% filter (molecule_list == "Citric acid")
r5p <- dat2 %>% filter (molecule_list == "Ribose 5-phosphate")
malate <- dat2 %>% filter (molecule_list == "Malic acid")
pep <- dat2 %>% filter (molecule_list == "Phosphoenolpyruvic acid")
pg <- dat2 %>% filter (molecule_list == "Phosphoglyceric acid")
g3p <- dat2 %>% filter (molecule_list == "sn-Glycerol 3-phosphate")
f6p <- dat2 %>% filter (molecule_list == "Fructose 6-phosphate")
aspartate <- dat2 %>% filter (molecule_list == "Aspartic acid")
alanine <- dat2 %>% filter (molecule_list == "Alanine")
glutamate <- dat2 %>% filter (molecule_list == "Glutamic acid")

r5p <- r5p %>% arrange(molecule)


write.csv(citrate, "Output/citr_NA_measFile.csv", row.names = F)
write.csv(r5p, "Output/ribo_NA_measFile.csv", row.names = F)
write.csv(malate, "Output/mala_NA_measFile.csv", row.names = F)
write.csv(pep, "Output/pep_NA_measFile.csv", row.names = F)
write.csv(pg, "Output/pg_NA_measFile.csv", row.names = F)
write.csv(g3p, "Output/g3p_NA_measFile.csv", row.names = F)
write.csv(f6p, "Output/f6p_NA_measFile.csv", row.names = F)
write.csv(aspartate, "Output/aspartate_NA_measFile.csv", row.names = F)
write.csv(alanine, "Output/alanine_NA_measFile.csv", row.names = F)
write.csv(glutamate, "Output/glutamate_NA_measFile.csv", row.names = F)

#This script corrects for natural abundance from raw data in isotope tracing untargeted metabolomics.
# Requires known metabolites and must be performed 1 m/z at a time. see ppt for tutorial.

#set working directory
setwd("") #update this and save script into your folder so you remember everything you did
#if package is not yet installed on your machine, first install, then load
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("IsoCorrectoR")
library(IsoCorrectoR) #Loads library
#update Measurement file and out file name in the line below:
IsoCorrection(MeasurementFile = "./R5P_NA_measFile.xlsx", ElementFile = "./ElementFile.csv", MoleculeFile = "./MoleculeFile.xlsx", CorrectTracerImpurity = TRUE, CorrectTracerElementCore = TRUE, CalculateMeanEnrichment = TRUE, UltraHighRes = TRUE, DirOut = ".", FileOut = "R5P", FileOutFormat = "csv", ReturnResultsObject = FALSE)


posdat <- read.csv("Input/Molecule Quantification_Labelled metabolites_pos mode.csv", check.names = F) %>% janitor::clean_names()
posdat2 <- posdat[c(1:3,8)]
# Convert long format data to wide format
posdat2 <- pivot_wider(posdat2, names_from = replicate_name, values_from = max_height)


#filter metabolites
g1p <- posdat2 %>% filter (molecule_list == "Glucose 1-phosphate")
g1p <- g1p[c(1:10,13,14,11,12)]
write.csv(g1p, "Output/G1P_NA_measFile.csv", row.names = F)

#update Measurement file and out file name in the line below:
IsoCorrection(MeasurementFile = "./G1p_NA_measFile.xlsx", ElementFile = "./ElementFile.csv", MoleculeFile = "./MoleculeFile.xlsx", CorrectTracerImpurity = TRUE, CorrectTracerElementCore = TRUE, CalculateMeanEnrichment = TRUE, UltraHighRes = TRUE, DirOut = ".", FileOut = "G1P", FileOutFormat = "csv", ReturnResultsObject = FALSE)















dat <- dat %>%
  mutate_at(which(colnames(dat)=="total_area_ms1"), as.numeric) %>%
  filter(total_area_ms1 != 0) %>%
  filter(!is.na(total_area_ms1)) %>%
  arrange(replicate_name, molecule_list)

dat_ratio <- dat %>%
  group_by(replicate_name, molecule_list) %>%
  mutate(single_light = case_when(length(total_area_ms1[isotope_label_type== "light"])==1 ~ "yes", 
                                  length(total_area_ms1[isotope_label_type== "light"])>1 ~ "no",
                                  length(total_area_ms1[isotope_label_type== "light"])==0 ~ "zero")) %>%
  mutate(light_value = ifelse(single_light == "yes", total_area_ms1[isotope_label_type== "light"],
                              sum(total_area_ms1[isotope_label_type == "light"])))
dat_ratio <- dat_ratio %>%
  group_by(replicate_name, molecule) %>%  
  mutate(single_heavy = case_when(length(total_area_ms1[isotope_label_type== "heavy"])==1 ~ "yes", 
                                  length(total_area_ms1[isotope_label_type== "heavy"])>1 ~ "no",
                                  length(total_area_ms1[isotope_label_type== "heavy"])==0 ~ "zero")) %>%
  mutate(heavy_value = ifelse(single_heavy == "yes", total_area_ms1[isotope_label_type== "heavy"],
                              sum(total_area_ms1[isotope_label_type == "heavy"])))
dat_ratio <- dat_ratio %>%
  mutate(ratio = ifelse(single_heavy == "no", heavy_value/light_value, 
                        ifelse(single_heavy == "zero", light_value/light_value,
                               total_area_ms1/light_value)))

dat_ratio_f <- dat_ratio %>%
  group_by(replicate_name, molecule, ratio) %>%
  summarize(Area = sum(total_area_ms1), .groups = 'drop')

write.csv(dat_ratio_f, "Output/Labeled Metabolites ratio.csv", row.names = F)

####################################

#labmet <- read.csv("Output/Labeled Metabolites ratio.csv")
labmet <- dat_ratio_f

#select ratio values
labmet_r <- labmet[c(1,2,3)]
#select area values
labmet_A <- labmet[c(1,2,4)]

# Convert long format data to wide format
labmet_r <- pivot_wider(labmet_r, names_from = replicate_name, values_from = ratio)

# Convert long format data to wide format
labmet_A <- pivot_wider(labmet_A, names_from = replicate_name, values_from = Area)


write.csv(labmet_A, "Output/Labeled Area.csv", row.names = F)

#rename columns

#renaming function to column names
rename_columns <- function (colnames, date_str) {
  str_replace(colnames, paste0("_",date_str, ".*"), "")
}

#Apply renaming function to the column names
new_colnames <- rename_columns(colnames(labmet_r), "10-22-2023")
colnames(labmet_r) <- new_colnames

new_colnames <- rename_columns(colnames(labmet_A), "10-22-2023")
colnames(labmet_A) <- new_colnames

#filter QC or TCI columns
columns_to_remove <- grep("QC|TCI", names(labmet_r))
labmet_r <- labmet_r[, -columns_to_remove]

columns_to_remove <- grep("QC|TCI", names(labmet_A))
labmet_A <- labmet_A[, -columns_to_remove]

labmet_r2 <- labmet_r[c(1:6, 48,47,46,36,35,34,45,44,43,33,32,32,39,38,37,42,41,40,30,29,28,27,26,25,15,14,13,24,23,22,12,11,10,18,17,16,21,20,19,9,8,7)]
labmet_A2 <- labmet_A[c(1:6, 48,47,46,36,35,34,45,44,43,33,32,32,39,38,37,42,41,40,30,29,28,27,26,25,15,14,13,24,23,22,12,11,10,18,17,16,21,20,19,9,8,7)]

write.csv(labmet_r2, "Output/Labeled ratio.csv", row.names = F)

# Function to apply log base 2 transformation to numerical columns
log_base2_transform <- function(x) {
  if(is.numeric(x)) {
    return(log2(x))
  } else {
    return(x)
  }
}

# Apply log base 2 transformation to all numerical columns
labmet_r2 <- lapply(labmet_r2, log_base2_transform)
labmet_r2 <- as.data.frame(labmet_r2)

write.csv(labmet_r2, "Output/Log Labeled ratio.csv", row.names = F)
write.csv(labmet_A2, "Output/Labeled Area(2).csv", row.names = F)
