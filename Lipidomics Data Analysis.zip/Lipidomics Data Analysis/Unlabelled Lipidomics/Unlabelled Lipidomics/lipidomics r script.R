library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
install_github("jokergoo/ComplexHeatmap")
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
BiocManager::install("clusterProfiler")
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)

a_pos <- read.csv('Input/NormalizedArea_pos.csv')
a_neg <- read.csv('Input/NormalizedArea_neg.csv')

a_pos <- a_pos[-c(1:3),]
a_neg <- a_neg[-c(1:3),]

#rename columns
rowasname <- 1
newcolnames <- as.character(a_pos[rowasname, ])
a_pos <- a_pos[-rowasname, ]
colnames(a_pos) <- newcolnames

newcolnames <- as.character(a_neg[rowasname, ])
a_neg <- a_neg[-rowasname, ]
colnames(a_neg) <- newcolnames
a_neg <- a_neg[-c(37,93)]

#rename columns
#renaming function to column names
rename_columns <- function (colnames, date_str) {
  str_replace(colnames, paste0("_",date_str, ".*"), "")
}

#Apply renaming function to the column names
new_colnames <- rename_columns(colnames(a_pos), "10-4-2023")
colnames(a_pos) <- new_colnames

new_colnames <- rename_columns(colnames(a_neg), "10-5-2023")
colnames(a_neg) <- new_colnames

#make column names unique in each dataset
names(a_pos) <- make.unique(names(a_pos))
names(a_neg) <- make.unique(names(a_neg))

#merge postive and negative mode data
lipidomics <- rbind(a_pos, a_neg)

#filter for peaks that were normalized by internal standard
lipidomics<- lipidomics %>%
  filter(Comment == 'Normalized unit: NormalizedByInternalStandardPeakHeight; Annotation method: Msp20230821112155_conventional_converted_dev_1') %>%
  arrange(Ontology)

#manual peak curation
write.csv(lipidomics, "Output/Lipidomics data.csv")
lipidomics <- read.csv("Input/Lipidomics data.csv", check.names = F)
lipidomics <- lipidomics[-c(1)]

#remove duplicate rows by keeping the rows with the smallest Standard deviation in QC
lipid2 <- lipidomics %>%
  group_by(`Metabolite name`) %>%
  slice_min(QC.1, with_ties = F) %>%
  ungroup()

#remove standard deviation columns
lipid2 <- lipid2[-c(116:133)]

#remove rows where the abundance in the highest column is not 5x more than levels in blank
lipid3 <- lipid2 %>%
  rowwise() %>%
  filter(max(c(c_across(56:67), c_across(80:91))) >= 5 * `Blank`) %>%
  ungroup()

#remove average columns 
lipid3 <- lipid3[-c(98:115)]
write.csv(lipid3, "Output/Annotated lipidomics.csv")

#isolate samples
lipid4 <- lipid3[c(4,12,44:91)]

#read protein normalization factor
prot <- read_excel("Input/Protein Normalization factor.xlsx")
prot <- prot[-1,-1]

#add missing columns to prot
missing_cols_in_prot <- setdiff(names(lipid4), names(prot))
prot[missing_cols_in_prot] <- NA

#rowbind the two dataframes
lipid5 <- rbind(prot, lipid4)

#protein normalization
lipid5 <- lipid5 %>%
  mutate(across(-c(49,50), ~ ./first(.)))
lipid5 <- lipid5[-1,]

#unlabelled columns
lipid6 <- lipid5[c(49, 50, 1:12,25:36)]
lipid6 <- lipid6[c(1,2,3,7,11,4,8,12,5,9,13,6,10,14,15,19,23,16,20,24,17,21,25,18,22,26)]
write.csv(lipid6, "Output/IS normalized lipidomics.csv")


#convert to log2
mf2<- lipid6 %>%
  mutate(across(-c(1,2), ~ifelse(.> 0, log2(.),NA)))

#clean up lipid names
# Function to remove characters preceding and including "|" and add parentheses
remove_prefix_add_parentheses <- function(x) {
  # Remove prefix if "|" is present
  x <- gsub(".*\\|", "", x)
  # Add parentheses without a space after the first space and closing parenthesis at the end
  x <- paste0(gsub(" ", "(", x, fixed = TRUE), ")")
  return(x)
}
# Apply the function to the specified column
mf2$`Metabolite name` <- sapply(mf2$`Metabolite name`, remove_prefix_add_parentheses)



write.csv(mf2, "Output/Log2 IS normalized lipidomics.csv")
mf2 <- read.csv("Output/Log2 IS normalized lipidomics.csv", check.names = F)
mf2<- mf2[,-1]
#lipidomics <- read_excel("Input/TIC normalized_combined annotated peaks.xlsx")

#m <- lipidomics [,3:28]
#m <- m[c(1,2,15,16,17,18,19,20,21,22,23,24,25,26,3,4,5,6,7,8,9,10,11,12,13,14)]

#calculate standard deviation across all samples
#m_sd <- function(df) {
 # df %>%
  #  rowwise() %>%
   # mutate(sd_across = sd(across(starts_with("Lenti"))))
#}
#mf <- m_sd(m)

#filter duplicates by lowest standard deviation across all samples
#column_to_filter <- mf$`Metabolite name`
#column_to_select <- mf$sd_across

#mf2 <- mf %>%
 # group_by({{column_to_filter}}) %>%
  #arrange({{column_to_select}}) %>%
  #slice_head(n = 1) %>%
  #ungroup ()

#convert to log2 scale
#mf2 <- mf2 %>%
  #mutate(log2(across(starts_with("Lenti"))))

#write.csv(mf2, "Output/TIC normalized lipid data.CSV") # save the file

#filtering data frame based on class in ontology column (for individual class heatmaps)

#define multiple values to filter
#lipid_classes <- c("DG")

#filter
#mf2.1 <- mf2 %>%
 # filter(Ontology %in% lipid_classes)

#write.csv(mf2.1, "Output/Diacylglycerol_TIC.CSV")

m1 <- as.matrix(mf2)
m2 <- m1 [,2:26]
rownames(m2) <- mf2$`Metabolite name`


m3 <- as.data.frame(m2) %>%
  mutate_at(2:25, as.numeric) %>%
  rename("1A" = "Lenti-SC_Time 0_Expt I",
         "1B" = "Lenti-SC_Time 0_Expt II",
         "1C" = "Lenti-SC_Time 0_Expt III",
         "2A" = "Lenti-SC_Time 1_Expt I",
         "2B" = "Lenti-SC_Time 1_Expt II",
         "2C" = "Lenti-SC_Time 1_Expt III",
         "3A" = "Lenti-SC_Time 2_Expt I",
         "3B" = "Lenti-SC_Time 2_Expt II",
         "3C" = "Lenti-SC_Time 2_Expt III",
         "4A" = "Lenti-SC_Time 3_Expt I",
         "4B" = "Lenti-SC_Time 3_Expt II",
         "4C" = "Lenti-SC_Time 3_Expt III",
         "5A" = "Lenti-C_Time 0_Expt I",
         "5B" = "Lenti-C_Time 0_Expt II",
         "5C" = "Lenti-C_Time 0_Expt III",
         "6A" = "Lenti-C_Time 1_Expt I",
         "6B" = "Lenti-C_Time 1_Expt II",
         "6C" = "Lenti-C_Time 1_Expt III",
         "7A" = "Lenti-C_Time 2_Expt I",
         "7B" = "Lenti-C_Time 2_Expt II",
         "7C" = "Lenti-C_Time 2_Expt III",
         "8A" = "Lenti-C_Time 3_Expt I",
         "8B" = "Lenti-C_Time 3_Expt II",
         "8C" = "Lenti-C_Time 3_Expt III")

m3.z <- t(scale(t(m3[,2:25])))

#function calculate z-scores but keep ontology column
#calculate_row_zscores <- function(matrix, columns) {
  #selected_data <- matrix[, columns, drop = FALSE]
  #row_means <- rowMeans(selected_data, na.rm = TRUE)
  #row_sds <- apply(selected_data, 1, sd, na.rm = TRUE)
  #Z_scores <- sweep(selected_data, 1, row_means, "-")
  #Z_scores <- sweep(Z_scores, 1, row_sds, "/")
  #untouched_data <- matrix[, -columns, drop = FALSE]
  #result_matrix <- cbind(untouched_data, Z_scores)
  #return(result_matrix)
#}

#m3.z2 <- calculate_row_zscores(m3, c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25))

#m3.z <- m3.z[complete.cases(m3.z),] #remove NaN values
#m3.z2 <- m3.z2[complete.cases(m3.z2[,2:25]),] #remove NaN values

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

#m4.2 <- as.matrix(m3.z2)


# plot heat maps
SCnT0 <- length(grep("1", colnames(m4)))
SCnT1 <- length(grep("2", colnames(m4)))
SCnT2 <- length(grep("3", colnames(m4)))
SCnT3 <- length(grep("4", colnames(m4)))
KDnT0 <- length(grep("5", colnames(m4)))
KDnT1 <- length(grep("6", colnames(m4)))
KDnT2 <- length(grep("7", colnames(m4)))
KDnT3 <- length(grep("8", colnames(m4)))

end_index_SCnT0 <- grep("1", colnames(m4)) [SCnT0]
end_index_SCnT1 <- grep("2", colnames(m4)) [SCnT1]
end_index_SCnT2 <- grep("3", colnames(m4)) [SCnT2]
end_index_SCnT3 <- grep("4", colnames(m4)) [SCnT3]
end_index_KDnT0 <- grep("5", colnames(m4)) [KDnT0]
end_index_KDnT1 <- grep("6", colnames(m4)) [KDnT1]
end_index_KDnT2 <- grep("7", colnames(m4)) [KDnT2]
end_index_KDnT3 <- grep("8", colnames(m4)) [KDnT3]

end_index_SCnT0
end_index_SCnT1
end_index_SCnT2
end_index_SCnT3
end_index_KDnT0
end_index_KDnT1
end_index_KDnT2
end_index_KDnT3

#class_factor <- factor(m3.z2$Ontology)

#row_order <- order(class_factor)

heatmap <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = FALSE,
                   
                   #cluster_rows = TRUE,
                   #cluster_columns = F,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 6, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_SCnT0,
                                            end_index_SCnT1,
                                            end_index_SCnT2,
                                            end_index_SCnT3,
                                            end_index_KDnT0,
                                            end_index_KDnT1,
                                            end_index_KDnT2,
                                            end_index_KDnT3
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 1
grid.rect(x = (end_index_SCnT0)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (SCnT0)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat4",
                    col = "wheat4"
          )
)
grid.text("SC_T0", 
          x = (end_index_SCnT0)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 2
grid.rect(x = (end_index_SCnT1 + end_index_SCnT0)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (SCnT1)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell1",
                    col = "seashell1"
          )
)
grid.text("SC_T1", 
          x = (end_index_SCnT1 + end_index_SCnT0)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))


#Condition label 3
grid.rect(x = (end_index_SCnT2 + end_index_SCnT1)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (SCnT2)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat3",
                    col = "wheat3"
          )
)
grid.text("SC_T2", 
          x = (end_index_SCnT2 + end_index_SCnT1)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))                    

#Condition label 4
grid.rect(x = (end_index_SCnT3 + end_index_SCnT2)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (SCnT3)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell2",
                    col = "seashell2"
          )
)
grid.text("SC_T3", 
          x = (end_index_SCnT3 + end_index_SCnT2)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))                    

#Condition label 5
grid.rect(x = (end_index_KDnT0 + end_index_SCnT3)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (KDnT0)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat2",
                    col = "wheat2"
          )
)
grid.text("KD_T0", 
          x = (end_index_KDnT0 + end_index_SCnT3)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_KDnT1 + end_index_KDnT0)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (KDnT1)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell3",
                    col = "seashell3"
          )
)
grid.text("KD_T1", 
          x = (end_index_KDnT1 + end_index_KDnT0)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 7
grid.rect(x = (end_index_KDnT2 + end_index_KDnT1)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (KDnT2)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat1",
                    col = "wheat1"
          )
)
grid.text("KD_T2", 
          x = (end_index_KDnT2 + end_index_KDnT1)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 8
grid.rect(x = (end_index_KDnT3 + end_index_KDnT2)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (KDnT3)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell4",
                    col = "seashell4"
          )
)
grid.text("KD_T3", 
          x = (end_index_KDnT3 + end_index_KDnT2)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))


## Top label gaps
#Vertical lines
grid.rect(x = end_index_SCnT0/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnT1/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnT2/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnT3/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnT0/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnT1/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnT2/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))


# step 4 - end by closing the saved file

pdf(file = 'Figures/IS + protein normalization.pdf',
    width = 10, 
    height = 10)

svg(file = 'Figures/IS + protein normalization_II.svg',
    width = 10, 
    height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()

################################################################################
#PCA plot

# Author: Chelsea Wenyonu
# Date: 2024-01-08
# Description: PCA Plotting Script


#Loading required packages
library(dplyr)
library(readxl)
library(writexl)
library(ggfortify)
library(ggplot2)
library(ggforce)
library(extrafont)
extrafont::loadfonts()
library(cluster)
library(factoextra)

#Loading excel sheet
log_data <- read.csv("Output/Log2 IS normalized lipidomics.csv", check.names = F)
log_data <- log_data[-c(1,3)]

# Remove rows with NAs
log_data <- na.omit(log_data)

# Extract the first column as column names
column_names <- log_data[, 1]

# Transpose the dataframe and set column names
transform <- t(log_data[,-1])
colnames(transform) <- column_names

# Converting matrix to data frame
transform <- as.data.frame(transform)

# Assuming your dataframe is named "transform"
transform <- transform %>%
  mutate(Samplegroups = case_when(
    grepl("Lenti-SC_Time 0", rownames(transform)) ~ "Ctrl_T0",
    grepl("Lenti-SC_Time 1", rownames(transform)) ~ "Ctrl_T1",
    grepl("Lenti-SC_Time 2", rownames(transform)) ~ "Ctrl_T2",
    grepl("Lenti-SC_Time 3", rownames(transform)) ~ "Ctrl_T3",
    grepl("Lenti-C_Time 0", rownames(transform)) ~ "KD_T0",
    grepl("Lenti-C_Time 1", rownames(transform)) ~ "KD_T1",
    grepl("Lenti-C_Time 2", rownames(transform)) ~ "KD_T2",
    grepl("Lenti-C_Time 3", rownames(transform)) ~ "KD_T3",
    TRUE ~ NA_character_
  )) %>%
  dplyr::select(Samplegroups, everything())
df <- transform
######################Plotting PCA##################################
pca_plot <- prcomp(df[c(-1)], scale. = TRUE)

# Converting "Comparison" column to factor with specified levels
df$Samplegroups <- factor(df$Samplegroups, levels = c(
  "Ctrl_T0", "Ctrl_T1", "Ctrl_T2", "Ctrl_T3",
  "KD_T0", "KD_T1", "KD_T2", "KD_T3"
))

# Assuming 'pca_plot' is a prcomp object
autoplot(pca_plot, data = df, colour = 'Samplegroups') +
  scale_color_manual(values = c(
    "Ctrl_T0" = "darkorange1",
    "Ctrl_T1" = "deepskyblue",
    "Ctrl_T2" = "gold",
    "Ctrl_T3" = "red4",
    "KD_T0" = "chartreuse4",
    "KD_T1" = "blue", 
    "KD_T2" = "darkorchid1",
    "KD_T3" = "lightsalmon"
  )) +
  theme_bw() +
  ggtitle(" ") 

#################Grouping points by similarity#######################

###This code shows the similarity among all points.###
#Performing PCA using prcomp
pca_result <- prcomp(df[, 2:443], scale. = TRUE)

# Accessing principal components
df$PC1 <- pca_plot$x[, 1]
df$PC2 <- pca_plot$x[, 2]

# Performing PAM clustering
pam_result <- pam(df[, 2:443], k = 2)

# Assigning cluster labels to the dataframe
df$Cluster <- pam_result$clustering

###****Clustering with shape border
colnames(pam_result)
# Performing PAM clustering
pam_result <- pam(df[, 2:443], k = 2)

# Specify the fill colors for the convex hulls
convex_fill_colors <- c("saddlebrown", "lightgoldenrod")  # Change these to your desired colors

# Creating the cluster plot with specified fill colors, white background, and Helvetica font
autoplot(pam_result, data = df, frame = TRUE, frame.type = 'norm') +
  theme_bw() +  # Set white background
  ggtitle(" ") +  # Add plot title
  theme(plot.title = element_text(hjust = 0.5)) +  # Center the plot title
  scale_fill_manual(values = convex_fill_colors, name = "Clusters", labels = c("Control", "KD")) +
  guides(fill = guide_legend(title = "Clusters"), color = guide_legend(title = "Sample groups", override.aes = list(shape = 16, fill = "white"))) +
  geom_point(aes(color = df$Samplegroups), size = 3) +
  scale_color_manual(values = c(
    "Ctrl_T0" = "#80320C",
    "Ctrl_T1" = "#B45423",
    "Ctrl_T2" = "#D98A5f",
    "Ctrl_T3" = "#FFCCB3",
    "KD_T0" = "#8A5D06",
    "KD_T1" = "#C38B0C", 
    "KD_T2" = "#E8C55E",
    "KD_T3" = "#FAE7C2")) +
  theme(legend.text = element_text(size = 14))

ggsave(filename="PCA plot_I.pdf",width=5.98,height=4.36,units="in")
ggsave(filename="PCA plot_I.svg",width=5.98,height=4.36,units="in")

################################################################################

#Stacked Area Plot
install.packages("ggplot2")
install.packages("reshape2")

library(ggplot2)
library(reshape2)
#import dataframe

lipid_classes <- c("MG")

#filter
mf2.1 <- mf2 %>%
  filter(Ontology %in% lipid_classes)

mf2.1 <- as.data.frame(mf2.1) %>%
  mutate_at(3:26, as.numeric) %>%
  rename("0_A" = "Lenti-SC_Time 0_I",
         "0_B" = "Lenti-SC_Time 0_II",
         "0_C" = "Lenti-SC_Time 0_III",
         "1_A" = "Lenti-SC_Time 1_I",
         "1_B" = "Lenti-SC_Time 1_II",
         "1_C" = "Lenti-SC_Time 1_III",
         "2_A" = "Lenti-SC_Time 2_I",
         "2_B" = "Lenti-SC_Time 2_II",
         "2_C" = "Lenti-SC_Time 2_III",
         "3_A" = "Lenti-SC_Time 3_I",
         "3_B" = "Lenti-SC_Time 3_II",
         "3_C" = "Lenti-SC_Time 3_III",
         "0_Ak" = "Lenti-C_Time 0_I",
         "0_Bk" = "Lenti-C_Time 0_II",
         "0_Ck" = "Lenti-C_Time 0_III",
         "1_Ak" = "Lenti-C_Time 1_I",
         "1_Bk" = "Lenti-C_Time 1_II",
         "1_Ck" = "Lenti-C_Time 1_III",
         "2_Ak" = "Lenti-C_Time 2_I",
         "2_Bk" = "Lenti-C_Time 2_II",
         "2_Ck" = "Lenti-C_Time 2_III",
         "3_Ak" = "Lenti-C_Time 3_I",
         "3_Bk" = "Lenti-C_Time 3_II",
         "3_Ck" = "Lenti-C_Time 3_III")

#mf2.2 <- mf2.1[c(1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)]
mf2.2 <- mf2.1[c(1, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26)]


# Melt the data frame to long format
melted_df <- reshape2::melt(mf2.2, id.vars = "Metabolite name")

# Extract time and replicate information from the variable column
melted_df <- melted_df %>%
  separate(variable, into = c("Time", "Replicate"), sep = "_") %>%
  mutate(across(c("value"), as.numeric))  # Convert the value column to numeric if it's not already

# Calculate the mean for each "Metabolite name" within each time point
mean_df <- melted_df %>%
  group_by(`Metabolite name`, Time) %>%
  summarise(mean_value = mean(value))

# Merge the mean values back to the melted dataframe
melted_df <- merge(melted_df, mean_df, by = c("Metabolite name", "Time")) %>%
  mutate(across(c("Time"), as.numeric))

# Convert "Metabolite name" to factor
melted_df$`Metabolite name` <- factor(melted_df$`Metabolite name`)

# Create a stacked area chart using ggplot2 with modified theme
ggplot(melted_df, aes(x = Time, y = mean_value, fill = `Metabolite name`)) +
  geom_area(position = "stack", color = "white") +
  labs(x = "Time (hrs)",
       y = "TIC Peaks",
       title = "Pdk1 KD",
       fill = "") +
  scale_fill_manual(values = colorRampPalette(c("navajowhite","wheat3", "khaki3", "lightgoldenrod"))(4)) +  # Use a blue color palette with 64 colors
  guides(fill = guide_legend(ncol = 2)) +  # Arrange legend in two vertical columns
  theme_minimal() +
  theme(
    legend.position = "right",   # Adjust legend position
    legend.text = element_text(size = 7),  # Adjust legend text size
    legend.title = element_text(size = 10),  # Adjust legend title size
    plot.margin = margin(10, 10, 10, 30, "pt"),  # Adjust plot margin for a larger chart area
    plot.title = element_text(hjust = 0.5)  # Center justify the chart title
  )

#################################################################################
#Data Processing for Linear Model


mf2 <- as.data.frame(mf2) %>%
  mutate_at(3:26, as.numeric) %>%
  rename("SC_0_1" = "Lenti-SC_Time 0_Expt I",
         "SC_0_2" = "Lenti-SC_Time 0_Expt II",
         "SC_0_3" = "Lenti-SC_Time 0_Expt III",
         "SC_1_1" = "Lenti-SC_Time 1_Expt I",
         "SC_1_2" = "Lenti-SC_Time 1_Expt II",
         "SC_1_3" = "Lenti-SC_Time 1_Expt III",
         "SC_2_1" = "Lenti-SC_Time 2_Expt I",
         "SC_2_2" = "Lenti-SC_Time 2_Expt II",
         "SC_2_3" = "Lenti-SC_Time 2_Expt III",
         "SC_3_1" = "Lenti-SC_Time 3_Expt I",
         "SC_3_2" = "Lenti-SC_Time 3_Expt II",
         "SC_3_3" = "Lenti-SC_Time 3_Expt III",
         "KD_0_1" = "Lenti-C_Time 0_Expt I",
         "KD_0_2" = "Lenti-C_Time 0_Expt II",
         "KD_0_3" = "Lenti-C_Time 0_Expt III",
         "KD_1_1" = "Lenti-C_Time 1_Expt I",
         "KD_1_2" = "Lenti-C_Time 1_Expt II",
         "KD_1_3" = "Lenti-C_Time 1_Expt III",
         "KD_2_1" = "Lenti-C_Time 2_Expt I",
         "KD_2_2" = "Lenti-C_Time 2_Expt II",
         "KD_2_3" = "Lenti-C_Time 2_Expt III",
         "KD_3_1" = "Lenti-C_Time 3_Expt I",
         "KD_3_2" = "Lenti-C_Time 3_Expt II",
         "KD_3_3" = "Lenti-C_Time 3_Expt III")

mf3 <- mf2[c(1,3:26)]


# Function to filter rows based on the percentage of valid values
filter_valid_rows <- function(data, threshold_percentage) {
  valid_rows <- data %>%
    filter(rowSums(data != -Inf, na.rm = TRUE)/ncol(data) >= threshold_percentage)
  
  return(valid_rows)
}

# Set the threshold percentage (75% in this case)
threshold_percentage <- 0.75

# Filter rows with at least 75% valid values (excluding -Inf)
mf3.2 <- filter_valid_rows(mf3, threshold_percentage)


write.csv(mf3.2, "Output/Log2 IS normalized lipidomics II.csv")
mf3_2 <- read.csv("Output/Log2 IS normalized lipidomics II.csv", check.names = F)
mf3.2 <- mf3_2[, 2:26]


# Change the data into long format where metabolites become columns
mf3.2_long <- mf3.2 %>%
  pivot_longer(cols = -`Metabolite name`, names_to = c("CellLine", "Time", "Replicate"), 
               names_sep = "_", values_to = "Abundance") %>%
  separate(CellLine, into = c("CellLine", "ID"), sep = 7) %>%
  mutate(Time = as.numeric(Time),
         Replicate = as.numeric(Replicate)) %>%
  dplyr::select(Subject = ID, CellLine, Time, Replicate, `Metabolite name`, Abundance) %>%
  spread(key = `Metabolite name`, value = Abundance) %>%
  dplyr::select(-Subject)
View(mf3.2_long)
write.csv(mf3.2_long, "Output/Log2 IS normalized lipidomics long.csv", row.names = F)

################################################################################
################################################################################
################################################################################
#Linear Model

# Install necessary packages
install.packages(c("lme4", "car", "multcomp"))
install.packages("MuMIn")


# Load the required libraries
install.packages("emmeans")
library(emmeans)
library(car)


mf3.2 <- read.csv("Output/Log2 IS normalized lipidomics long.csv", check.names = F) # 598 x 24

#SC is our reference 
mf3.2$CellLine <- factor(mf3.2$CellLine, levels=c("SC","KD")) 
levels(mf3.2$CellLine)

i=1
input=mf3.2
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ CellLine * Time")
    model <- lm(formula, data = input) 
    s <- summary(model)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(s$coefficients)
    fixed_est <- fixed_df[1:4,1]
    fixed_SE <- fixed_df[1:4,2]
    fixed_p <- fixed_df[1:4,4]
   
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:4, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model)$r.squared
    f_statistic <- summary(model)$fstatistic[1]
    
    # Specify the overall time point of interest
    #overall_time_point <- 3
    # Obtain estimated marginal trends for each level of CellLine at the overall time point
    #trend_result <- emtrends(model, ~ CellLine | Time, var = "Time", at = list(Time = overall_time_point))
    # Perform pairwise comparisons between CellLine levels
    #pairwise_comparisons <- pairs(trend_result)
    #p_values <- summary(pairwise_comparisons)$p.value
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
              
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_SC","Basal_KD_Diff","SC_slope", "KD_slope_diff",
                           "SE_Basal_SC", "SE_Basal_KD_Diff", "SE_SC_slope", "SE_KD_slope_diff",
                           "p_Basal_SC", "p_Basal_KD_Diff", "p_SC_slope", "p_KD_slope_diff",
                           "95%CI_Basal_SC", "95%CI_Basal_KD_Diff", "95%CI_SC_slope", "95%CI_KD_slope_diff",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                         "Multiplel_r.sq")
                        
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_SC = p.adjust(p_Basal_SC, method = "fdr"),
           p.adj_Basal_KD_Diff = p.adjust(p_Basal_KD_Diff, method = "fdr"),
           p.adj_SC_slope = p.adjust(p_SC_slope, method = "fdr"),
           p.adj_KD_slope_diff = p.adjust(p_KD_slope_diff, method = "fdr"))
  
  return(output.df)
}

# calculate lme using the created function
output.mf3.2 <- calculate_lm(mf3.2)
## Got warning message: boundary (singular) fit: see help('isSingular')
## Suggest random effect is very small?  https://stackoverflow.com/questions/60028673/lme4-error-boundary-singular-fit-see-issingular

View(output.mf3.2)
output.mf3.2 <- output.mf3.2[c(1,2,6,10,14,23,3,7,11,15,24,4,8,12,16,25,5,9,13,17,26,18,19,20,21,22)]
write.csv(output.mf3.2, "Output/Log2 transformed Lipid Data_lm_results.csv", row.names = F)

output.mf3.3 <- output.mf3.2 %>% filter(p_KD_slope_diff < 0.05)
################################################################################
#Fit Separate CellLine LMs 
data <- read.csv("Output/Log2 IS normalized lipidomics long.csv", check.names = F)
sc <- filter(data, CellLine == "SC")
kd <- filter(data, CellLine == "KD")

# Remove columns with missing values
sc <- sc %>% select_if(~all(!is.na(.)))


#LM for SC cellLine
i=1
input=sc
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ Time")
    model_sc <- lm(formula, data = input) 
    s <- summary(model_sc)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(s$coefficients)
    fixed_est <- fixed_df[1:2,1]
    fixed_SE <- fixed_df[1:2,2]
    fixed_p <- fixed_df[1:2,4]
    df_coef <- df.residual(model_sc)
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model_sc))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:2, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model_sc)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model_sc)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model_sc)$r.squared
    f_statistic <- summary(model_sc)$fstatistic[1]
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 df_coef,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_SC","SC_slope", 
                           "SE_Basal_SC", "SE_SC_slope",
                           "p_Basal_SC",  "p_SC_slope",
                           "df",
                           "95%CI_Basal_SC",  "95%CI_SC_slope",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                           "Multiplel_r.sq")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_SC = p.adjust(p_Basal_SC, method = "fdr"),
           p.adj_SC_slope = p.adjust(p_SC_slope, method = "fdr"))
  
  return(output.df)
}


# calculate lme using the created function
output.sc <- calculate_lm(sc)
write.csv(output.sc, "Output/LM SC Lipids.csv", row.names = T)



# LM for KD CellLine
i=1
input=kd
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ Time")
    model_kd <- lm(formula, data = input) 
    k <- summary(model_kd)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(k$coefficients)
    fixed_est <- fixed_df[1:2,1]
    fixed_SE <- fixed_df[1:2,2]
    fixed_p <- fixed_df[1:2,4]
    df_coef <- df.residual(model_kd)
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model_kd))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:2, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model_kd)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model_kd)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model_kd)$r.squared
    f_statistic <- summary(model_kd)$fstatistic[1]
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 df_coef,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_KD","KD_slope", 
                           "SE_Basal_KD", "SE_KD_slope",
                           "p_Basal_KD",  "p_KD_slope",
                           "df",
                           "95%CI_Basal_KD",  "95%CI_KD_slope",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                           "Multiplel_r.sq")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_KD = p.adjust(p_Basal_KD, method = "fdr"),
           p.adj_KD_slope = p.adjust(p_KD_slope, method = "fdr"))
  
  return(output.df)
}
# calculate lm using the created function
output.kd <- calculate_lm(kd)
write.csv(output.kd, "Output/LM KD Lipids.csv", row.names = T)


output.kd1 <- output.kd [,2:17]
rownames(output.kd1) <- output.kd$metabolites
output.kd2 <- output.kd1 [c(2,4,7)]
output.kd2 <- as.data.frame(lapply(output.kd2, as.numeric))
rownames(output.kd2) <- output.kd$metabolites


output.sc1 <- output.sc [,2:17]
rownames(output.sc1) <- output.sc$metabolites
output.sc2 <- output.sc1 [c(2,4,7)]
output.sc2 <- as.data.frame(lapply(output.sc2, as.numeric))
rownames(output.sc2) <- output.sc$metabolites


t_test_custom <- function(mean1, se1, df1, mean2, se2, df2) {
  pooled_se <- sqrt((se1^2 / df1) + (se2^2 / df2))
  t_value <- (mean1 - mean2) / pooled_se
  df_pooled <- df1 + df2
  
  p_value <- 2 * pt(-abs(t_value), df = df_pooled)
  
  result <- data.frame(
    t_value = t_value,
    df_pooled = df_pooled,
    p_value = p_value
  )
  
  return(result)
}

# Assuming `output.sc2` and `output.kd2` are your data frames with rownames set
# Find common row names
common_rownames <- intersect(rownames(output.sc2), rownames(output.kd2))

# Subset the data frames to keep only the matching rows
output.sc2_matched <- output.sc2[common_rownames, ]
output.kd2_matched <- output.kd2[common_rownames, ]

# Perform the t-test on the matched rows
result <- t_test_custom(
  output.sc2_matched$SC_slope,
  output.sc2_matched$SE_SC_slope,
  output.sc2_matched$df,
  output.kd2_matched$KD_slope,
  output.kd2_matched$SE_KD_slope,
  output.kd2_matched$df
)


result_table <- as.data.frame(result)
rownames(result_table) <- output.sc$metabolites
adjusted_p_values <- as.data.frame(p.adjust(result_table$p_value, method = "BH"))
rownames(adjusted_p_values) <- output.sc$metabolites

# Add a column with row names to each data frame
output.sc2$metabolites <- rownames(output.sc2)
output.kd2$metabolites <- rownames(output.kd2)
adjusted_p_values$metabolites <- rownames(adjusted_p_values)
result_table$metabolites <- rownames(result_table)

merged_stats <- merge(merge(merge(output.sc2, output.kd2, by = "metabolites", all = TRUE), result_table, by = "metabolites", all = TRUE), adjusted_p_values, by = "metabolites", all = TRUE)

merged_stats <- merged_stats[c(1,2,3,5,6,10,11)]

write.csv(merged_stats, "Output/Fixed Time estimates stats (SC v KD).csv", row.names = T)

merged_stats.2 <- merged_stats %>% filter(merged_stats$`p.adjust(result_table$p_value, method = "BH")` < 0.05)
################################################################################
################################################################################
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("limma")
library(limma)


exprs <- read.csv("Output/Log2 IS normalized lipidomics II.csv", header = TRUE, row.names = 1) #expression data
sample_info <- read.csv("Output/IS normalized lipid metadata.csv", header = TRUE, row.names = 1) #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make time a categorical variable
sample_info$Time <- factor(sample_info$Time, levels=c("0","1","2", "3")) 
levels(sample_info$Time)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Time, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  CellLineKD_Time0 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "0"),
  CellLineKD_Time1 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "1"),
  CellLineKD_Time2 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "2"),
  CellLineKD_Time3 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "3"),
  CellLineSC_Time0 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "0"),
  CellLineSC_Time1 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "1"),
  CellLineSC_Time2 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "2"),
  CellLineSC_Time3 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "3")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  #CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_starvation(time 3).csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_starvation(time 3).csv", row.names = F)
################################################################################
################################################################################
#hotellin T^2 statistic

# Install and load the multcomp package
if (!requireNamespace("multcomp", quietly = TRUE)) {
  install.packages("multcomp")
}
if (!requireNamespace("mvtnorm", quietly = TRUE)) {
  install.packages("mvtnorm")
}
if (!requireNamespace("Hotelling", quietly = TRUE)) {
  install.packages("Hotelling")
}

library(multcomp)
library(mvtnorm)
library(Hotelling)


data <- read.csv("Output/Log2 transformed Lipid Data long.csv", check.names = F)
sc <- filter(data, CellLine == "SC")
kd <- filter(data, CellLine == "KD")

#filter to include only columns with samples
sc_f <- sc[,-(1:3)]
kd_f <- kd[,-(1:3)]

# Function to perform Hotelling's T-squared test for each column
perform_hotelling_test <- function(sc_f, kd_f) {
  num_columns <- ncol(sc_f)
  
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(sc_f)))
  
  for (i in 1:num_columns) {
    col_sc_f <- sc_f[, i]
    col_kd_f <- kd_f[, i]
    
    # Perform Hotelling's T-squared test for each column
    result <- hotelling.test(matrix(col_sc_f), matrix(col_kd_f))
    
    
    # Extract the Hotelling's T-squared statistic and p-value
    T_squared_statistic <- result[["stats"]][["statistic"]]
    p_value <- result$pval
    
    # save in output dataframe
    results <- c(T_squared_statistic,
                 p_value)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(sc_f)
  rownames(output.df) <- c("hotelling^T2", 
                           "p_value")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj = p.adjust(p_value, method = "fdr"))
  
  return(output.df)
  
}


# Perform Hotelling's T-squared test for each column
output_hot<-perform_hotelling_test(sc_f, kd_f)

write.csv(output_hot, "Output/Hotelling-T2 stat.csv", row.names = F)
output_hot <- output_hot %>% filter(p.adj < 0.05)










################################################################################
#Plot Scatter Plots

scat <- read.csv("Output/Log2 IS normalized lipidomics long.csv", check.names = F)

# Extract the first three columns
scat_f <- scat[, 1:3]

# Extract columns with "TG" "DG" "MG" in their name
tg_columns <- scat[, grep("TG", names(scat))]
dg_columns <- scat[, grep("DG", names(scat))]
mg_columns <- scat[, grep("MG", names(scat))]

# Combine the first three columns and TG columns
scat_tg <- cbind(scat_f, tg_columns)
write.csv(scat_tg, "Output/Log2 transformed Triacylglycerols.csv", row.names = F)
# Extract numeric columns (excluding non-numeric columns like ID)
numeric_data <- scat_tg[, 4:14]
# Calculate column-wise z-scores
z_scores <- scale(numeric_data)
# Combine z-scores with non-numeric columns
scat_tg2 <- cbind(scat_tg[, 1:2], as.data.frame(z_scores))
write.csv(scat_tg2, "Output/Log2 transformed Triacylglycerols z scores.csv", row.names = F)


scat_dg <- cbind(scat_f, dg_columns)
# Extract numeric columns (excluding non-numeric columns like ID)
write.csv(scat_dg, "Output/Log2 transformed Diacylglycerols.csv", row.names = F)
numeric_data <- scat_dg[, 4:47]
# Calculate column-wise z-scores
z_scores <- scale(numeric_data)
# Combine z-scores with non-numeric columns
scat_dg2 <- cbind(scat_dg[, 1:2], as.data.frame(z_scores))
write.csv(scat_dg2, "Output/Log2 transformed Diacylglycerols z scores.csv", row.names = F)


#scat_mg <- cbind(scat_f, mg_columns)
# Extract numeric columns (excluding non-numeric columns like ID)
#write.csv(scat_mg, "Output/Log2 transformed Monoacylglycerols.csv", row.names = F)
#numeric_data <- scat_mg[, 4:7]
# Calculate column-wise z-scores
#z_scores <- scale(numeric_data)
# Combine z-scores with non-numeric columns
#scat_mg2 <- cbind(scat_mg[, 1:2], as.data.frame(z_scores))
#write.csv(scat_mg2, "Output/Log2 transformed Monoacylglycerols z scores.csv", row.names = F)


install.packages("viridis")
library(ggplot2)
library(tidyr)
library(dplyr)
library(RColorBrewer)
library(viridis)
install.packages("ggbeeswarm")
library(ggbeeswarm)

scat_tg2 <- read.csv("Output/Log2 transformed Triacylglycerols z scores.csv", check.names = F)
scat_dg2 <- read.csv("Output/Log2 transformed Diacylglycerols z scores.csv", check.names = F)
#scat_mg2 <- read.csv("Output/Log2 transformed Monoacylglycerols z scores.csv", check.names = F)

# Reshape TG data to long format for ggplot
scat_tg_long <- scat_tg2 %>%
  pivot_longer(cols = starts_with("TG"), names_to = "TG", values_to = "Intensity")
scat_tg_long$CellLine <- factor(scat_tg_long$CellLine, levels = c("SC", "KD"))
# Calculate the mean for each combination of Time, CellLine, and TG
mean_data <- scat_tg_long %>%
  group_by(CellLine, Time, TG) %>%
  summarize(
    AvgIntensity = mean(Intensity),
    SEM = sd(Intensity) / sqrt(n())
  )
# Reorder TG variable based on average intensity
mean_data$TG <- factor(mean_data$TG, levels = levels(factor(mean_data$TG))[order(mean_data$AvgIntensity, decreasing = TRUE)])
# Calculate the mean for each combination of Time, CellLine for line graph
mean_data2 <- scat_tg_long %>%
  group_by(CellLine, Time) %>%
  summarize(AvgIntensity = mean(Intensity))

# Generate 17 visually distinct colors using the viridis palette
my_colors <- c(
  "#8B0000", "#006400", "cyan", "violetred", "#008B8B", 
  "#ff7f00", "darkblue", "burlywood",  "#e31a1c","#33a02c", 
  "#1E90FF", "#2F4F4F", "#8B4513", "#4682B4", "gold", 
  "sienna1")
# Specify the number of colors you need
num_colors <- 17
# Generate 4 visually distinct colors using the viridis palette
my_colors <- plasma(num_colors)

#ggplot() +
#  geom_point(data = mean_data, aes(x = Time, y = AvgIntensity, color = TG),
#             position = position_jitter(width = 0.05), size = 3) +
#  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
#            position = position_dodge(0.5), size = 0.5, linetype = "dashed", color = "black") +
#  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "black", size = 3) +
#  labs(x = "Time (hrs)", y = "z-scores") +
#  facet_wrap(~CellLine) +
#  scale_color_manual(name = " ", values = my_colors) +  # Use viridis color palette
#  theme_bw() +
#  theme(legend.key.size = unit(2, "mm"), strip.background = element_rect(fill = "white"))

##############
ggplot() +
  geom_point(data = scat_tg_long, aes(x = Time, y = Intensity, color = TG),
             position = position_jitter(width = 0.05), size = 1) +
  labs(x = "Time (hrs)", y = "z-scores") +
  facet_wrap(~CellLine) +
  scale_color_manual(name = " ", values = my_colors) +
  geom_beeswarm(data = mean_data, aes(x = Time, y = AvgIntensity, color = TG), alpha = 0.5, cex = 3, size = 3, method = "center", dodge.width = 0.01) +
  geom_line(data = mean_data, aes(x = Time, y = AvgIntensity, group = TG, color = TG), size = 0.5, alpha = 0.5) +
  theme_bw() +
  theme(
    legend.key.size = unit(1, "mm"),  # Adjust legend key size
    legend.text = element_text(size = 7.5),  # Adjust legend text size
    strip.background = element_rect(fill = "white"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "bottom",  # Change legend position
    legend.margin = margin(t = 0, r = 10, b = 0, l = 0),  # Adjust legend margin
    plot.margin = margin(10, 10, 10, 10)) +
  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
            position = position_dodge(0.5), size = 1.2, color = "black") +
  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "black", size = 3) 



#################
# Reshape DG data to long format for ggplot
scat_dg_long <- scat_dg2 %>%
  pivot_longer(cols = starts_with("DG"), names_to = "DG", values_to = "Intensity")
scat_dg_long$CellLine <- factor(scat_dg_long$CellLine, levels = c("SC", "KD"))
scat_dg_long <- na.omit(scat_dg_long)
# Calculate the mean for each combination of Time, CellLine, and TG
mean_data <- scat_dg_long %>%
  group_by(CellLine, Time, DG) %>%
  summarize(AvgIntensity = mean(Intensity))
# Reorder TG variable based on average intensity
mean_data$DG <- factor(mean_data$DG, levels = levels(factor(mean_data$DG))[order(mean_data$AvgIntensity, decreasing = TRUE)])
# Calculate the mean for each combination of Time, CellLine for line graph
mean_data2 <- scat_dg_long %>%
  group_by(CellLine, Time) %>%
  summarize(AvgIntensity = mean(Intensity))
# Specify the number of colors you need
num_colors <- 67
# Generate 67 visually distinct colors using the viridis palette
my_colors <- viridis(num_colors)
#ggplot() +
#  geom_point(data = mean_data, aes(x = Time, y = AvgIntensity, color = DG),
#             position = position_jitter(width = 0.05), size = 3) +
#  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
#            position = position_dodge(0.5), size = 0.5, linetype = "dashed", color = "red4") +
#  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "red4", size = 3) +
#  labs(x = "Time (hrs)", y = "z-scores") +
#  facet_wrap(~CellLine) +
#  scale_color_manual(name = " ", values = my_colors) +  # Use viridis color palette
#  theme_bw() +
#  theme(legend.key.size = unit(2, "mm"), strip.background = element_rect(fill = "white"))+
#  guides(color = guide_legend(ncol = 2))

##############
ggplot() +
  geom_point(data = scat_dg_long, aes(x = Time, y = Intensity, color = DG),
             position = position_jitter(width = 0.05), size = 1) +
  labs(x = "Time (hrs)", y = "z-scores") +
  facet_wrap(~CellLine) +
  scale_color_manual(name = " ", values = my_colors) +
  geom_beeswarm(data = mean_data, aes(x = Time, y = AvgIntensity, color = DG), alpha = 0.5, cex = 3, size = 3, method = "center", dodge.width = 0.01) +
  geom_line(data = mean_data, aes(x = Time, y = AvgIntensity, group = DG, color = DG), size = 0.5, alpha = 0.5) +
  theme_bw() +
  theme(legend.text = element_text(size = 5),  # Adjust legend text size
        strip.background = element_rect(fill = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.key.size = unit(1, "mm"))+
  guides(color = guide_legend(ncol = 2)) +
  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
            position = position_dodge(0.5), size = 1.2, color = "black") +
  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "black", size = 3)


##############
# Reshape MG data to long format for ggplot
scat_mg_long <- scat_mg2 %>%
  pivot_longer(cols = starts_with("MG"), names_to = "MG", values_to = "Intensity")
scat_mg_long$CellLine <- factor(scat_mg_long$CellLine, levels = c("SC", "KD"))
# Calculate the mean for each combination of Time, CellLine, and TG
mean_data <- scat_mg_long %>%
  group_by(CellLine, Time, MG) %>%
  summarize(AvgIntensity = mean(Intensity))
# Reorder MG variable based on average intensity
mean_data$MG <- factor(mean_data$MG, levels = levels(factor(mean_data$MG))[order(mean_data$AvgIntensity, decreasing = TRUE)])
# Calculate the mean for each combination of Time, CellLine for line graph
mean_data2 <- scat_mg_long %>%
  group_by(CellLine, Time) %>%
  summarize(AvgIntensity = mean(Intensity))
# Specify the number of colors you need
num_colors <- 4
# Generate 4 visually distinct colors using the viridis palette
my_colors <- plasma(num_colors)
#ggplot() +
#  geom_point(data = mean_data, aes(x = Time, y = AvgIntensity, color = MG),
#             position = position_jitter(width = 0.05), size = 3) +
#  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
#            position = position_dodge(0.5), size = 0.5, linetype = "dashed", color = "black") +
#  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "black", size = 3) +
#  labs(x = "Time (hrs)", y = "z-scores") +
#  facet_wrap(~CellLine) +
#  scale_color_manual(name = " ", values = my_colors) +  # Use viridis color palette
#  theme_bw() +
#  theme(legend.key.size = unit(2, "mm"), strip.background = element_rect(fill = "white"))+
#  guides(color = guide_legend(ncol = 1))
####################
ggplot() +
  geom_point(data = scat_mg_long, aes(x = Time, y = Intensity, color = MG),
             position = position_jitter(width = 0.05), size = 1) +
  labs(x = "Time (hrs)", y = "z-scores") +
  facet_wrap(~CellLine) +
  scale_color_manual(name = " ", values = my_colors) +
  geom_beeswarm(data = mean_data, aes(x = Time, y = AvgIntensity, color = MG), alpha = 0.5, cex = 3, size = 3, method = "center", dodge.width = 0.01) +
  geom_line(data = mean_data, aes(x = Time, y = AvgIntensity, group = MG, color = MG), size = 0.5, alpha = 0.5) +
  theme_bw() +
  theme(legend.text = element_text(size = 8),  # Adjust legend text size
        strip.background = element_rect(fill = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.key.size = unit(1, "mm"))+
  guides(color = guide_legend(ncol = 1)) +
  geom_line(data = mean_data2, aes(x = Time, y = AvgIntensity, color = CellLine, group = CellLine),
            position = position_dodge(0.5), size = 1.2, color = "black") +
  geom_point(data = mean_data2, aes(x = Time, y = AvgIntensity), color = "black", size = 3)
################################################################################
#Scatter plot for Lipid Classes (Glycerolipids)
scat_tg <- read.csv("Output/Log2 transformed Triacylglycerols.csv", check.names = F)
scat_dg <- read.csv("Output/Log2 transformed Diacylglycerols.csv", check.names = F)
#scat_mg <- read.csv("Output/Log2 transformed Monoacylglycerols.csv", check.names = F)

#convert to long format
scat_tg_long <- scat_tg %>%
  pivot_longer(cols = starts_with("TG"), names_to = "TG", values_to = "Intensity")
#calculate sum of all TG species
sum_tg <- scat_tg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(TotalIntensity = log2(sum(2^Intensity)))
write.csv(sum_tg, "Output/log2 Total TG.csv", row.names = F)

#convert to long format
scat_dg_long <- scat_dg %>%
  pivot_longer(cols = starts_with("DG"), names_to = "DG", values_to = "Intensity")
scat_dg_long <- na.omit(scat_dg_long)
#calculate sum of all DG species
sum_dg <- scat_dg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(TotalIntensity = log2(sum(2^Intensity)))
write.csv(sum_dg, "Output/log2 Total DG.csv", row.names = F)

#convert to long format
scat_mg_long <- scat_mg %>%
  pivot_longer(cols = starts_with("MG"), names_to = "MG", values_to = "Intensity")
#calculate sum of all MG species
sum_mg <- scat_mg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(TotalIntensity = log2(sum(2^Intensity)))
write.csv(sum_mg, "Output/log2 Total MG.csv", row.names = F)
#graphs are plotted in Graphpad PRISM
################################################################################
# Fit a Linear Model to determine if trends of bulk TG, DG, and MG across time are sig different

#import log transformed intensities
bulk_tg <- read.csv("Output/Log2 transformed Triacylglycerols.csv", check.names = F)
bulk_dg <- read.csv("Output/Log2 transformed Diacylglycerols.csv", check.names = F)
bulk_mg <- read.csv("Output/Log2 transformed Monoacylglycerols.csv", check.names = F)

#convert to long format
bulk_tg_long <- bulk_tg %>%
  pivot_longer(cols = starts_with("TG"), names_to = "TG", values_to = "Intensity")
#make SC the reference factor
bulk_tg_long$CellLine <- factor(bulk_tg_long$CellLine, levels = c("SC", "KD"))
levels(bulk_tg_long$CellLine)
#calculate mean TG at each time point
mean_tg <- bulk_tg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = log2(sum(2^Intensity)))

#Bulk TG LM 
model_tg <- lm(AvgIntensity ~ CellLine * Time, data = mean_tg)
summary(model_tg)
tg <- summary(model_tg)
# Fixed effects
fixed_tg <- as.data.frame(tg$coefficients)
fixed_coeff <- fixed_tg[1:4,1]
fixed_SE <- fixed_tg[1:4,2]
fixed_p <- fixed_tg[1:4,4]

# 95% confidence intervals of fixed effect
CI_tg <- as.data.frame(confint(model_tg))
CI_tg$`95% CI` <- paste(round(CI_tg$`2.5 %`, 3), round(CI_tg$`97.5 %`,  3), sep = ", ")
CI_tgf <- CI_tg[1:4, 3]

# Extract residuals
residuals_vector <- residuals(model_tg)

# Calculate minimum, median, and maximum
residual_min <- min(residuals_vector)
residual_median <- median(residuals_vector)
residual_max <- max(residuals_vector)

# Extract residual standard error
residual_std_error <- sigma(model_tg)

# Extract multiple R-squared, F-statistic, and its p-value
multiple_r_squared <- summary(model_tg)$r.squared

# save in output dataframe
results_tg <- c(fixed_coeff,
             fixed_SE,
             fixed_p,
             CI_tgf,
             residual_std_error,
             residual_min,
             residual_median,
             residual_max,
             multiple_r_squared)

tg_results <- as.data.frame(t(results_tg))
colnames(tg_results) <- c("Basal_SC","Basal_KD_Diff","SC_slope", "KD_slope_diff",
                          "SE_Basal_SC", "SE_Basal_KD_Diff", "SE_SC_slope", "SE_KD_slope_diff",
                          "p_Basal_SC", "p_Basal_KD_Diff", "p_SC_slope", "p_KD_slope_diff",
                          "95%CI_Basal_SC", "95%CI_Basal_KD_Diff", "95%CI_SC_slope", "95%CI_KD_slope_diff",
                          "Residual_SE",
                          "Residual_min", "Residual_Median", "Residual_Max",
                          "Multiplel_r.sq")
rownames(tg_results) <- "Bulk TG"

#####DG
#convert to long format
bulk_dg_long <- bulk_dg %>%
  pivot_longer(cols = starts_with("DG"), names_to = "DG", values_to = "Intensity")
#make SC the reference factor
bulk_dg_long$CellLine <- factor(bulk_dg_long$CellLine, levels = c("SC", "KD"))
levels(bulk_dg_long$CellLine)
bulk_dg_long <- na.omit(bulk_dg_long)
#calculate mean DG at each time point
mean_dg <- bulk_dg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = log2(sum(2^Intensity)))

#Bulk DG LM 
model_dg <- lm(AvgIntensity ~ CellLine * Time, data = mean_dg)
summary(model_dg)
dg <- summary(model_dg)
# Fixed effects
fixed_dg <- as.data.frame(dg$coefficients)
fixed_coeff <- fixed_dg[1:4,1]
fixed_SE <- fixed_dg[1:4,2]
fixed_p <- fixed_dg[1:4,4]

# 95% confidence intervals of fixed effect
CI_dg <- as.data.frame(confint(model_dg))
CI_dg$`95% CI` <- paste(round(CI_dg$`2.5 %`, 3), round(CI_dg$`97.5 %`,  3), sep = ", ")
CI_dgf <- CI_dg[1:4, 3]

# Extract residuals
residuals_vector <- residuals(model_dg)

# Calculate minimum, median, and maximum
residual_min <- min(residuals_vector)
residual_median <- median(residuals_vector)
residual_max <- max(residuals_vector)

# Extract residual standard error
residual_std_error <- sigma(model_dg)

# Extract multiple R-squared, F-statistic, and its p-value
multiple_r_squared <- summary(model_dg)$r.squared

# save in output dataframe
results_dg <- c(fixed_coeff,
                fixed_SE,
                fixed_p,
                CI_dgf,
                residual_std_error,
                residual_min,
                residual_median,
                residual_max,
                multiple_r_squared)

dg_results <- as.data.frame(t(results_dg))
colnames(dg_results) <- c("Basal_SC","Basal_KD_Diff","SC_slope", "KD_slope_diff",
                          "SE_Basal_SC", "SE_Basal_KD_Diff", "SE_SC_slope", "SE_KD_slope_diff",
                          "p_Basal_SC", "p_Basal_KD_Diff", "p_SC_slope", "p_KD_slope_diff",
                          "95%CI_Basal_SC", "95%CI_Basal_KD_Diff", "95%CI_SC_slope", "95%CI_KD_slope_diff",
                          "Residual_SE",
                          "Residual_min", "Residual_Median", "Residual_Max",
                          "Multiplel_r.sq")
rownames(dg_results) <- "Bulk DG"


#####MG
#convert to long format
bulk_mg_long <- bulk_mg %>%
  pivot_longer(cols = starts_with("MG"), names_to = "MG", values_to = "Intensity")
#make SC the reference factor
bulk_mg_long$CellLine <- factor(bulk_mg_long$CellLine, levels = c("SC", "KD"))
levels(bulk_mg_long$CellLine)
#calculate mean DG at each time point
mean_mg <- bulk_mg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = log2(sum(2^Intensity)))

#Bulk MG LM 
model_mg <- lm(AvgIntensity ~ CellLine * Time, data = mean_mg)
summary(model_mg)
mg <- summary(model_mg)
# Fixed effects
fixed_mg <- as.data.frame(mg$coefficients)
fixed_coeff <- fixed_mg[1:4,1]
fixed_SE <- fixed_mg[1:4,2]
fixed_p <- fixed_mg[1:4,4]
# 95% confidence intervals of fixed effect
CI_mg <- as.data.frame(confint(model_mg))
CI_mg$`95% CI` <- paste(round(CI_mg$`2.5 %`, 3), round(CI_mg$`97.5 %`,  3), sep = ", ")
CI_mgf <- CI_mg[1:4, 3]

# Extract residuals
residuals_vector <- residuals(model_mg)

# Calculate minimum, median, and maximum
residual_min <- min(residuals_vector)
residual_median <- median(residuals_vector)
residual_max <- max(residuals_vector)

# Extract residual standard error
residual_std_error <- sigma(model_mg)

# Extract multiple R-squared, F-statistic, and its p-value
multiple_r_squared <- summary(model_mg)$r.squared

# save in output dataframe
results_mg <- c(fixed_coeff,
                fixed_SE,
                fixed_p,
                CI_dgf,
                residual_std_error,
                residual_min,
                residual_median,
                residual_max,
                multiple_r_squared)

mg_results <- as.data.frame(t(results_mg))
colnames(mg_results) <- c("Basal_SC","Basal_KD_Diff","SC_slope", "KD_slope_diff",
                          "SE_Basal_SC", "SE_Basal_KD_Diff", "SE_SC_slope", "SE_KD_slope_diff",
                          "p_Basal_SC", "p_Basal_KD_Diff", "p_SC_slope", "p_KD_slope_diff",
                          "95%CI_Basal_SC", "95%CI_Basal_KD_Diff", "95%CI_SC_slope", "95%CI_KD_slope_diff",
                          "Residual_SE",
                          "Residual_min", "Residual_Median", "Residual_Max",
                          "Multiplel_r.sq")
rownames(mg_results) <- "Bulk MG"



# Extract rows
dg_row <- dg_results[1, ]
mg_row <- mg_results[1,]
# merge TG, DG and MG data
stats_ag <- rbind(tg_results, dg_row, mg_row)
#reorder columns
stats_ag <- stats_ag[c(1,5,9,13,2,6,10,14,3,7,11,15,4,8,12,16,17,18,19,20,21)]
write.csv(stats_ag, "Output/LM Bulk Acylglycerols.csv", row.names = T)

################################################################################


################################################################################
# How do the slopes of bulk TG, DG, MG compare to each other in both sc and KD?
tg <- read.csv("Output/Log2 transformed Triacylglycerols.csv", check.names = F)
dg <- read.csv("Output/Log2 transformed Diacylglycerols.csv", check.names = F)
#mg <- read.csv("Output/Log2 transformed Monoacylglycerols.csv", check.names = F)

# Reshape TG data to long format
tg_long <- tg %>%
  pivot_longer(cols = starts_with("TG"), names_to = "TG", values_to = "Intensity")
# Calculate the mean for each combination of Time, CellLine, and Replicate
mean_tg <- tg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = mean(Intensity))
# Group by cellLine and Replicate, then calculate the difference between different levels of time
result <- mean_tg %>%
  group_by(CellLine, Replicate) %>%
  arrange(Time) %>%
  mutate(Slope = AvgIntensity - lag(AvgIntensity, default = first(AvgIntensity)))
write.csv(result, "Output/Bulk TG Means and slopes.csv", row.names = T)



# Reshape DG data to long format
dg_long <- dg %>%
  pivot_longer(cols = starts_with("DG"), names_to = "DG", values_to = "Intensity")
dg_long <- na.omit(dg_long)
# Calculate the mean for each combination of Time, CellLine, and Replicate
mean_dg <- dg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = mean(Intensity))

# Group by cellLine and Replicate, then calculate the difference between different levels of time
result_dg <- mean_dg %>%
  group_by(CellLine, Replicate) %>%
  arrange(Time) %>%
  mutate(Slope = AvgIntensity - lag(AvgIntensity, default = first(AvgIntensity)))
write.csv(result_dg, "Output/Bulk DG Means and slopes.csv", row.names = T)


# Reshape MG data to long format
mg_long <- mg %>%
  pivot_longer(cols = starts_with("MG"), names_to = "MG", values_to = "Intensity")
# Calculate the mean for each combination of Time, CellLine, and Replicate
mean_mg <- mg_long %>%
  group_by(CellLine, Time, Replicate) %>%
  summarize(AvgIntensity = mean(Intensity))

# Group by cellLine and Replicate, then calculate the difference between different levels of time
result_mg <- mean_mg %>%
  group_by(CellLine, Replicate) %>%
  arrange(Time) %>%
  mutate(Slope = AvgIntensity - lag(AvgIntensity, default = first(AvgIntensity)))
write.csv(result_mg, "Output/Bulk MG Means and slopes.csv", row.names = T)


################################################################################
################################################################################
################################################################################
#Pathway Enrichment Analysis on LIPEA

#m1 <- read.csv("Output/TIC normalized lipid data.csv", check.names = F)
m1 <- read.csv("Output/Limma lipid results_Pre starvation(time 0).csv", check.names = F)
m2 <- read_excel("Input/LipidLynxX-Link.xlsx")

# Merge the data frames based on the 'Metabolite name' column
m3 <- merge(m1, m2, by = "Metabolite.name", all.x = TRUE)

m4 <- m3 %>% filter (adj.P.Val < 0.05) 

m14 <- m4[complete.cases(m4$kegg), ]
m14 <- m14[c(1,17,10,2,6)]
write.csv(m14, "Statistics/Lipid list at time 0_Network explorer.csv", row.names = T)

m5 <- m4 %>% filter (logFC > 0)

m6 <- m4 %>% filter (logFC < 0)

write.csv(m5, "Statistics/Upregulated list at Time0.csv", row.names = T)
write.csv(m6, "Statistics/downregulated list at Time0.csv", row.names = T)

m7 <- read.csv("Output/Limma lipid results_starvation time points.csv", check.names = F)


# Merge the data frames based on the 'Metabolite name' column
m8 <- merge(m7, m2, by = "Metabolite.name", all.x = TRUE)

m9 <- m8 %>% filter (adj.P.Val < 0.05) 

m10 <- m9 %>% filter (logFC > 0)

m11 <- m9 %>% filter (logFC < 0)

write.csv(m10, "Statistics/Upregulated list_starv.csv", row.names = T)
write.csv(m11, "Statistics/downregulated list_starv.csv", row.names = T)
#################################################################################
#install.packages("tidyverse")
library(tidyverse)
#install.packages("readxl")
library(readxl)
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("org.Hs.eg.db")
library(org.Hs.eg.db) # for converting rat gene IDs
BiocManager::install("clusterProfiler")
BiocManager::install("ReactomePA")
library("ReactomePA") # for Reactome
library("clusterProfiler") # for any other gene set knowledgebases
# Install the babelgene package
install.packages("babelgene")
# Load the babelgene package
library(babelgene)

res <- read.csv("Input/Unnorm Sig hits_SCvKD_PA.csv", check.names = F)
#remove rows with multiple protein IDs
res <- res[!grepl(";", res$Genes),]
#remove rows with empty Genes
res <- subset(res, !res$Genes == "")
#remove duplicated genes
res <- res[!duplicated(res[["Genes"]]) & !duplicated(res[["Genes"]], fromLast = TRUE), ]


# Convert rat genes to human genes
human_genes <- data.frame(orthologs(res$Genes, "rat", human = F))
human_genes <- human_genes[c(5,1,2)]
names(human_genes)[names(human_genes) == "symbol"] <- "Genes"

# Merge the data frames based on the 'Genes' column
res_2 <- merge(res, human_genes, by = "Genes", all.x = TRUE)

res_2 <- na.omit(res_2)

# remove duplicate genes
res_2 <- res_2[!duplicated(res_2[["Genes"]]) & !duplicated(res_2[["Genes"]], fromLast = TRUE), ]


res_2 <- res_2[c(1,4,5,2,3)]
write.csv(res_2, "Statistics/Prot list at time0_Network explorer.csv", row.names = TRUE)


################################################################################
################################################################################
#Volcano Plots

library(ggplot2)
library(ggrepel)

unstarved <- read.csv("Output/Limma lipid results_prestarvation(time 0).csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(unstarved$logFC), max(unstarved$logFC))))

#label dots with biggest positive FC
label_point <- unstarved %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 20) 

#label dots with smallest negative FC
label_point2 <- unstarved %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 20) 

#label dots with highest logP val
label_point3 <- unstarved %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 20) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(unstarved, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (Time 0)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  ylim(c(0,6)) +
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Metabolite.name),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 6-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Metabolite.name),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -6-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )

volcano_plot
ggsave(filename="volcano plot_Time 0.pdf",width=6.15,height=5.74,units="in")
ggsave(filename="volcano plot_Time 0.svg",width=6.15,height=5.74,units="in")


#########################################

starved <- read.csv("Output/Limma lipid results_starvation(time 3).csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(starved$logFC), max(starved$logFC))))

#label dots with biggest positive FC
label_point <- starved %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 12) 

#label dots with smallest negative FC
label_point2 <- starved %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 20) 

#label dots with highest logP val
label_point3 <- starved %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 12) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(starved, aes(x=logFC,y= -log10(adj.P.Val))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = 'dashed', color = "black") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "black") +
  labs(title = "KD/SC (Time 3)") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) + 
  xlim(c(-10, 10)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Metabolite.name),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 6-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Metabolite.name),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    show.legend = F
  )

volcano_plot
ggsave(filename="volcano plot_Time 3.pdf",width=6.15,height=5.74,units="in")
ggsave(filename="volcano plot_Time 3.svg",width=6.15,height=5.74,units="in")


################################################################################
#trend relationship
trend <- read.csv("Output/Fixed Time estimates stats (SC v KD).csv", check.names = F)
#trend <- trend[,-1]

# Clean up column names
colnames(trend) <- make.names(colnames(trend))
#remove rows with NA values
trend <- na.omit(trend)


#find difference between slopes
trend$slope_diff <- (abs(trend$KD_slope) - abs(trend$SC_slope))

# Assuming your data frame is named 'trend'
trend$SC_slope <- round(trend$SC_slope, 2)
trend$KD_slope <- round(trend$KD_slope, 2)

# Assuming your data frame is named 'your_data' and the column you want to transform is 'your_column'
trend$logP.adj <- -log10(trend$p.adjust.result_table.p_value..method....BH..)
#filter based on hits with the highest confidence (for option 2)
#trend <- trend %>% filter(p.adj.BH.meth < 0.01)

# For each cell line, added a column to label the directions of change as Up, Down, or NS.
trend$SC_slope.direction <- ifelse(trend$SC_slope>0,"Up", "Down")
trend$KD_slope.direction <- ifelse(trend$KD_slope>0,"Up", "Down")

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"
trend$Intersect_direction <- ifelse(trend[, 11] == trend[, 12], 
                                    ifelse(trend[, 11] == "Down", "Down", "Up"), 
                                    "Different direction")

#quandrant_plot <- ggplot(trend, aes(SC_slope, KD_slope, size = abs(slope_diff))) +
#  geom_point(aes(color = logP.adj), show.legend = T) +
#  theme_minimal() +
#  labs(title = " ", x = expression(paste(italic(m[SC]))),
#       y = expression(paste(italic(m[KD])))) +
#  geom_hline(yintercept = 0, color = "black") +
 # geom_vline(xintercept = 0, color = "black") +
  #scale_x_continuous(limits = c(-0.7, 0.7), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
  #scale_y_continuous(limits = c(-0.6, 0.6), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
#  scale_size_continuous(range = c(0.1, 4), name = expression(paste("(", italic(abs(m[KD]-m[SC])), ")"))) +
 # scale_color_gradient(low = "ivory2", high = "chocolate4", name = "logP.adj") +
 # theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 0.25))

#option 1
quandrant_plot <- ggplot(trend, aes(SC_slope, KD_slope, size = logP.adj, color = ifelse(p.adjust.result_table.p_value..method....BH.. > 0.05, "grey", ifelse(Intersect_direction == "Different direction", "black", ifelse(slope_diff > 0, "indianred3", "deepskyblue3"))))) +
  geom_point(show.legend = TRUE) +
  scale_color_manual(
    values = c("indianred3" = "indianred3", "deepskyblue3" = "deepskyblue3", "black" = "black"),
    breaks = c("indianred3", "deepskyblue3", "black"),
    labels = c("Higher rate in KD", "Lower rate in KD", "Different Direction"),
    name = " "
  ) +
  scale_size_continuous(range = c(1, 3), name = "logP.adj") +
  theme_minimal() +
  labs(title = " ", x = expression(paste(italic(m[SC]))),
       y = expression(paste(italic(m[KD])))) +
  geom_hline(yintercept = 0, color = "black") +
  geom_vline(xintercept = 0, color = "black") +
  scale_x_continuous(limits = c(-0.7, 1.5), breaks = seq(-2, 2, 0.5), labels = seq(-2, 2, 0.5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(-0.7, 0.7), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
  theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 0.25))

quandrant_plot
# tg label points
tglabel_points <- trend %>%
  filter (p.adjust.result_table.p_value..method....BH.. < 0.05) %>%
  arrange(desc(abs(slope_diff))) %>%
  filter(startsWith(metabolites, "TG")) %>%
  slice_head(n = 5) %>%
  separate(metabolites, into = c("label", "rest"), sep = "\\|", extra = "merge")

# dg label points
dglabel_points <- trend %>%
  filter (p.adjust.result_table.p_value..method....BH.. < 0.05) %>%
  arrange(desc(abs(slope_diff))) %>%
  filter(startsWith(metabolites, "DG")) %>%
  slice_head(n = 5) %>%
  separate(metabolites, into = c("label", "rest"), sep = "\\|", extra = "merge")

#+ve KD and -ve SC
label_points1 <- trend %>%
  filter (p.adjust.result_table.p_value..method....BH.. < 0.05) %>%
  arrange(desc(KD_slope),SC_slope) %>%
  filter(SC_slope <= 0) %>%
  slice_head(n = 4) %>%
  separate(metabolites, into = c("label", "rest"), sep = "\\|", extra = "merge")

#+ve KD and +ve SC
label_points2 <- trend %>%
  filter (p.adjust.result_table.p_value..method....BH.. < 0.05) %>%
  arrange(desc(SC_slope)) %>%
  filter(KD_slope > 0) %>%
  slice_head(n = 5) %>%
  separate(metabolites, into = c("label", "rest"), sep = "\\|", extra = "merge")

#-ve KD and +ve SC
label_points3 <- trend %>%
  filter (p.adjust.result_table.p_value..method....BH.. < 0.05) %>%
  arrange(desc(SC_slope)) %>%
  filter(KD_slope < 0) %>%
  slice_head(n = 4) %>%
  separate(metabolites, into = c("label", "rest"), sep = "\\|", extra = "merge")

# Add TG labels
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = tglabel_points,
    aes(label = label),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -0.25,
    nudge_y = -0.25,
    size=2.5,
    show.legend = F
  )
#Add DG labels
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = dglabel_points,
    aes(label = label),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = -0.2,
    nudge_y = 0.2,
    size=2.5,
    show.legend = F
  )

#Add label1
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = label_points1,
    aes(label = label),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -0.25,
    nudge_y = 0.05,
    size=2.5,
    show.legend = F
  )

#Add label2
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = label_points2,
    aes(label = label),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -0.3,
    nudge_y = 0.05,
    size=2.5,
    show.legend = F
  )

#Add label3
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = label_points3,
    aes(label = label),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 0.3,
    #nudge_y = 0.05,
    size=2.5,
    show.legend = F
  )


print(quandrant_plot)
ggsave(filename="lipid trend relationship.pdf",width=6.15,height=5.74,units="in")
ggsave(filename="lipid trend relationship.svg",width=6.15,height=5.74,units="in")
################################################################################
################################################################################
#Data Preparation for Lipid Network Analysis using LINEX2 and LipidOne Analysis
m2 <- read.csv("Output/Log2 IS normalized lipidomics II.csv", check.names = F)
m3 <- m2[,-1]
#remove rows with NA
m3 <- na.omit(m3)

#m4 <- m3 %>%
  #filter(grepl("^P", `Metabolite name`))

# Initialize the new columns with empty strings
#m4$Column1 <- ""
#m4$Column2 <- ""

# Loop through each string in 'Metabolite name'
#for (i in seq_along(m4$'Metabolite name')) {
  # Split the string using the delimiter "|"
 # split_strings <- strsplit(m4$'Metabolite name'[i], "|", fixed = TRUE)[[1]]
  
  # Extract only the desired parts using regular expressions
#  column1_value <- gsub(".* (\\d+:\\d+).*", "\\1", split_strings[1])
#  column2_value <- gsub(".* (\\d+:\\d+).*", "\\1", split_strings[2])
  
  # Assign the extracted values to the respective columns
#  m4$Column1[i] <- column1_value
#  m4$Column2[i] <- column2_value
#}


#write.csv(m4, "Output/Lipid names I.csv", row.names = F)


#clean up Lipid names
# Function to remove characters preceding and including "|" and add parentheses
#remove_prefix_add_parentheses <- function(x) {
  # Remove prefix if "|" is present
#  x <- gsub(".*\\|", "", x)
  # Add parentheses without a space after the first space and closing parenthesis at the end
 # x <- paste0(gsub(" ", "(", x, fixed = TRUE), ")")
#  return(x)
#}
# Apply the function to the specified column
#m3$`Metabolite name` <- sapply(m3$`Metabolite name`, remove_prefix_add_parentheses)
write.csv(m3, "Statistics/log2 lipid data_cleaned names.csv", row.names = F)
ats <- m3
#################### LINEX2
#identify the lipid class
m3 <- m3 %>%
  mutate(Class = sub("\\(.*", "", `Metabolite name`))
#LINEX supported lipid classes
j <- read.csv("Statistics/standard_lipid_classes.csv", check.names = F)
#filter for only LINEX supported classes
m4 <- m3[m3$Class %in% j$Class, ]

m5<- m4[c(1:25)]
m4.1 <- m4[c(1)]

#export lipid names and convert to lipidlynxX nomenclature
write.csv(m4.1, "Statistics/lipid names for lipidlynxX.csv", row.names = F)

lynx <- read.csv("Statistics/LipidLynxX-Converter-20240612-030346-e557.csv", check.names = F)
lynx <- lynx[,-1]
lynx <- merge(lynx, m5, by = "Metabolite name", all.x = TRUE)
lynx <- lynx[,-1]

# Change the data into long format where metabolites become columns
lynx_long <- lynx %>%
  pivot_longer(cols = -Lipid, names_to = c("CellLine", "Time", "Replicate"), 
               names_sep = "_", values_to = "Abundance") %>%
  separate(CellLine, into = c("CellLine", "ID"), sep = 7) %>%
  mutate(Time = as.numeric(Time),
         Replicate = as.numeric(Replicate)) %>%
  dplyr::select(Subject = ID, CellLine, Time, Replicate, Lipid, Abundance) %>%
  spread(key = Lipid, value = Abundance) %>%
  dplyr::select(-Subject)


#filter all time 0 = non-starved
lynx.0<- lynx_long %>% filter(Time == 0)
lynx.0 <- lynx.0 %>%
  arrange(desc(CellLine))
#filter all time 3 = starved
lynx.3 <- lynx_long %>% filter(Time == 3)
lynx.3 <- lynx.3 %>%
  arrange(desc(CellLine))

write.csv(lynx.0, "Statistics/lipid_data_unstarved.csv", row.names = F)
write.csv(lynx.3, "Statistics/lipid_data_starved.csv", row.names = F)


#################### LipidONE
k <- read.csv("Statistics/LipidLynxX-shorthand_lipidone.csv", check.names = F)
ats <- ats[ats$`Metabolite name` %in% k$`Metabolite name`, ]
#convert to antilog
ats[, -1] <- 2 ^ ats[, -1]

lone <- merge(ats, k, by = "Metabolite name", all.x = TRUE)
lone <- lone[c(27,2:25)]

#unstarved samples
lone.0 <- lone[c(1,2:4,14:16)]

#3H starved samples
lone.3 <- lone[c(1,11:13,23:25)]

write.csv(lone.0, "Statistics/lipid_data_unstarved_Lone.csv", row.names = F)
write.csv(lone.3, "Statistics/lipid_data_starved_Lone.csv", row.names = F)
################################################################################
################################################################################
#Lipid Profile Overview Before Starvation
prof <- read.csv("Output/IS normalized lipidomics.csv", check.names = F)
prof <- prof[,-1]


#filter to remove unknown classes and vit D
#prof <- prof %>%
 # filter(!Ontology %in% riken_remove)
prof <- prof[-1,]
prof<- prof[-109,]

#clean up Lipid names
# Function to remove characters preceding and including "|" and add parentheses
remove_prefix_add_parentheses <- function(x) {
  # Remove prefix if "|" is present
  x <- gsub(".*\\|", "", x)
  # Add parentheses without a space after the first space and closing parenthesis at the end
  x <- paste0(gsub(" ", "(", x, fixed = TRUE), ")")
  return(x)
}
# Apply the function to the specified column
prof$`Metabolite name` <- sapply(prof$`Metabolite name`, remove_prefix_add_parentheses)

prof <- as.data.frame(prof) %>%
  rename("SC_0_1" = "Lenti-SC_Time 0_Expt I",
         "SC_0_2" = "Lenti-SC_Time 0_Expt II",
         "SC_0_3" = "Lenti-SC_Time 0_Expt III",
         "SC_1_1" = "Lenti-SC_Time 1_Expt I",
         "SC_1_2" = "Lenti-SC_Time 1_Expt II",
         "SC_1_3" = "Lenti-SC_Time 1_Expt III",
         "SC_2_1" = "Lenti-SC_Time 2_Expt I",
         "SC_2_2" = "Lenti-SC_Time 2_Expt II",
         "SC_2_3" = "Lenti-SC_Time 2_Expt III",
         "SC_3_1" = "Lenti-SC_Time 3_Expt I",
         "SC_3_2" = "Lenti-SC_Time 3_Expt II",
         "SC_3_3" = "Lenti-SC_Time 3_Expt III",
         "KD_0_1" = "Lenti-C_Time 0_Expt I",
         "KD_0_2" = "Lenti-C_Time 0_Expt II",
         "KD_0_3" = "Lenti-C_Time 0_Expt III",
         "KD_1_1" = "Lenti-C_Time 1_Expt I",
         "KD_1_2" = "Lenti-C_Time 1_Expt II",
         "KD_1_3" = "Lenti-C_Time 1_Expt III",
         "KD_2_1" = "Lenti-C_Time 2_Expt I",
         "KD_2_2" = "Lenti-C_Time 2_Expt II",
         "KD_2_3" = "Lenti-C_Time 2_Expt III",
         "KD_3_1" = "Lenti-C_Time 3_Expt I",
         "KD_3_2" = "Lenti-C_Time 3_Expt II",
         "KD_3_3" = "Lenti-C_Time 3_Expt III")
prof<- prof[c(1:26)]
#convert to long format
prof_long <- gather(prof, key = "Sample", value = "value", -c(`Metabolite name`, Ontology))
# Extract time and replicate information from the variable column
prof_long <- prof_long %>%
  separate(Sample, into = c("CellLine","Time", "Replicate"), sep = "_") %>%
  mutate(across(c("value"), as.numeric)) 

write.csv(prof_long, "Output/lipid profile Overview.csv", row.names = F)

###########Calculate t test
#filter all time 0 = non-starved
prof_long.stat <- prof_long %>% filter(Time == 0)
# Calculate the sum for each combination of Time, CellLine, and Ontology
sum_prof.stat <- prof_long.stat %>%
  group_by(CellLine, Ontology, Replicate) %>%
  summarize(TotalIntensity = sum(value))

# Convert long format data to wide format
wide_data <- pivot_wider(sum_prof.stat, names_from = Replicate, values_from = TotalIntensity)
write.csv(wide_data, "Output/lipid profile_unstarved.csv", row.names = F)

# Create an empty data frame to store the t-test results
t_test_results <- data.frame()
# Unique ontologies in the data frame
ontologies <- unique(sum_prof.stat$Ontology)
# Loop through each ontology and perform t-test
for (ontology in ontologies) {
  kd_data <- subset(sum_prof.stat, CellLine == "KD" & Ontology == ontology)$TotalIntensity
  sc_data <- subset(sum_prof.stat, CellLine == "SC" & Ontology == ontology)$TotalIntensity
  # Perform t-test
  t_test_result <- t.test(kd_data, sc_data)
  # Store the results in the data frame
  result_row <- data.frame(Ontology = ontology,
                           t_statistic = t_test_result$statistic,
                           p_value = t_test_result$p.value)
  t_test_results <- rbind(t_test_results, result_row)
}
# Perform FDR correction
t_test_results$fdr <- p.adjust(t_test_results$p_value, method = "fdr")
# Calculate the mean for each combination of Time, CellLine, and Ontology
sum_prof <- sum_prof.stat %>%
  group_by(CellLine, Ontology) %>%
  summarize(AvgIntensity = mean(TotalIntensity),
            SEM = sd(TotalIntensity) / sqrt(length(TotalIntensity)))
#make SC the reference factor
sum_prof$CellLine <- factor(sum_prof$CellLine, levels = c("SC", "KD"))
# Merge the data
sum_prof <- merge(sum_prof, t_test_results, by = "Ontology")

# Create a new column 'label' based on significance levels
sum_prof$label <- ifelse(sum_prof$fdr < 0.001 & sum_prof$CellLine == "KD", '***',
                         ifelse(sum_prof$fdr < 0.01 & sum_prof$CellLine == "KD", '**',
                                ifelse(sum_prof$fdr < 0.05 & sum_prof$CellLine == "KD", '*', '')))
write.csv(sum_prof, "Output/lipid classes profile_unstarved.csv", row.names = F)
# Plot the data
ggplot(sum_prof, aes(x = Ontology, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = AvgIntensity + 10), position = position_dodge(width = 0.5), size = 5) +  # Add significance label
  labs(title = "Lipid profile",
       x = "Lipid Classes",
       y = "Total Intensity/TIC") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 7.5,vjust = 1.08, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 6000000)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))  # Add this line to set the colors of the bars


#################################################################################
#Chain Class distribution - class 16:0

#select lipids that contain a 16C fatty acid chain
prof_long.2 <- prof_long[grepl("16", prof_long$"Metabolite name"), ]
#filter all time 0 = non-starved
prof_long.2<- prof_long.2 %>% filter(Time == 3)

# Calculate the sum for each combination of Time, CellLine, Replicate, and Ontology
sum_prof1 <- prof_long.2 %>%
  group_by(CellLine, Replicate, Ontology) %>%
  summarize(TotalIntensity = sum(value))
# Create an empty data frame to store the t-test results
t_test_results <- data.frame()
# Unique ontologies in the data frame
ontologies <- unique(sum_prof1$Ontology)
# Loop through each ontology and perform t-test
for (ontology in ontologies) {
  kd_data <- subset(sum_prof1, CellLine == "KD" & Ontology == ontology)$TotalIntensity
  sc_data <- subset(sum_prof1, CellLine == "SC" & Ontology == ontology)$TotalIntensity
  # Perform t-test
  t_test_result <- t.test(kd_data, sc_data)
  # Store the results in the data frame
  result_row <- data.frame(Ontology = ontology,
                           t_statistic = t_test_result$statistic,
                           p_value = t_test_result$p.value)
  t_test_results <- rbind(t_test_results, result_row)
}
# Perform FDR correction
t_test_results$fdr <- p.adjust(t_test_results$p_value, method = "fdr")
# Calculate the mean for each combination of CellLine, and Ontology
sum_prof2 <- sum_prof1 %>%
  group_by(CellLine, Ontology) %>%
  summarize(AvgIntensity = mean(TotalIntensity),
            SEM = sd(TotalIntensity) / sqrt(length(TotalIntensity)))

#make SC the reference factor
sum_prof2$CellLine <- factor(sum_prof2$CellLine, levels = c("SC", "KD"))
# Merge the data
sum_prof2 <- merge(sum_prof2, t_test_results, by = "Ontology")

# Create a new column 'label' based on significance levels
sum_prof2$label <- ifelse(sum_prof2$fdr < 0.001 & sum_prof2$CellLine == "KD", '***',
                         ifelse(sum_prof2$fdr < 0.01 & sum_prof2$CellLine == "KD", '**',
                                ifelse(sum_prof2$fdr < 0.05 & sum_prof2$CellLine == "KD", '*', '')))
write.csv(sum_prof2, "Output/palmitate distribution stat_unstarved.csv", row.names = F)

ggplot(sum_prof2, aes(x = Ontology, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black",linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  labs(title = "Chain Class Distribution - 16:0",
       x = "Lipid Classes",
       y = "Total Intensity/TIC") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 7.5,vjust = 1.08, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 450)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))  # Add this line to set the colors of the bars
######################################################################################
######################################################################################
###Linear Models of Lipid Classes
vso <- read.csv("Output/lipid profile Overview.csv", check.names = F)
# Calculate the sum for each combination of Time, CellLine, and Ontology
sum_vso <- vso %>%
  group_by(CellLine, Time, Replicate, Ontology) %>%
  summarize(TotalIntensity = log2(sum(value)))
#calculate average of total intensities acrosss replicates
mean_vso <- sum_vso %>%
  group_by(Time, Ontology) %>%
  summarize(meanTotalIntensity = (mean(TotalIntensity)))
mean_vso_un <- mean_vso %>% filter (Time == 0)
mean_vso_st <- mean_vso %>% filter (Time == 3)
write.csv(mean_vso, "Output/lipid class mean total intensity.csv")
write.csv(mean_vso_un, "Output/lipid class mean total intensity(time 0).csv")
write.csv(mean_vso_st, "Output/lipid class mean total intensity(time 3).csv")


#concatenate the sample names
sum_vso$Sample <- paste(sum_vso$CellLine, sum_vso$Time, sum_vso$Replicate, sep = "_")
sum_vso <- sum_vso[-c(1:3)]

# transform the data frame
sum_vso_wide <- sum_vso %>%
  pivot_wider(names_from = "Ontology", values_from = "TotalIntensity")

#transform and save for Lipid classes Limma
transform <- t(sum_vso_wide[,-1])
colnames(transform) <- sum_vso_wide$Sample
transform <- as.data.frame(transform)
transform <- rownames_to_column(transform, var = "Lipid class")
transform <- transform[c(1,14:25,2:13)]
write.csv(transform, "Output/lipid profile Overview_II.csv")

# Extract time and replicate information from the variable column
sum_vso_wide <- sum_vso_wide %>%
  separate(Sample, into = c("CellLine","Time", "Replicate"), sep = "_") %>%
  mutate(Time = as.numeric(Time))

#SC is our reference 
sum_vso_wide$CellLine <- factor(sum_vso_wide$CellLine, levels=c("SC","KD")) 
levels(sum_vso_wide$CellLine)
write.csv(sum_vso_wide, "Output/lipid profile Overview_wide.csv", row.names = F)

data <- sum_vso_wide


#Fit one LM
sc <- filter(data, CellLine == "SC")
kd <- filter(data, CellLine == "KD")

mf3.2 <- read.csv("Output/lipid profile Overview_wide.csv", check.names = F) # 598 x 24

#SC is our reference 
mf3.2$CellLine <- factor(mf3.2$CellLine, levels=c("SC","KD")) 
levels(mf3.2$CellLine)

i=1
input=mf3.2
# create the function to calculate lm for every lipid
calculate_lm <- function(input){
  
  input.df <- input[,-(1:3)]
  output.df <- data.frame(matrix(nrow=0, ncol=ncol(input.df))) 
  
  for (i in 1:ncol(input.df)){
    
    # lm test
    ## Construct the formula (Enclose variable names with backticks)
    formula <- paste0("`",colnames(input.df)[i],"`", "~ CellLine * Time")
    model <- lm(formula, data = input) 
    s <- summary(model)
    
    # Main effects and Interactors
    fixed_df <- as.data.frame(s$coefficients)
    fixed_est <- fixed_df[1:4,1]
    fixed_SE <- fixed_df[1:4,2]
    fixed_p <- fixed_df[1:4,4]
    
    
    # 95% confidence intervals of fixed effect
    conf_intervals <- as.data.frame(confint(model))
    conf_intervals$`95% CI` <- paste(round(conf_intervals$`2.5 %`, 3), round(conf_intervals$`97.5 %`,  3), sep = ", ")
    confidence <- conf_intervals[1:4, 3]
    
    # Extract residuals
    residuals_vector <- residuals(model)
    
    # Calculate minimum, median, and maximum
    residual_min <- min(residuals_vector)
    residual_median <- median(residuals_vector)
    residual_max <- max(residuals_vector)
    
    # Extract residual standard error
    residual_std_error <- sigma(model)
    
    # Extract multiple R-squared, F-statistic, and its p-value
    multiple_r_squared <- summary(model)$r.squared
    f_statistic <- summary(model)$fstatistic[1]
    
    # Specify the overall time point of interest
    #overall_time_point <- 3
    # Obtain estimated marginal trends for each level of CellLine at the overall time point
    #trend_result <- emtrends(model, ~ CellLine | Time, var = "Time", at = list(Time = overall_time_point))
    # Perform pairwise comparisons between CellLine levels
    #pairwise_comparisons <- pairs(trend_result)
    #p_values <- summary(pairwise_comparisons)$p.value
    
    # save in output dataframe
    results <- c(fixed_est,
                 fixed_SE,
                 fixed_p,
                 confidence,
                 residual_std_error,
                 residual_min,
                 residual_median,
                 residual_max,
                 multiple_r_squared)
    
    l <- length(results)
    output.df[1:l,i] <- results
  }
  
  colnames(output.df) <- colnames(input.df)
  rownames(output.df) <- c("Basal_SC","Basal_KD_Diff","SC_slope", "KD_slope_diff",
                           "SE_Basal_SC", "SE_Basal_KD_Diff", "SE_SC_slope", "SE_KD_slope_diff",
                           "p_Basal_SC", "p_Basal_KD_Diff", "p_SC_slope", "p_KD_slope_diff",
                           "95%CI_Basal_SC", "95%CI_Basal_KD_Diff", "95%CI_SC_slope", "95%CI_KD_slope_diff",
                           "Residual_SE",
                           "Residual_min", "Residual_Median", "Residual_Max",
                           "Multiplel_r.sq")
  
  
  output.df <- as.data.frame(t(output.df)) %>%
    rownames_to_column(var="metabolites") %>% 
    mutate(p.adj_Basal_SC = p.adjust(p_Basal_SC, method = "fdr"),
           p.adj_Basal_KD_Diff = p.adjust(p_Basal_KD_Diff, method = "fdr"),
           p.adj_SC_slope = p.adjust(p_SC_slope, method = "fdr"),
           p.adj_KD_slope_diff = p.adjust(p_KD_slope_diff, method = "fdr"))
  
  return(output.df)
}

# calculate lme using the created function
output.mf3.2 <- calculate_lm(mf3.2)
## Got warning message: boundary (singular) fit: see help('isSingular')
## Suggest random effect is very small?  https://stackoverflow.com/questions/60028673/lme4-error-boundary-singular-fit-see-issingular

View(output.mf3.2)
output.mf3.2 <- output.mf3.2[c(1,2,6,10,14,23,3,7,11,15,24,4,8,12,16,25,5,9,13,17,26,18,19,20,21,22)]
write.csv(output.mf3.2, "Output/Log2 transformed Lipid Class Data_lm_results.csv", row.names = F)

output.mf3.2 <- read.csv("Output/Log2 transformed Lipid Class Data_lm_results.csv", check.names = F)
merged_stats <- output.mf3.2[c(1,12,17,19)]
#trend relationship

#find KD slope
merged_stats$KD_slope <- ((merged_stats$SC_slope) + (merged_stats$KD_slope_diff))

# round up the data
merged_stats$SC_slope <- round(merged_stats$SC_slope, 2)
merged_stats$KD_slope <- round(merged_stats$KD_slope, 2)

# Assuming your data frame is named 'your_data' and the column you want to transform is 'your_column'
merged_stats$logP.val <- -log10(merged_stats$p_KD_slope_diff)


# For each cell line, added a column to label the directions of change as Up, Down, or NS.
merged_stats$SC_slope.direction <- ifelse(merged_stats$SC_slope>0,"Up", "Down")
merged_stats$KD_slope.direction <- ifelse(merged_stats$KD_slope>0,"Up", "Down")

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"
merged_stats$Intersect_direction <- ifelse(merged_stats[, 7] == merged_stats[, 8], 
                                    ifelse(merged_stats[, 7] == "Down", "Down", "Up"), 
                                    "Different direction")

#option 1
quandrant_plot <- ggplot(merged_stats, aes(SC_slope, KD_slope, size = logP.val, color = ifelse(p_KD_slope_diff > 0.05, "black", "deepskyblue3"))) +
  geom_point(show.legend = TRUE) +
  scale_color_manual(
    values = c("deepskyblue3" = "deepskyblue3", "black" = "black"),
    breaks = c("deepskyblue3","black"),
    labels = c("Lower rate in KD", "Not significant"),
    name = " "
  ) +
  scale_size_continuous(range = c(1, 12), name = "log P.val") +
  theme_minimal() +
  labs(title = " ", x = expression(paste(italic(m[SC]))),
       y = expression(paste(italic(m[KD])))) +
  geom_hline(yintercept = 0, color = "black", size = 0.5) +
  geom_vline(xintercept = 0, color = "black", size = 0.5) +
  scale_x_continuous(limits = c(-0.3, 0.2), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 0.3), breaks = seq(-1, 1, 0.2), labels = seq(-1, 1, 0.2), expand = c(0, 0)) 
  #theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 0.25))

# Add labels with random arrangement to minimize overlap
quandrant_plot <- quandrant_plot +
  geom_text_repel(
    data = merged_stats,
    aes(label = metabolites),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 4,
    show.legend = FALSE
  ) +
  theme(legend.text = element_text(size = 12))
print(quandrant_plot)


ggsave(filename="lipid class trend relationship.pdf",width=6.38,height=5,units="in")
ggsave(filename="lipid class trend relationship.svg",width=6.38,height=5,units="in")
################################################################################
################################################################################
#Limma and Volcano plot
library(limma)

exprs <- read.csv("Output/lipid profile Overview_II.csv") #expression data
exprs <- exprs[-c(1)]
sample_info <- read.csv("Output/IS normalized lipid metadata.csv", header = TRUE, row.names = 1) #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make time a categorical variable
sample_info$Time <- factor(sample_info$Time, levels=c("0","1","2", "3")) 
levels(sample_info$Time)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Time, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  CellLineKD_Time0 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "0"),
  CellLineKD_Time1 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "1"),
  CellLineKD_Time2 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "2"),
  CellLineKD_Time3 = as.numeric(sample_info$CellLine == "KD" & sample_info$Time == "3"),
  CellLineSC_Time0 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "0"),
  CellLineSC_Time1 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "1"),
  CellLineSC_Time2 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "2"),
  CellLineSC_Time3 = as.numeric(sample_info$CellLine == "SC" & sample_info$Time == "3")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  CellLineKD_Time0 - CellLineSC_Time0,
  #CellLineKD_Time1 - CellLineSC_Time1,
  #CellLineKD_Time2 - CellLineSC_Time2,
  #CellLineKD_Time3 - CellLineSC_Time3,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

#mean_vso_st <- read.csv("Output/lipid class mean total intensity(time 3).csv")
#mean_vso_st<- mean_vso_st[,-1]
#mean_vso_st <- mean_vso_st %>%
#  rename(Lipid.class = Ontology)


mean_vso_un <- read.csv("Output/lipid class mean total intensity(time 0).csv")
mean_vso_un<- mean_vso_un[,-1]
mean_vso_un <- mean_vso_un %>%
  rename(Lipid.class = Ontology)

results <- merge(results,mean_vso_un, by = "Lipid.class")




write.csv(results, "Output/Limma lipid classes_starvation(time 0).csv", row.names = F)

results <- results %>% filter(adj.P.Val < 0.05)
########################### Volcano plot ########################################
unstarved <- read.csv("Output/Limma lipid classes_starvation(time 0).csv", check.names = F)

# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(unstarved$logFC), max(unstarved$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(unstarved, aes(x = logFC, y = -log10(adj.P.Val), size = meanTotalIntensity)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = "KD v SC (Time 0)", x = "logFC", y = "-log10(adj.P.Val)", size = "Log mean abundance") +
  theme( panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),      
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(3,7), limits = range(unstarved$meanTotalIntensity, na.rm = T)) +
  guides(color = 'none')
# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_logFC, max_abs_logFC))

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = unstarved,
    aes(label = Lipid.class),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 4,
    show.legend = FALSE
  )

# Print the plot
print(volcano_plot)
ggsave(filename="lipid class volcano plot_Time 0.pdf",width=6.38,height=5,units="in")
ggsave(filename="lipid class volcano plot_Time 0.svg",width=6.38,height=5,units="in")
#########################################

starved <- read.csv("Output/Limma lipid classes_starvation(time 3).csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(starved$logFC), max(starved$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(starved, aes(x = logFC, y = -log10(adj.P.Val), size = meanTotalIntensity)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = "KD v SC (Time 3)", x = "logFC", y = "-log10(adj.P.Val)", size = "Log mean abundance") +
  theme( panel.background = element_rect(fill = "white"),
         axis.line.y = element_line(color = "black"),
         axis.ticks.y = element_line(color = "black"),
         axis.line.x = element_line(color = "black"),      
         axis.ticks.x = element_line(color = "black"),
         plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),   
         plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(3,7), limits = c(16, max(starved$meanTotalIntensity, na.rm = TRUE))) +
  guides(color = 'none')
# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_logFC, max_abs_logFC))

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = starved,
    aes(label = Lipid.class),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 4,
    show.legend = FALSE
  )
# Print the plot
print(volcano_plot)

ggsave(filename="lipid class volcano plot_Time 3.pdf",width=6.27,height=5,units="in")
ggsave(filename="lipid class volcano plot_Time 3.svg",width=6.27,height=5,units="in")
################################################################################
#Glycerolipid Profile at pre-starved
prof_long <- read.csv("Output/lipid profile Overview.csv")
#filter all time 0 = non-starved
prof_long<- prof_long %>% filter(Time == 0)
prof_long.log <- prof_long
prof_long.log$value <- log2(prof_long.log$value)
prof_long.log <- prof_long.log[is.finite(prof_long.log$value), ]
# Remove rows where Metabolite.names are not present in both KD and SC categories
prof_long.log <- prof_long.log %>%
  group_by(Metabolite.name) %>%
  filter(all(c("KD", "SC") %in% CellLine) &
      n() >= 4  # Check that there are at least 2 values for each category
  )

###########Calculate t test
# Create an empty data frame to store the t-test results
t_test_results <- data.frame()

# Unique ontologies in the data frame
lipids <- unique(prof_long.log$Metabolite.name)

# Loop through each lipid specie and perform t-test
for (lipid in lipids) {
  kd_data <- subset(prof_long.log, CellLine == "KD" & Metabolite.name == lipid)$value
  sc_data <- subset(prof_long.log, CellLine == "SC" & Metabolite.name == lipid)$value
  
  # Perform t-test
  t_test_result <- t.test(kd_data, sc_data)
  
  # Store the results in the data frame
  result_row <- data.frame(Metabolite.name = lipid,
                           t_statistic = t_test_result$statistic,
                           p_value = t_test_result$p.value)
  
  t_test_results <- rbind(t_test_results, result_row)
}

# Perform FDR correction
t_test_results$fdr <- p.adjust(t_test_results$p_value, method = "fdr")

# Calculate the sum for each combination of Time, CellLine, and Ontology
mean_prof <- prof_long %>%
  group_by(CellLine, Metabolite.name) %>%
  summarize(AvgIntensity = mean(value),
            SEM = sd(value) / sqrt(length(value)))
# Merge the data
mean_prof <- merge(mean_prof, t_test_results, by = "Metabolite.name")

#make SC the reference factor
mean_prof$CellLine <- factor(mean_prof$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
mean_prof$label <- ifelse(mean_prof$fdr < 0.001 & mean_prof$CellLine == "KD", '***',
                         ifelse(mean_prof$fdr < 0.01 & mean_prof$CellLine == "KD", '**',
                                ifelse(mean_prof$fdr < 0.05 & mean_prof$CellLine == "KD", '*', '')))
write.csv(mean_prof, "Output/lipid species stat_unstarved.csv", row.names = F)

#filter for acylglycerol species
tg_spec <- mean_prof[grep("TG", mean_prof$Metabolite.name), ]
dg_spec <- mean_prof[grep("DG", mean_prof$Metabolite.name), ]
mg_spec <- mean_prof[grep("MG", mean_prof$Metabolite.name), ]

#tg
# Reorder TG variable based on average intensity within each CellLine
tg_spec <- tg_spec %>%
  arrange(CellLine, desc(AvgIntensity))

# Convert Metabolite.name to a factor with levels ordered by the new order
tg_spec$Metabolite.name <- factor(tg_spec$Metabolite.name, levels = unique(tg_spec$Metabolite.name))

# Plot the data (rest of the code remains unchanged)
ggplot(tg_spec, aes(x = Metabolite.name, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = AvgIntensity + 0.1), position = position_dodge(width = 0.5), size = 5) +  # Add significance label
  labs(title = "TG species profile",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 7.25, vjust = 1.08, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 15)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

#dg
# Reorder DG variable based on average intensity within each CellLine
dg_spec <- dg_spec %>%
  arrange(CellLine, desc(AvgIntensity)) 
# Convert Metabolite.name to a factor with levels ordered by the new order
dg_spec$Metabolite.name <- factor(dg_spec$Metabolite.name, levels = unique(dg_spec$Metabolite.name))
# Plot the data (rest of the code remains unchanged)
ggplot(dg_spec, aes(x = Metabolite.name, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = AvgIntensity + 0.3), position = position_dodge(width = 0.5), size = 5) +  # Add significance label
  labs(title = "DG species profile",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 4.5, vjust = 1.08, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 10)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

#mg
# Reorder DG variable based on average intensity within each CellLine
mg_spec <- mg_spec %>%
  arrange(CellLine, desc(AvgIntensity)) 

# Convert Metabolite.name to a factor with levels ordered by the new order
mg_spec$Metabolite.name <- factor(mg_spec$Metabolite.name, levels = unique(mg_spec$Metabolite.name))

# Plot the data (rest of the code remains unchanged)
ggplot(mg_spec, aes(x = Metabolite.name, y = AvgIntensity, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = AvgIntensity - SEM, ymax = AvgIntensity + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = AvgIntensity + 0.3), position = position_dodge(width = 0.5), size = 5) +  # Add significance label
  labs(title = "MG species profile",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 7.5, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 0.5)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))
################################################################################
################################################################################
#replotting lipidone output (pre-starved)
#chain length
clength <- read.csv("Input/Chain length.csv")
# make long format
clength_long <- tidyr::gather(clength, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
clength_long <- clength_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
clength_long <- clength_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
clength_long$CellLine <- factor(clength_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
clength_long$label <- ifelse(clength_long$P.value < 0.001 & clength_long$CellLine == "SC", '***',
                          ifelse(clength_long$P.value < 0.01 & clength_long$CellLine == "SC", '**',
                                 ifelse(clength_long$P.value < 0.05 & clength_long$CellLine == "SC", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(clength_long, aes(x= as.factor(Chain.length), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + 25), position = position_dodge(width = 0.25), size = 5) +  # Add significance label
  labs(title = "Chain Length",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 7.5, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 600)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

############################chain length_TG######################################
clength_tg <- read.csv("Input/Chain length_TG.csv")
# make long format
clength_tg_long <- tidyr::gather(clength_tg, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
clength_tg_long <- clength_tg_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
clength_tg_long <- clength_tg_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
clength_tg_long$CellLine <- factor(clength_tg_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
clength_tg_long$label <- ifelse(clength_tg_long$P.value < 0.001 & clength_tg_long$CellLine == "SC", '***',
                             ifelse(clength_tg_long$P.value < 0.01 & clength_tg_long$CellLine == "SC", '**',
                                    ifelse(clength_tg_long$P.value < 0.05 & clength_tg_long$CellLine == "SC", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(clength_tg_long, aes(x= as.factor(Chain.length), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + 1), position = position_dodge(width = 0.25), size = 5) +  # Add significance label
  labs(title = "TG Chain Length",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 25)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

###############################chain unsat#######################################
unsat <- read.csv("Input/Chains Unsaturation_all classes.csv")
# make long format
unsat_long <- tidyr::gather(unsat, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
unsat_long <- unsat_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
unsat_long <- unsat_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
unsat_long$CellLine <- factor(unsat_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
unsat_long$label <- ifelse(unsat_long$P.value < 0.001 & unsat_long$CellLine == "SC", '***',
                                ifelse(unsat_long$P.value < 0.01 & unsat_long$CellLine == "SC", '**',
                                       ifelse(unsat_long$P.value < 0.05 & unsat_long$CellLine == "SC", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(unsat_long, aes(x= as.factor(Unsaturations), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + 25), position = position_dodge(width = 0.25), size = 5) +  # Add significance label
  labs(title = "All Class Unsaturation",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 700)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))

########################TG chain unsat##########################################
unsat <- read.csv("Input/Chains Unsaturation_TG.csv")
# make long format
unsat_long <- tidyr::gather(unsat, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
unsat_long <- unsat_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
unsat_long <- unsat_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
unsat_long$CellLine <- factor(unsat_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
unsat_long$label <- ifelse(unsat_long$P.value < 0.001 & unsat_long$CellLine == "SC", '***',
                           ifelse(unsat_long$P.value < 0.01 & unsat_long$CellLine == "SC", '**',
                                  ifelse(unsat_long$P.value < 0.05 & unsat_long$CellLine == "SC", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(unsat_long, aes(x= as.factor(Unsaturations), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + 1), position = position_dodge(width = 0.25), size = 5) +  # Add significance label
  labs(title = "TG Unsaturation",
       x = " ",
       y = "Relative abundance") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 12, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 30)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))


####################Ether/Ester linked ratio####################################
Eth <- read.csv("Input/Ether_Ester linked ratio.csv")
#remove na values
Eth <- subset(Eth, SC != 0)
#make P-val col numeric
Eth$P.value <- as.numeric(Eth$P.value)
# make long format
Eth_long <- tidyr::gather(Eth, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
Eth_long <- Eth_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
Eth_long <- Eth_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
Eth_long$CellLine <- factor(Eth_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
Eth_long$label <- ifelse(Eth_long$P.value < 0.001 & Eth_long$CellLine == "KD", '***',
                           ifelse(Eth_long$P.value < 0.01 & Eth_long$CellLine == "KD", '**',
                                  ifelse(Eth_long$P.value < 0.05 & Eth_long$CellLine == "KD", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(Eth_long, aes(x= as.factor(Alkyl.Acyl.ratio), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + SEM + 0.05), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = " ",
       x = " ",
       y = "Ether/Ester ratio") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 2)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))


###################Odd/Even linked ratio#####################################
odd <- read.csv("Input/Odds_Even ratio.csv")
#remove na values
odd <- subset(odd, SC != 0)
#make P-val col numeric
odd$P.value <- as.numeric(odd$P.value)
# make long format
odd_long <- tidyr::gather(odd, key = "CellLine", value = "value", c("KD", "SC"))
# Extract the corresponding standard errors
odd_long <- odd_long %>%
  mutate(Standard_Error = ifelse(CellLine == "KD", Standard_Error, NA),
         Standard_Error.1 = ifelse(CellLine == "SC", Standard_Error.1, NA))
# coalesce the standard error values into a single column
odd_long <- odd_long %>%
  mutate(SEM = coalesce(Standard_Error, Standard_Error.1)) %>%
  select(-Standard_Error, -Standard_Error.1)
#make SC the reference factor
odd_long$CellLine <- factor(odd_long$CellLine, levels = c("SC", "KD"))
# Create a new column 'label' based on significance levels
odd_long$label <- ifelse(odd_long$P.value < 0.001 & odd_long$CellLine == "KD", '***',
                         ifelse(odd_long$P.value < 0.01 & odd_long$CellLine == "KD", '**',
                                ifelse(odd_long$P.value < 0.05 & odd_long$CellLine == "KD", '*', '')))

# Plot the data (rest of the code remains unchanged)
ggplot(odd_long, aes(x= as.factor(Odd.Even.ratio), y = value, fill = CellLine)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.5, color = "black", linewidth = 0.05) +
  geom_errorbar(aes(ymin = value - SEM, ymax = value + SEM), position = position_dodge(width = 0.5), width = 0.25, linewidth = 0.1) +  # Add error bars
  geom_text(aes(label = label, y = value + 0.01), position = position_dodge(width = 0), size = 5) +  # Add significance label
  labs(title = " ",
       x = " ",
       y = "Odd/Even ratio") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, size = 8, vjust = 0, margin = margin(b = 10)),
        axis.line = element_line(color = "black", linewidth = 0.25),
        plot.title = element_text(hjust = 0.5)) + 
  scale_y_continuous(expand = c(0, 0), limits = c(0, 0.5)) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = NA, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("saddlebrown", "lightgoldenrod1"))



###################################################################################################################################
###################################################################################################################################
###################################################################################################################################
# Install and load required packages
library(ggplot2)
library(dplyr)



#import dataset
ctrl <- read.csv("Input/Control lipid distribution.csv", check.names = F)
kd <- read.csv("Input/KD lipid distribution.csv", check.names = F)

# Preparing data for inner donut
inner_ctrl <- ctrl %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_ctrl$`Lipid Categories`<- factor(inner_ctrl$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

# Preparing data for outer donut
outer_ctrl <- ctrl %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_ctrl$rank.order <- c(9,8,7,6,5,4,13,11,10,12,3,2,1)
outer_ctrl <- outer_ctrl %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_ctrl$`Lipid Class`<- factor(outer_ctrl$`Lipid Class`, levels = c("EtherPC", "PC", "EtherPE", "PE", "LPC", "EtherLPC", "PG", "EtherLPE", "LPE", "DG", "TG","SM", "CE"))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG" = "lightblue",
  "TG" = "steelblue3",
  "EtherLPC" = "chocolate2",
  "EtherLPE" = "lightcoral",
  "EtherPC" = "lightsalmon1",
  "EtherPE" = "burlywood1",
  "LPC" = "sandybrown",
  "LPE" = "hotpink3",
  "PC" = "peachpuff",
  "PE" = "indianred3",
  "PG" = "burlywood",
  "SM" = "rosybrown1",
  "CE" = "lightgoldenrod1"
)



# Plot
ggplot() +
  geom_bar(data = inner_ctrl, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "Control Lipid Distribution Chart") +
  geom_text(data = inner_ctrl, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_ctrl, aes(x = 3, y = Mean, fill = `Lipid Class`), 
           stat = "identity", color = "white", linewidth = 0.05) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_ctrl, aes(x = 3, y = outer_cumsum, label = `Lipid Class`), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="control donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="control donut chart_I.svg",width=9.42,height=5.82,units="in")



# Preparing data for inner donut
inner_kd <- kd %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_kd$`Lipid Categories`<- factor(inner_kd$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

# Preparing data for outer donut
outer_kd <- kd %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_kd$rank.order <- c(9,8,7,6,5,13,4,11,10,12,3,2,1)
outer_kd <- outer_kd %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_kd$`Lipid Class`<- factor(outer_kd$`Lipid Class`, levels = c("PC", "EtherPC", "EtherPE", "PE", "LPC", "EtherLPC", "EtherLPE","PG", "LPE", "TG", "DG","SM", "CE"))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG" = "lightblue",
  "TG" = "steelblue3",
  "EtherLPC" = "chocolate2",
  "EtherLPE" = "lightcoral",
  "EtherPC" = "lightsalmon1",
  "EtherPE" = "burlywood1",
  "LPC" = "sandybrown",
  "LPE" = "hotpink3",
  "PC" = "peachpuff",
  "PE" = "indianred3",
  "PG" = "burlywood",
  "SM" = "rosybrown1",
  "CE" = "lightgoldenrod1"
)



# Plot
ggplot() +
  geom_bar(data = inner_kd, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "KD Lipid Distribution Chart") +
  geom_text(data = inner_kd, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_kd, aes(x = 3, y = Mean, fill = `Lipid Class`), 
           stat = "identity", color = "white", linewidth = 0.05) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_kd, aes(x = 3, y = outer_cumsum, label = `Lipid Class`), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="KD donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="KD donut chart_I.svg",width=9.42,height=5.82,units="in")


#import dataset
ctrl <- read.csv("Input/Control lipid distribution (time 3).csv", check.names = F)
kd <- read.csv("Input/KD lipid distribution (time 3).csv", check.names = F)

# Preparing data for inner donut
inner_ctrl <- ctrl %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_ctrl$`Lipid Categories`<- factor(inner_ctrl$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

# Preparing data for outer donut
outer_ctrl <- ctrl %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_ctrl$rank.order <- c(9,8,7,6,5,13,4,11,10,12,3,2,1)
outer_ctrl <- outer_ctrl %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_ctrl$`Lipid Class`<- factor(outer_ctrl$`Lipid Class`, levels = c("EtherPC", "PC", "EtherPE", "PE", "LPC", "EtherLPC", "PG", "EtherLPE", "LPE", "DG", "TG","SM", "CE"))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG" = "lightblue",
  "TG" = "steelblue3",
  "EtherLPC" = "chocolate2",
  "EtherLPE" = "lightcoral",
  "EtherPC" = "lightsalmon1",
  "EtherPE" = "burlywood1",
  "LPC" = "sandybrown",
  "LPE" = "hotpink3",
  "PC" = "peachpuff",
  "PE" = "indianred3",
  "PG" = "burlywood",
  "SM" = "rosybrown1",
  "CE" = "lightgoldenrod1"
)



# Plot
ggplot() +
  geom_bar(data = inner_ctrl, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "Control Lipid Distribution Chart") +
  geom_text(data = inner_ctrl, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_ctrl, aes(x = 3, y = Mean, fill = `Lipid Class`), 
           stat = "identity", color = "white", linewidth = 0.05) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_ctrl, aes(x = 3, y = outer_cumsum, label = `Lipid Class`), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="starved control donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="starved control donut chart_I.svg",width=9.42,height=5.82,units="in")



# Preparing data for inner donut
inner_kd <- kd %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_kd$`Lipid Categories`<- factor(inner_kd$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

# Preparing data for outer donut
outer_kd <- kd %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_kd$rank.order <- c(9,8,7,6,5,13,4,11,10,12,3,2,1)
outer_kd <- outer_kd %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_kd$`Lipid Class`<- factor(outer_kd$`Lipid Class`, levels = c("EtherPC", "PC", "EtherPE", "PE", "LPC", "EtherLPC", "EtherLPE","PG", "LPE", "DG", "TG","SM", "CE"))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG" = "lightblue",
  "TG" = "steelblue3",
  "EtherLPC" = "chocolate2",
  "EtherLPE" = "lightcoral",
  "EtherPC" = "lightsalmon1",
  "EtherPE" = "burlywood1",
  "LPC" = "sandybrown",
  "LPE" = "hotpink3",
  "PC" = "peachpuff",
  "PE" = "indianred3",
  "PG" = "burlywood",
  "SM" = "rosybrown1",
  "CE" = "lightgoldenrod1"
)



# Plot
ggplot() +
  geom_bar(data = inner_kd, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "KD Lipid Distribution Chart") +
  geom_text(data = inner_kd, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_kd, aes(x = 3, y = Mean, fill = `Lipid Class`), 
           stat = "identity", color = "white", linewidth = 0.05) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_kd, aes(x = 3, y = outer_cumsum, label = `Lipid Class`), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="starved KD donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="starved KD donut chart_I.svg",width=9.42,height=5.82,units="in")

