install.packages("tidyverse")
install.packages("readxl")

install.packages("devtools")
library(devtools)
install_github("jokergoo/ComplexHeatmap")

install.packages("gridtext")
install.packages("scales")

library(tidyverse)
library(readxl)
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

dir.create("input")
dir.create("output")
dir.create("figures")



protdata <- read_excel("Input/Lipid Gene List.xlsx")

#protdata <- read_excel("input/List of Sig Genes involved in Lipid Metabolism (PA treatment).xlsx")
#view(protdata)
#str(protdata)

#Protdata.filt <- Protdata %>%
  #mutate_at(2:25, as.numeric) %>%
  #as.data.frame()

#dim(Protdata.filt)
#str(Protdata.filt)

#write.csv(Protdata.filt, "output/Z-score_normalized_I.CSV") # save the file

Protdata.filt <-read.csv("Input/Log transformed Protein Matrix.csv")
int <-read.csv("Input/Upset Plot Sc v KD_PA treatments only.csv")
int <- int[,-1]

# filter Lipid Genes
#Protdata.filt <-Protdata.filt %>%
#  filter(Genes %in% protdata$Genes)

# filter Lipid Genes
int <-int %>%
  filter(Genes %in% protdata$Genes)

# filter sig hits in starved
int_starv <- int %>%
  filter (adj.P.Val.SS.PA < 0.05)

write.csv(int_starv, "output/Sig lipid genes in PA_SS.CSV")

# filter Lipid Genes
Protdata.filt <-Protdata.filt %>%
  filter(Genes %in% int_starv$Genes)

# filter to remove unresolved protein isomers
Protdata.filt <- Protdata.filt[!grepl(";", Protdata.filt$Protein.Group), ]

Protdata.filt <- Protdata.filt[c(4:6, 10:12, 16:18, 22:24, 28)]

#filtered out duplicated genes
Protdata.filt <- Protdata.filt %>%
  group_by(Genes) %>%
  filter(n() == 1) %>%
  ungroup()

# set gene names as row names
m <- Protdata.filt [c(13, 1:3, 7:9, 4:6, 10:12)]
m1 <- as.matrix(m)
m2 <- m1 [,2:13]
rownames(m2) <- m$Genes


m3 <- as.data.frame(m2) %>%
  mutate_at(1:12, as.numeric) %>%
  rename("3A" = "Scrambled.control_PA_I",
         "3B" = "Scrambled.control_PA_II",
         "3C" = "Scrambled.control_PA_III",
         "4A" = "Pdk1.KD_PA_I",
         "4B" = "Pdk1.KD_PA_II",
         "4C" = "Pdk1.KD_PA_III",
         "7A" = "Scrambled.control_SS_PA_I",
         "7B" = "Scrambled.control_SS_PA_II",
         "7C" = "Scrambled.control_SS_PA_III",
         "8A" = "Pdk1.KD_SS_PA_I",
         "8B" = "Pdk1.KD_SS_PA_II",
         "8C" = "Pdk1.KD_SS_PA_III")
#calculate z score
m3 <- t(scale(t(m3)))


m4 <- as.matrix(m3)



# plot heat maps
#number_of_SCnBSA <- length(grep("1", colnames(m4)))
#number_of_KDnBSA <- length(grep("2", colnames(m4)))
number_of_SCnPA <- length(grep("3", colnames(m4)))
number_of_KDnPA <- length(grep("4", colnames(m4)))
#number_of_SCnBSAnSS <- length(grep("5", colnames(m4)))
#number_of_KDnBSAnSS <- length(grep("6", colnames(m4)))
number_of_SCnPAnSS <- length(grep("7", colnames(m4)))
number_of_KDnPAnSS <- length(grep("8", colnames(m4)))

#end_index_SCnBSA <- grep("1", colnames(m4)) [number_of_SCnBSA]
#end_index_KDnBSA <- grep("2", colnames(m4)) [number_of_KDnBSA]
end_index_SCnPA <- grep("3", colnames(m4)) [number_of_SCnPA]
end_index_KDnPA <- grep("4", colnames(m4)) [number_of_KDnPA]
#end_index_SCnBSAnSS <- grep("5", colnames(m4)) [number_of_SCnBSAnSS]
#end_index_KDnBSAnSS <- grep("6", colnames(m4)) [number_of_KDnBSAnSS]
end_index_SCnPAnSS <- grep("7", colnames(m4)) [number_of_SCnPAnSS]
end_index_KDnPAnSS <- grep("8", colnames(m4)) [number_of_KDnPAnSS]

#end_index_SCnBSA
#end_index_KDnBSA
end_index_SCnPA
end_index_KDnPA
#end_index_SCnBSAnSS
#end_index_KDnBSAnSS
end_index_SCnPAnSS
end_index_KDnPAnSS

#m4[is.na(m4)] <- 0
max(m4)
min(m4)

m4[is.na(m4)] <- 0

heatmap <- Heatmap(m4,
                   show_row_names = T,
                   show_column_names = FALSE,
                   show_row_dend = F,
                   show_column_dend = FALSE,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(fontsize = 5),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("skyblue2", "white", "indianred")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(130, "mm"),
                   width = ncol(m4)*unit(10, "mm"),
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = " ",
                     title_position = "topcenter",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(13, "cm"),
                     labels_gp = gpar(fontsize = 7)),
                   
                   #split = 3, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                   
                     ind = unique(c(mat[, c(#end_index_SCnBSA, 
                                            #end_index_KDnBSA, 
                                            end_index_SCnPA, 
                                            end_index_KDnPA, 
                                            #end_index_SCnBSAnSS, 
                                            #end_index_KDnBSAnSS, 
                                            end_index_SCnPAnSS, 
                                            end_index_KDnPAnSS
                                            ) # enter the number where you want a gap between columns
                                        ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
                   ) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 1
grid.rect(x = (end_index_SCnBSA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_SCnBSA)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat4",
                    col = "wheat4"
          )
)
grid.text("SC_BSA", 
          x = (end_index_SCnBSA)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 2
grid.rect(x = (end_index_KDnBSA + end_index_SCnBSA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_KDnBSA)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell1",
                    col = "seashell1"
          )
)
grid.text("KD_BSA", 
          x = (end_index_KDnBSA + end_index_SCnBSA)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black"))


#Condition label 3
grid.rect(x = (end_index_SCnPA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_SCnPA)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#AA4611",
                    col = "#AA4611"
          )
)
grid.text("SC(fed)", 
          x = (end_index_SCnPA)/2/ncol(m4), # location at the middle of DN
          y = 1.5,
          just = "center",
          #rot = 90,
          gp = gpar(fontsize = 7,
                    col = "black"))                    

#Condition label 4
grid.rect(x = (end_index_KDnPA + end_index_SCnPA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_KDnPA)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#CB9f18",
                    col = "#CB9F18"
          )
)
grid.text("KD(fed)", 
          x = (end_index_KDnPA + end_index_SCnPA)/2/ncol(m4), # location at the middle of DN
          y = 1.5,
          just = "center",
          #rot = 90,
          gp = gpar(fontsize = 7,
                    col = "black"))                    

#Condition label 5
grid.rect(x = (end_index_SCnBSAnSS + end_index_KDnPA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_SCnBSAnSS)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "wheat2",
                    col = "wheat2"
          )
)
grid.text("SC_BSA_SS", 
          x = (end_index_SCnBSAnSS + end_index_KDnPA)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_KDnBSAnSS + end_index_SCnBSAnSS)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_KDnBSAnSS)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "seashell3",
                    col = "seashell3"
          )
)
grid.text("KD_BSA_SS", 
          x = (end_index_KDnBSAnSS + end_index_SCnBSAnSS)/2/ncol(m4), # location at the middle of DN
          y = 1.2,
          just = "left",
          rot = 90,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 7
grid.rect(x = (end_index_SCnPAnSS + end_index_KDnPA)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_SCnPAnSS)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#AA4611",
                    col = "#AA4611"
          )
)
grid.text("SC(starved)", 
          x = (end_index_SCnPAnSS + end_index_KDnPA)/2/ncol(m4), # location at the middle of DN
          y = 1.5,
          just = "center",
          #rot = 90,
          gp = gpar(fontsize = 7,
                    col = "black"))

#Condition label 8
grid.rect(x = (end_index_KDnPAnSS + end_index_SCnPAnSS)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (number_of_KDnPAnSS)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#CB9F18",
                    col = "#CB9F18"
          )
)
grid.text("KD(starved)", 
          x = (end_index_KDnPAnSS + end_index_SCnPAnSS)/2/ncol(m4), # location at the middle of DN
          y = 1.5,
          just = "center",
          #rot = 90,
          gp = gpar(fontsize = 7,
                    col = "black"))


## Top label gaps
#Vertical lines
grid.rect(x = end_index_SCnBSA/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnBSA/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnPA/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnPA/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnBSAnSS/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_KDnBSAnSS/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_SCnPAnSS/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))


# step 4 - end by closing the saved file
ggsave(filename="Lipid genes heatmap.png",width=10,height=10,units="in",dpi=600)

pdf(file = 'figures/Sig Lipid genes heatmap.pdf',
    width = 10, 
    height = 10)
#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()




dev.off()

