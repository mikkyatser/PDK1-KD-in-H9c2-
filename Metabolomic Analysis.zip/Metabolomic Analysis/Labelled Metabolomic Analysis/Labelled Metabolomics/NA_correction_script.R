#This script corrects for natural abundance from raw data in isotope tracing untargeted metabolomics.
# Requires known metabolites and must be performed 1 m/z at a time. see ppt for tutorial.

#set working directory
setwd("") #update this and save script into your folder so you remember everything you did
#if package is not yet installed on your machine, first install, then load
#install.packages('IsoCorrectoR') 
library(IsoCorrectoR) #Loads library
#update Measurement file and out file name in the line below:
IsoCorrection(MeasurementFile = "./Gluc_NA_measFile.xlsx", ElementFile = "./ElementFile.csv", MoleculeFile = "./MoleculeFile.xlsx", CorrectTracerImpurity = TRUE, CorrectTracerElementCore = TRUE, CalculateMeanEnrichment = TRUE, UltraHighRes = TRUE, DirOut = ".", FileOut = "Glucose", FileOutFormat = "csv", ReturnResultsObject = FALSE)

