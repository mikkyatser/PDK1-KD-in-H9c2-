library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)

#Limma and Volcano plot
library(limma)

exprs <- read.csv("Input/Log transformed Protein Matrix.csv") #log2expression data

exprs_2 <- exprs[, 1:25]
exprs_clean <- exprs_2[c(25,1:24)] 

# Remove duplicated rows
#exprs_unique <- exprs[!duplicated(exprs$Protein.Group) & !duplicated(exprs$Protein.Group, fromLast = TRUE), ]
# Remove rows where 'Genes' column contains ";"
#exprs_clean <- exprs_unique[!grepl(";", exprs_unique$Genes), ]

# Convert columns to numerical except 'Genes' column
#for (col in names(exprs_clean)) {
#  if (col != "Genes") {
#    exprs_clean[[col]] <- as.numeric(as.character(exprs_clean[[col]]))
#  }
#}
#write.csv(exprs_clean, "Output/Log2 protein data cleaned.csv", row.names = F)
sample_info <- read.csv("Input/Protein metadata.csv", header = TRUE, row.names = 1) #metadata

#make cell line a factor and set SC as a reference
sample_info$CellLine <- factor(sample_info$CellLine, levels=c("SC","KD")) 
levels(sample_info$CellLine)

#make treatement a categorical variable
sample_info$Treatment <- factor(sample_info$Treatment, levels=c("BSA","PA","BSA.SS", "PA.SS")) 
levels(sample_info$Treatment)

# Create a design matrix
design <- model.matrix(~0 + CellLine + Treatment, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  CellLineKD_TreatmentBSA = as.numeric(sample_info$CellLine == "KD" & sample_info$Treatment == "BSA"),
  CellLineKD_TreatmentPA = as.numeric(sample_info$CellLine == "KD" & sample_info$Treatment == "PA"),
  CellLineKD_TreatmentBSA.SS = as.numeric(sample_info$CellLine == "KD" & sample_info$Treatment == "BSA.SS"),
  CellLineKD_TreatmentPA.ss = as.numeric(sample_info$CellLine == "KD" & sample_info$Treatment == "PA.SS"),
  CellLineSC_TreatmentBSA = as.numeric(sample_info$CellLine == "SC" & sample_info$Treatment == "BSA"),
  CellLineSC_TreatmentPA = as.numeric(sample_info$CellLine == "SC" & sample_info$Treatment == "PA"),
  CellLineSC_TreatmentBSA.SS = as.numeric(sample_info$CellLine == "SC" & sample_info$Treatment == "BSA.SS"),
  CellLineSC_TreatmentPA.ss = as.numeric(sample_info$CellLine == "SC" & sample_info$Treatment == "PA.SS")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs_clean, design_matrix)

# contrast Sc v KD BSA
contrast.matrix <- makeContrasts(
  CellLineKD_TreatmentBSA - CellLineSC_TreatmentBSA,
  levels = design_matrix)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_BSA <- topTable(fit2, coef = 1, number = nrow(exprs_clean))

# Merge the datasets based on the common column "Protein.Groups"
merged_BSA <- merge(results_BSA, exprs, by = "Protein.Group", all = TRUE)
merged_BSA <- merged_BSA[c(34,1:7)]
write.csv(merged_BSA, "Output/SCvKD_BSA.csv", row.names = F)
# Remove rows where 'Genes' column contains ";". Filtering for unique protein groups
merged_BSA_clean <- merged_BSA[!grepl(";", merged_BSA$Protein.Group), ]
merged_BSA_clean <- merged_BSA_clean %>% filter (adj.P.Val < 0.05)
# Check for duplicate rows in the 'Protein.Groups' column
write.csv(merged_BSA_clean, "Output/Sig hits SCvKD_BSA.csv", row.names = F)
duplicate_rows <- merged_BSA_clean[duplicated(merged_BSA_clean$Genes) | duplicated(merged_BSA_clean$Genes, fromLast = TRUE), ]

# contrast Sc v KD PA
contrast.matrix <- makeContrasts(
  CellLineKD_TreatmentPA - CellLineSC_TreatmentPA,
  levels = design_matrix)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_PA <- topTable(fit2, coef = 1, number = nrow(exprs_clean))

# Merge the datasets based on the common column "Protein.Groups"
merged_PA <- merge(results_PA, exprs, by = "Protein.Group", all = TRUE)
merged_PA <- merged_PA[c(34,1:7)]
write.csv(merged_PA, "Output/SCvKD_PA.csv", row.names = F)
# Remove rows where 'Genes' column contains ";". Filtering for unique protein groups
merged_PA_clean <- merged_PA[!grepl(";", merged_PA$Protein.Group), ]
merged_PA_clean <- merged_PA_clean %>% filter (adj.P.Val < 0.05)
# Check for duplicate rows in the 'Protein.Groups' column
write.csv(merged_PA_clean, "Output/Sig hits SCvKD_PA.csv", row.names = F)

# contrast Sc v KD BSA.SS
contrast.matrix <- makeContrasts(
  CellLineKD_TreatmentBSA.SS - CellLineSC_TreatmentBSA.SS,
  levels = design_matrix)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_BSA.SS <- topTable(fit2, coef = 1, number = nrow(exprs_clean))

# Merge the datasets based on the common column "Protein.Groups"
merged_BSA.SS <- merge(results_BSA.SS, exprs, by = "Protein.Group", all = TRUE)
merged_BSA.SS <- merged_BSA.SS[c(34,1:7)]
write.csv(merged_BSA.SS, "Output/SCvKD_SS_BSA.csv", row.names = F)
# Remove rows where 'Genes' column contains ";". Filtering for unique protein groups
merged_BSA.SS_clean <- merged_BSA.SS[!grepl(";", merged_BSA.SS$Protein.Group), ]
merged_BSA.SS_clean <- merged_BSA.SS_clean %>% filter (adj.P.Val < 0.05)
# Check for duplicate rows in the 'Protein.Groups' column
write.csv(merged_BSA.SS_clean, "Output/Sig hits SCvKD_SS_BSA.csv", row.names = F)


# contrast Sc v KD PA.SS
contrast.matrix <- makeContrasts(
  CellLineKD_TreatmentPA.ss - CellLineSC_TreatmentPA.ss,
  levels = design_matrix)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results_PA.SS <- topTable(fit2, coef = 1, number = nrow(exprs_clean))

# Merge the datasets based on the common column "Protein.Groups"
merged_PA.SS <- merge(results_PA.SS, exprs, by = "Protein.Group", all = TRUE)
merged_PA.SS <- merged_PA.SS[c(34,1:7)]
write.csv(merged_PA.SS, "Output/SCvKD_SS_PA.csv", row.names = F)
# Remove rows where 'Genes' column contains ";". Filtering for unique protein groups
merged_PA.SS_clean <- merged_PA.SS[!grepl(";", merged_PA.SS$Protein.Group), ]
merged_PA.SS_clean <- merged_PA.SS_clean %>% filter (adj.P.Val < 0.05)
# Check for duplicate rows in the 'Protein.Groups' column
write.csv(merged_PA.SS_clean, "Output/Sig hits SCvKD_SS_PA.csv", row.names = F)

###################################################################################

#m <- read.csv("Input/TG met Genes to rat uniprot IDs_2024_08_15.csv")
m <- read.csv("Input/TG Metabolism gene list.csv")
#m <- m[,-4]

pa <- read.csv("Output/SCvKD_PA.csv")
pa.s <- read.csv("Output/SCvKD_SS_PA.csv")  

pa_tg <- pa %>% filter (pa$Genes %in% m$Genes)

# Remove rows where the Genes column is NA, empty, or contains only whitespace
#pa_tg <- pa_tg %>% 
#  filter(!is.na(Genes) & Genes != "" & str_trim(Genes) != "")
write.csv(pa_tg, "Output/PA_TG Metabolism genes.csv", row.names = F)

pa_tg2 <- pa_tg %>%
  filter (adj.P.Val < 0.05)

write.csv(pa_tg2, "Output/Sig hits PA_TG Metabolism genes.csv", row.names = F)


pa.s_tg <- pa.s %>% filter (pa.s$Genes %in% m$Genes)  
#pa.s_tg <- pa.s_tg %>% 
#  filter(!is.na(Genes) & Genes != "" & str_trim(Genes) != "") 
write.csv(pa.s_tg, "Output/SS_PA_TG Metabolism genes.csv", row.names = F)  

pa.s_tg2 <- pa.s_tg %>%
  filter (adj.P.Val < 0.05)
write.csv(pa.s_tg2, "Output/Sig hits SS_PA_TG Metabolism genes.csv", row.names = F)
  
  
  